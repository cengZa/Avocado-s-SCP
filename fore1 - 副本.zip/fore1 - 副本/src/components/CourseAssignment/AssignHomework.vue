<template>
  <div class="assign-homework">
    <h2>发布作业</h2>
    <div class="homeworkdetail">
      <form @submit.prevent="submitHomework" class="homework-form">
        <!-- 作业标题 -->
        <div class="form-group">
          <label for="title">作业标题:</label>
          <input type="text" id="title" v-model="Assignment.title" required />
        </div>

        <!-- 作业介绍 -->
        <div class="form-group">
          <label for="description">作业介绍:</label>
          <textarea id="description" v-model="Assignment.description" rows="4" required></textarea>
        </div>

        <!-- 开始时间 -->
        <div class="form-group">
          <label for="startTime">开始时间:</label>
          <input type="datetime-local" id="startTime" v-model="Assignment.startTime" required />
        </div>

        <!-- 截止时间 -->
        <div class="form-group">
          <label for="endTime">截止时间:</label>
          <input type="datetime-local" id="endTime" v-model="Assignment.endTime" required />
        </div>

        <!-- 附件上传 -->
        <div class="form-group">
          <label for="attachment">附件:</label>
          <input type="file" id="attachment" @change="handleFileUpload" ref="fileInput" class="form-control" multiple/>
          <p v-if="selectedFileNames.length > 0" class="uploaded-file-info">
            已选择文件:
            <span v-for="(name, index) in selectedFileNames" :key="index">{{ name }}{{ index < selectedFileNames.length - 1 ? ', ' : '' }}</span>
          </p>
        </div>

        <!-- 是否互评 -->
        <div class="form-group peer-review-group">
          <label for="peerReview">是否互评:</label>
          <input type="checkbox" id="peerReview" v-model="Assignment.isPeerReview"/>
        </div>

        <!-- 互评规则配置（条件渲染） -->
        <div v-if="Assignment.isPeerReview" class="peer-review-config">
          <!-- 互评截止时间 -->
          <div class="form-group">
            <label for="peerReviewDeadline">互评截至时间:</label>
            <input type="datetime-local" id="peerReviewDeadline" v-model="Assignment.peerReviewDeadline" required/>
          </div>

          <!-- 每位学生需要互评的数量 -->
          <div class="form-group">
            <label for="peerReviewCount">每位学生需要互评的数量:</label>
            <input type="number" id="peerReviewCount" v-model.number="Assignment.peerReviewCount" min="1" required/>
          </div>

          <!-- 互评评分范围 -->
          <div class="form-group">
            <label>互评分数范围:</label>
            <div class="score-range">
              <input type="number" v-model.number="Assignment.peerReviewMinScore" min="0" max="100" required/>
              <span>到</span>
              <input type="number" v-model.number="Assignment.peerReviewMaxScore" min="0" max="100" required/>
            </div>
          </div>
        </div>

        <!-- 提交按钮 -->
        <button type='submit' class="btn btn-primary" :disabled="isSubmitting">
          {{ isSubmitting ? '发布中...' : '发布作业' }}
        </button>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: 'AssignHomework',
  data() {
    return {
      Assignment: {
        title: '',
        description: '',
        publisherId: null,
        classId: null,
        startTime: '',
        endTime: '',
        isPeerReview: null,
        peerReviewDeadline: '',
        peerReviewCount: 1,
        peerReviewMinScore: 0,
        peerReviewMaxScore: 100
      },

      AssignmentAttachment: {
        assignmentId: null,
        files: []
      },
      selectedFileNames: [],
      isSubmitting: false
    };
  },

  created() {
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    const selectedClass = JSON.parse(sessionStorage.getItem('selectedCourse'));

    if (userInfo && selectedClass) {
      this.Assignment.publisherId = userInfo.id;
      this.Assignment.classId = selectedClass.classId;
    } else {
      alert('缺少必要的用户或班级信息');
      // 可以考虑跳转到登录页或错误页
      this.$router.push('/login');
    }
  },

  methods: {
    handleFileUpload(event) {
      const files = event.target.files;
      if (files && files.length > 0) {
        this.AssignmentAttachment.files = files; // FileList对象
        this.selectedFileNames = Array.from(files).map(file => file.name);
      } else {
        this.AssignmentAttachment.files = [];
        this.selectedFileNames = [];
      }
    },

    async submitHomework() {
      // 表单验证：互评截止时间必须晚于作业截止时间
      if (this.Assignment.isPeerReview) {
        const endTime = new Date(this.Assignment.endTime);
        const peerReviewDeadline = new Date(this.Assignment.peerReviewDeadline);
        if (peerReviewDeadline <= endTime) {
          alert('互评截止时间必须晚于作业截止时间');
          return;
        }

        // 互评分数范围验证
        if (this.Assignment.peerReviewMinScore > this.Assignment.peerReviewMaxScore) {
          alert('互评分数最小值不能大于最大值');
          return;
        }
      }

      const formData = new FormData();
      // 将 Assignment 对象转换为 JSON Blob
      const assignmentJson = JSON.stringify(this.Assignment);
      const assignmentBlob = new Blob([assignmentJson], { type: 'application/json' });
      formData.append('assignment', assignmentBlob);

      // 多文件添加
      if (this.AssignmentAttachment.files && this.AssignmentAttachment.files.length > 0) {
        for (let i = 0; i < this.AssignmentAttachment.files.length; i++) {
          formData.append('files', this.AssignmentAttachment.files[i]);
        }
      }

      this.isSubmitting = true;

      try {
        const response = await axios.post(
            `/api/assignments/create`, // 使用代理前缀
            formData,
            {
              headers: {
                'Content-Type': 'multipart/form-data'
              }
            }
        );

        if (response.data && response.data.code === '0') {
          alert(response.data.msg || '发布作业成功');
          this.resetForm();
        } else {
          alert(response.data.msg || '发布作业失败');
        }
      } catch (error) {
        console.error('提交作业失败:', error);

        // 检查是否有响应且包含错误消息
        if (error.response && error.response.data && error.response.data.msg) {
          alert(`提交作业失败：${error.response.data.msg}`);
        } else if (error.message) {
          // 处理其他类型的错误（如网络错误）
          alert(`提交作业失败：${error.message}`);
        } else {
          // 默认错误消息
          alert('提交作业失败！');
        }
      } finally {
        this.isSubmitting = false;
      }
    },

    resetForm() {
      this.Assignment.title = '';
      this.Assignment.description = '';
      this.Assignment.startTime = '';
      this.Assignment.endTime = '';
      this.Assignment.isPeerReview = false;
      this.Assignment.peerReviewDeadline = '';
      this.Assignment.peerReviewCount = 1;
      this.Assignment.peerReviewMinScore = 0;
      this.Assignment.peerReviewMaxScore = 100;

      this.AssignmentAttachment.files = [];
      this.selectedFileNames = [];
      // 重置文件输入框的值
      this.$refs.fileInput.value = '';
    }
  }
};
</script>

<style scoped>
.assign-homework {
  width: 80vw;
  padding: 20px;
  display: flex;
  flex-direction: column;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #333;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.assign-homework h2 {
  margin-bottom: 20px;
  font-size: 28px;
  text-align: center;
  color: #00509e;
}

.homeworkdetail {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.homework-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  text-align: left;
}

.form-group label {
  font-weight: bold;
  margin-bottom: 8px;
  color: #00509e;
}

.form-group input[type='text'],
.form-group input[type='datetime-local'],
.form-group input[type='file'],
.form-group textarea,
.form-group input[type='number'] {
  padding: 12px;
  border-radius: 5px;
  border: 1px solid #ccc;
  outline: none;
  transition: border-color 0.3s ease-in-out;
  width: 100%;
  font-size: 16px;
}

.form-group input[type='text']:focus,
.form-group input[type='datetime-local']:focus,
.form-group textarea:focus,
.form-group input[type='file']:focus,
.form-group input[type='number']:focus {
  border-color: #00509e;
}

.peer-review-group {
  display: flex;
  align-items: center;
  gap: 10px;
}

.peer-review-group input[type='checkbox'] {
  transform: scale(1.2);
  cursor: pointer;
}

.peer-review-config {
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #fff;
}

.peer-review-config .form-group {
  gap: 10px;
}

.score-range {
  display: flex;
  align-items: center;
  gap: 10px;
}

.score-range input[type='number'] {
  width: 80px;
}

.score-range span {
  font-weight: bold;
  color: #555;
}

button[type='submit'] {
  background-color: #00509e;
  color: white;
  border: none;
  padding: 15px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 18px;
  transition: background-color 0.3s ease;
}

button[type='submit']:hover {
  background-color: #003f7f;
}

button[type='submit']:disabled {
  background-color: #a0c4ff;
  cursor: not-allowed;
}

/* 上传文件信息样式 */
.uploaded-file-info {
  text-align: center;
  margin-top: 10px;
  color: #555;
  font-style: italic;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .assign-homework {
    width: 95vw;
  }

  .homework-form {
    gap: 15px;
  }

  button[type='submit'] {
    font-size: 16px;
    padding: 12px;
  }
}
</style>

<!--<template>-->
<!--  <div class="assign-homework">-->
<!--    <h2>发布作业</h2>-->
<!--    <div class="homeworkdetail">-->
<!--      <form @submit.prevent="submitHomework" class="homework-form">-->
<!--        <div class="form-group">-->
<!--          <label for="title">作业标题:</label>-->
<!--          <input type="text" id="title" v-model="Assignment.title" required />-->
<!--        </div>-->

<!--        <div class="form-group">-->
<!--          <label for="description">作业介绍:</label>-->
<!--          <textarea id="description" v-model="Assignment.description" rows="4" required></textarea>-->
<!--        </div>-->

<!--        <div class="form-group">-->
<!--          <label for="startTime">开始时间:</label>-->
<!--          <input type="datetime-local" id="startTime" v-model="Assignment.startTime" required />-->
<!--        </div>-->

<!--        <div class="form-group">-->
<!--          <label for="endTime">结束时间:</label>-->
<!--          <input type="datetime-local" id="endTime" v-model="Assignment.endTime" required />-->
<!--        </div>-->

<!--        <div class="form-group">-->
<!--          <label for="attachment">附件:</label>-->
<!--          <input type="file" id="attachment" @change="handleFileUpload" ref="fileInput" class="form-control"/>-->
<!--          <p v-if="selectedFileNames.length > 0" class="uploaded-file-info">-->
<!--            已选择文件:-->
<!--            <span v-for="(name, index) in selectedFileNames" :key="index">{{ name }} </span>-->
<!--          </p>-->
<!--&lt;!&ndash;          <p v-if='selectedFileName' class='uploaded-file-info'>已选择文件: {{ selectedFileName }}</p>&ndash;&gt;-->
<!--        </div>-->

<!--        <div class="form-group">-->
<!--          <label for="peerReview">是否互评:</label>-->
<!--          <input type="checkbox" id="peerReview" v-model="Assignment.isPeerReview"/>-->
<!--        </div>-->

<!--        <div class="form-group" v-if="Assignment.isPeerReview">-->
<!--          <label for="peerReviewDeadline">互评截至时间:</label>-->
<!--          <input type="datetime-local" id="peerReviewDeadline" v-model="Assignment.peerReviewDeadline" required/>-->
<!--        </div>-->

<!--        &lt;!&ndash; 提交按钮 &ndash;&gt;-->
<!--        <button type='submit' class="btn btn-primary" :disabled="isSubmitting">-->
<!--          {{ isSubmitting ? '发布中...' : '发布作业' }}-->
<!--        </button>-->
<!--      </form>-->

<!--    </div>-->
<!--  </div>-->
<!--</template>-->

<!--<script>-->
<!--import axios from "axios";-->

<!--export default {-->
<!--  data() {-->
<!--    return {-->
<!--      Assignment: {-->
<!--        title: null,-->
<!--        description: null,-->
<!--        publisherId:null,-->
<!--        classId:null,-->
<!--        startTime: null,-->
<!--        endTime: null,-->
<!--        isPeerReview: false,-->
<!--        peerReviewDeadline:null-->
<!--      },-->

<!--      AssignmentAttachment:{-->
<!--        assignmentId:null,-->
<!--        files:[]-->
<!--      },-->
<!--      selectedFileNames: [],-->
<!--      isSubmitting: false-->

<!--    };-->
<!--  },-->

<!--  created() {-->
<!--    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));-->
<!--    const selectedClass = JSON.parse(sessionStorage.getItem('selectedCourse'));-->

<!--    if (userInfo && selectedClass) {-->
<!--      this.Assignment.publisherId = userInfo.id;-->
<!--      this.Assignment.classId = selectedClass.classId;-->
<!--    } else {-->
<!--      alert('缺少必要的用户或班级信息');-->
<!--      // 可以考虑跳转到登录页或错误页-->
<!--    }-->

<!--  },-->

<!--  methods: {-->

<!--    handleFileUpload(event) {-->
<!--      const files = event.target.files;-->
<!--      if (files && files.length > 0) {-->
<!--        this.AssignmentAttachment.files = files; // FileList对象-->
<!--        this.selectedFileNames = Array.from(files).map(file => file.name);-->
<!--      } else {-->
<!--        this.AssignmentAttachment.files = [];-->
<!--        this.selectedFileNames = [];-->
<!--      }-->
<!--    },-->

<!--    async submitHomework() {-->
<!--      const formData = new FormData();-->
<!--      // 将 Assignment 对象转换为 JSON Blob-->
<!--      const assignmentJson = JSON.stringify(this.Assignment);-->
<!--      const assignmentBlob = new Blob([assignmentJson], { type: 'application/json' });-->
<!--      formData.append('assignment', assignmentBlob);-->

<!--      // 多文件添加-->
<!--      if (this.AssignmentAttachment.files && this.AssignmentAttachment.files.length > 0) {-->
<!--        for (let i = 0; i < this.AssignmentAttachment.files.length; i++) {-->
<!--          formData.append('files', this.AssignmentAttachment.files[i]);-->
<!--        }-->
<!--      }-->

<!--      this.isSubmitting = true;-->

<!--      try {-->
<!--        const response = await axios.post(-->
<!--            `http://localhost:8080/assignments/create`,-->
<!--            formData,-->
<!--            {-->
<!--              headers: {-->
<!--                'Content-Type': 'multipart/form-data'-->
<!--              }-->
<!--            }-->
<!--        );-->

<!--        if (response.data && response.data.code === '0') {-->
<!--          alert(response.data.msg);-->
<!--          this.resetForm();-->
<!--        } else {-->
<!--          alert(response.data.msg || '发布作业失败');-->
<!--        }-->
<!--      } catch (error) {-->
<!--        console.error('提交作业失败:', error);-->

<!--        // 检查是否有响应且包含错误消息-->
<!--        if (error.response && error.response.data && error.response.data.msg) {-->
<!--          alert(`提交作业失败：${error.response.data.msg}`);-->
<!--        } else if (error.message) {-->
<!--          // 处理其他类型的错误（如网络错误）-->
<!--          alert(`提交作业失败：${error.message}`);-->
<!--        } else {-->
<!--          // 默认错误消息-->
<!--          alert('提交作业失败！');-->
<!--        }-->
<!--      } finally {-->
<!--        this.isSubmitting = false;-->
<!--      }-->

<!--      // try {-->
<!--      //   const response = await axios.post(-->
<!--      //       `http://localhost:8080/assignments/create`,-->
<!--      //       formData,-->
<!--      //       {-->
<!--      //         headers: {-->
<!--      //           'Content-Type': 'multipart/form-data'-->
<!--      //         }-->
<!--      //       }-->
<!--      //   );-->
<!--      //-->
<!--      //   if (response.data && response.data.code === '0') {-->
<!--      //     alert(response.data.msg);-->
<!--      //     this.resetForm();-->
<!--      //   } else {-->
<!--      //     alert(response.data.msg || '发布作业失败');-->
<!--      //   }-->
<!--      // } catch (error) {-->
<!--      //   console.error('提交作业失败:', error);-->
<!--      //   alert('提交作业失败！');-->
<!--      // } finally {-->
<!--      //   this.isSubmitting = false;-->
<!--      // }-->
<!--    },-->

<!--    resetForm() {-->
<!--      this.Assignment.title = '';-->
<!--      this.Assignment.description = '';-->
<!--      this.Assignment.startTime = '';-->
<!--      this.Assignment.endTime = '';-->
<!--      this.Assignment.isPeerReview = false;-->
<!--      this.Assignment.peerReviewDeadline = '';-->

<!--      this.AssignmentAttachment.files = [];-->
<!--      this.selectedFileNames = [];-->
<!--      // 重置文件输入框的值-->
<!--      this.$refs.fileInput.value = '';-->
<!--    }-->

<!--  }-->
<!--};-->
<!--</script>-->

<!--<style scoped>-->
<!--.assign-homework {-->
<!--  width: calc(80vw);-->
<!--  padding: 20px;-->

<!--  display:flex;-->
<!--  flex-direction :column ;-->

<!--}-->

<!--.homeworkdetail{-->
<!--  display:flex ;-->
<!--  flex-direction :column ;-->
<!--  width:100%;-->
<!--}-->

<!--.homework-form {-->
<!--  display:flex ;-->
<!--  flex-direction :column ;-->
<!--  gap :15px ;-->
<!--}-->

<!--.form-group label {-->
<!--  font-weight:bold ;-->
<!--}-->

<!--input[type='text'],-->
<!--input[type='datetime-local'],-->
<!--input[type='file'],-->
<!--textarea {-->
<!--  padding :12px ;-->
<!--  border-radius :5px ;-->
<!--  border :1px solid #ccc ;-->
<!--  outline:none ;-->
<!--  transition:border-color .3s ease-in-out;-->
<!--  width:100%;-->
<!--}-->

<!--textarea {-->
<!--  resize:none;-->
<!--  font-size :16px;-->
<!--}-->

<!--input[type='text']:focus,-->
<!--input[type='datetime-local']:focus,-->
<!--textarea:focus,-->
<!--input[type='file']:focus{-->
<!--  border-color:#00509e;-->
<!--}-->

<!--button[type='submit'] {-->
<!--  background-color:#00509e;-->
<!--  color:white ;-->
<!--  border:none ;-->
<!--  padding :12px ;-->
<!--  border-radius :5px ;-->
<!--  cursor:pointer ;-->
<!--}-->

<!--/* 上传文件信息样式 */-->
<!--.uploaded-file-info {-->
<!--  text-align:center ;-->
<!--  margin-top :10px ;-->
<!--  color:#555 ;-->
<!--}-->
<!--</style>-->
