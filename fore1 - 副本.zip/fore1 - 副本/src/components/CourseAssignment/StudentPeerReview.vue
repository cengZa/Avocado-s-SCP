<template>
  <div class="peer-review-container">
    <h2>{{ assignment.title }}的互评列表</h2>
    <div v-if="error" class="error">{{ error }}</div>
    <table v-if="submissions.length > 0">
      <thead>
      <tr>
        <th>学生ID</th>
        <th>学生姓名</th>
        <th>提交时间</th>
        <th>分数</th>
        <th>状态</th>
        <th>操作</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="sub in submissions" :key="sub.submissionId">
        <td>{{ sub.studentId }}</td>
        <td>{{ sub.student_name }}</td>
        <td>{{ formatDateTime(sub.submitTime) }}</td>
        <td>{{ sub.score !== null ? sub.score : '未评分' }}</td>
        <td>{{ sub.status }}</td>
        <td>
          <button @click="openReviewModal(sub)">互评</button>
        </td>
      </tr>
      </tbody>
    </table>
    <div v-if="submissions.length === 0 && !error">
      无需要互评的提交
    </div>

    <!-- 互评弹窗 -->
    <div v-if="showModal" class="modal-overlay">
      <div class="modal-content">
        <h3>对提交ID：{{ currentSubmission.submissionId }} 进行互评</h3>
        <div class="form-group">
          <label>分数（0-100）：</label>
          <input type="number" v-model.number="reviewScore" min="0" max="100" />
        </div>
        <div class="form-group">
          <label>评语：</label>
          <textarea v-model="reviewComment" placeholder="输入评语"></textarea>
        </div>
        <div class="modal-actions">
          <button @click="submitReview">提交</button>
          <button @click="closeReviewModal">取消</button>
        </div>
        <div v-if="reviewError" class="error">{{ reviewError }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'StudentPeerReview',
  props: {
    assignment: {
      type: Object,
      required: true
    },
    userId: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      submissions: [],
      error: null,
      showModal: false,
      currentSubmission: null,
      reviewScore: null,
      reviewComment: '',
      reviewError: null
    };
  },
  created() {
    this.fetchPeerReviewSubmissions();
  },
  methods: {
    async fetchPeerReviewSubmissions() {
      try {
        const response = await axios.get(`http://localhost:8080/assignments/${this.assignment.assignmentId}/peerReview`, {
          params: {
            studentId: this.userId
          }
        });
        if (response.data && response.data.code === '0') {
          this.submissions = response.data.data;
        } else {
          this.error = response.data.msg || '获取互评列表失败';
        }
      } catch (err) {
        console.error(err);
        this.error = '获取互评列表失败，请稍后重试';
      }
    },
    formatDateTime(dateTime) {
      if (!dateTime) return '无';
      const date = new Date(dateTime);
      return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
    },
    openReviewModal(submission) {
      this.currentSubmission = submission;
      this.reviewScore = null;
      this.reviewComment = '';
      this.reviewError = null;
      this.showModal = true;
    },
    closeReviewModal() {
      this.showModal = false;
    },
    async submitReview() {
      if (this.reviewScore == null || this.reviewScore < 0 || this.reviewScore > 100) {
        this.reviewError = '请填写有效的分数（0-100）';
        return;
      }
      try {
        const payload = {
          submissionId: this.currentSubmission.submissionId,
          reviewerId: this.userId,
          score: this.reviewScore,
          comment: this.reviewComment
        };
        const response = await axios.post(`http://localhost:8080/assignments/peerReview`, payload);
        if (response.data && response.data.code === '0') {
          alert('互评成功！');
          // 可根据需要刷新列表或更新数据
          this.closeReviewModal();
        } else {
          this.reviewError = response.data.msg || '互评失败，请重试';
        }
      } catch (err) {
        console.error(err);
        this.reviewError = '互评提交失败，请稍后重试';
      }
    }
  }
};
</script>

<style scoped>
.peer-review-container {
  padding: 20px;
}
table {
  width: 100%;
  border-collapse: collapse;
}
thead th {
  background-color: #f2f2f2;
  padding: 8px;
}
tbody td {
  padding: 8px;
  border-bottom: 1px solid #ddd;
}
.error {
  color: red;
}
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width:100%;
  height:100%;
  background: rgba(0,0,0,0.5);
  display:flex;
  justify-content:center;
  align-items:center;
}
.modal-content {
  background:#fff;
  padding:20px;
  border-radius:5px;
  width:400px;
}
.form-group {
  margin-bottom:10px;
}
.modal-actions {
  display:flex;
  justify-content:flex-end;
}
.modal-actions button {
  margin-left:10px;
}
</style>
