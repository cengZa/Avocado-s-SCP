<template>
  <div class="submissions">
    <h2>{{ assignment.title }}的提交情况</h2>
    <table>
      <thead>
      <tr>
        <th>学生ID</th>
        <th>学生姓名</th>
        <th>提交时间</th>
        <th>得分</th>
        <th>操作</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="submission in submissions" :key="submission.submissionId">
        <td>{{ submission.studentId }}</td>
        <td>{{ submission.student_name }}</td>
        <td>{{ formatDateTime(submission.submitTime) }}</td>
        <td>{{ submission.score !== null ? submission.score : '未评分' }}</td>
        <td class="actions-cell">
          <!-- 如果有filePath，则显示下载按钮 -->
          <button v-if="submission.filePath" @click="downloadFile(submission)" class="download-btn">下载附件</button>
          <!-- 只有老师才有批改权限 -->
          <button v-if="isTeacher" @click="openGradeModal(submission)" class="grade-btn">批改</button>
        </td>
      </tr>
      </tbody>
    </table>
    <div v-if="error" class="error-message">{{ error }}</div>

    <!-- 批改弹窗 -->
    <div v-if="showGradeModal" class="modal-overlay">
      <div class="modal-content">
        <h3>对学生ID: {{ selectedSubmission.studentId }}的作业进行批改</h3>
        <div class="form-group">
          <label>分数：</label>
          <input type="number" v-model.number="gradeScore" />
        </div>
        <div class="form-group">
          <label>评语：</label>
          <textarea v-model="gradeComment"></textarea>
        </div>
        <div class="actions">
          <button @click="gradeSubmission" class="confirm-btn">确定</button>
          <button @click="closeGradeModal" class="cancel-btn">取消</button>
        </div>
        <div v-if="gradeError" class="error-message">{{ gradeError }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'SubmissionsDetail',

  props: {
    assignment: {
      type: Object,
      required: true
    }
  },

  data() {
    return {
      submissions: [],
      error: null,
      showGradeModal: false,
      selectedSubmission: null,
      gradeScore: null,
      gradeComment: '',
      gradeError: null
    };
  },

  computed: {
    isTeacher() {
      const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
      return userInfo && userInfo.role === 'Teacher';
    }
  },

  created() {
    this.fetchSubmissions();
  },

  methods: {
    async fetchSubmissions() {
      try {
        const response = await axios.get(
            `http://localhost:8080/assignments/${this.assignment.assignmentId}/submissions`
        );
        if (response.data && (response.data.code === '0' || response.data.code === 0)) {
          this.submissions = response.data.data;
        } else {
          this.error = '获取提交列表失败，请重试！';
        }
      } catch (error) {
        this.error = '获取提交列表失败，请重试！';
      }
    },

    formatDateTime(dateTime) {
      // 假设submitTime为一个日期数组格式，如[2024,12,20,10,30]
      if (Array.isArray(dateTime)) {
        const [year, month, day, hours, minutes] = dateTime;
        const date = new Date(year, month - 1, day, hours, minutes);
        return date.toLocaleString('zh-CN', {
          timeZone: 'Asia/Shanghai',
          hour12: false,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        }).replace(/\//g, '-');
      } else if (dateTime) {
        // 如果是标准Date字符串或其他格式，视情况处理
        const date = new Date(dateTime);
        return date.toLocaleString('zh-CN', {
          timeZone: 'Asia/Shanghai',
          hour12: false,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        }).replace(/\//g, '-');
      } else {
        return '无效日期';
      }
    },

    openGradeModal(submission) {
      this.selectedSubmission = submission;
      this.gradeScore = submission.score || 0;
      this.gradeComment = submission.comment || '';
      this.gradeError = null;
      this.showGradeModal = true;
    },

    closeGradeModal() {
      this.showGradeModal = false;
    },

    async gradeSubmission() {
      if (this.gradeScore === null || this.gradeScore < 0) {
        this.gradeError = '请填写有效的分数';
        return;
      }

      try {
        const response = await axios.post(
            `http://localhost:8080/assignments/${this.assignment.assignmentId}/submissions/${this.selectedSubmission.submissionId}/grade`,
            {
              score: this.gradeScore,
              comment: this.gradeComment
            }
        );

        if (response.data && response.data.code === '0') {
          const updatedSubmission = response.data.data;
          const index = this.submissions.findIndex(s => s.submissionId === updatedSubmission.submissionId);
          if (index !== -1) {
            this.submissions.splice(index, 1, updatedSubmission);
          }
          alert('批改成功！');
          this.closeGradeModal();
        } else {
          this.gradeError = response.data.msg || '批改失败，请重试！';
        }
      } catch (error) {
        console.error('批改作业失败:', error);
        this.gradeError = '批改请求失败，请稍后重试。';
      }
    },

    downloadFile(submission) {
      // 根据后端接口下载附件ZIP文件
      // 通常为GET /assignments/{assignmentId}/submissions/{submissionId}/download
      const url = `http://localhost:8080/assignments/${this.assignment.assignmentId}/submissions/${submission.submissionId}/download`;
      window.open(url, '_blank');
    }
  }
};
</script>

<style scoped>
.submissions {
  margin: 20px;
  font-family: Arial, sans-serif;
  color: #333;
}

.submissions h2 {
  margin-bottom: 20px;
  font-size: 20px;
  font-weight: bold;
}

.submissions table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

.submissions th, .submissions td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}

.submissions th {
  background-color: #f9f9f9;
  font-weight: bold;
}

.actions-cell button {
  margin: 0 5px;
  padding: 5px 10px;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}

.download-btn {
  background-color: #007bff;
  color: #fff;
}

.download-btn:hover {
  background-color: #0056b3;
}

.grade-btn {
  background-color: #28a745;
  color: #fff;
}

.grade-btn:hover {
  background-color: #218838;
}

.error-message {
  color: red;
  margin-top: 10px;
}

/* Modal 样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background: #fff;
  padding: 20px;
  border-radius: 5px;
  width: 300px;
}

.modal-content h3 {
  margin-bottom: 15px;
}

.form-group {
  margin-bottom: 10px;
  display: flex;
  flex-direction: column;
  text-align: left;
}

.form-group label {
  margin-bottom: 5px;
}

.actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.confirm-btn, .cancel-btn {
  padding: 5px 10px;
  border: none;
  border-radius: 3px;
}

.confirm-btn {
  background-color: #28a745;
  color: #fff;
}

.confirm-btn:hover {
  background-color: #218838;
}

.cancel-btn {
  background-color: #ccc;
}

.cancel-btn:hover {
  background-color: #aaa;
}
</style>
