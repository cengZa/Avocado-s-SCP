<template>
  <div class="modal-overlay" v-if="isOpen">
    <div class="modal-content">
      <h3>{{ hasSubmission ? '查看提交' : '提交作业' }}</h3>

      <!-- 如果已有提交，显示已提交信息 -->
      <div v-if="hasSubmission" class="submitted-info">
        <p>您已提交作业，提交时间：{{ formatDateTime(assignment.submission.submitTime) }}</p>
        <p v-if="assignment.submission.filePath">
          <button @click="downloadSubmission">下载已提交文件</button>
        </p>
        <p>若需再次提交可选择新文件：</p>
      </div>

      <form @submit.prevent="handleSubmit">
        <div class="form-group">
          <label for="files">上传文件（可选，多选）:</label>
          <input type="file" id="files" @change="handleFileChange" multiple />
        </div>

        <div class="form-actions">
          <!-- 若已提交则为“再次提交” -->
          <button type="submit" :disabled="isSubmitting">
            {{ hasSubmission ? '再次提交' : '提交' }}
          </button>
          <button type="button" @click="close">取消</button>
        </div>
      </form>

      <div v-if="isSubmitting" class="loading">提交中...</div>
      <div v-if="error" class="error-message">{{ error }}</div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'AssignmentModal',
  props: {
    isOpen: {
      type: Boolean,
      required: true
    },
    assignment: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      files: [],
      isSubmitting: false,
      error: null,
    };
  },
  computed: {
    hasSubmission() {
      return this.assignment && this.assignment.submission;
    }
  },
  methods: {
    handleFileChange(event) {
      const selectedFiles = Array.from(event.target.files);
      if (selectedFiles.length > 0) {
        const allowedTypes = [
          'image/jpeg',
          'image/png',
          'application/pdf',
          'text/plain',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'application/vnd.ms-excel',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'application/zip',
          'application/x-rar-compressed'
        ];
        const maxSize = 10 * 1024 * 1024; // 10MB
        for (const file of selectedFiles) {
          if (!allowedTypes.includes(file.type)) {
            this.error = `不支持的文件类型: ${file.name}`;
            this.files = [];
            return;
          }
          if (file.size > maxSize) {
            this.error = `文件大小超过限制（10MB）: ${file.name}`;
            this.files = [];
            return;
          }
        }
        this.files = selectedFiles;
        this.error = null;
      } else {
        this.files = [];
      }
    },
    async handleSubmit() {
      this.isSubmitting = true;
      this.error = null;
      try {
        const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
        const formData = new FormData();
        formData.append('studentId', userInfo.id);
        formData.append('assignmentId', this.assignment.assignmentId);
        if (this.files.length > 0) {
          this.files.forEach(file => {
            formData.append('files', file);
          });
        }

        const response = await axios.post(
            `http://localhost:8080/assignments/${this.assignment.assignmentId}/submissions`,
            formData,
            { headers: { 'Content-Type': 'multipart/form-data' } }
        );

        if (response.data && response.data.code === '0') {
          alert('提交成功！');
          // 通知父组件刷新作业列表或状态
          this.$emit('submit', { files: this.files, assignmentId: this.assignment.assignmentId });
        } else {
          this.error = response.data.msg || '提交失败，请重试！';
        }
      } catch (err) {
        console.error('提交作业失败:', err);
        alert('提交失败 ' + err)
        this.error = err.response?.data?.msg || '提交作业失败，请重试！';
      } finally {
        this.isSubmitting = false;
      }
    },
    close() {
      this.$emit('close');
      this.files = [];
      this.error = null;
    },
    formatDateTime(dateTime) {
      if (Array.isArray(dateTime)) {
        const [year, month, day, hours, minutes] = dateTime;
        const date = new Date(year, month - 1, day, hours, minutes);
        return date.toLocaleString('zh-CN', {
          timeZone: 'Asia/Shanghai',
          hour12: false,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        }).replace(/\//g, '-');
      } else if (dateTime) {
        const date = new Date(dateTime);
        return date.toLocaleString('zh-CN', {
          timeZone: 'Asia/Shanghai',
          hour12: false,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        }).replace(/\//g, '-');
      } else {
        return '无效日期';
      }
    },
    downloadSubmission() {
      const submissionId = this.assignment.submission.submissionId;
      const assignmentId = this.assignment.assignmentId;
      const url = `http://localhost:8080/assignments/${assignmentId}/submissions/${submissionId}/download`;
      window.open(url, '_blank');
    }
  }
};
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.modal-content {
  background: #fff;
  padding: 20px;
  border-radius: 5px;
  width: 400px;
}

.form-group {
  margin-bottom: 15px;
  display: flex;
  flex-direction: column;
  text-align: left;
}

.form-group label {
  margin-bottom: 5px;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.error-message {
  color: red;
  margin-top: 10px;
}

.loading {
  color: #333;
  margin-top: 10px;
}

.submitted-info {
  margin-bottom: 10px;
}

.submitted-info p {
  margin: 5px 0;
}
</style>
