<template>
  <div class="peer-review-teacher-view">
    <h2 v-if="assignment" class="assignment-title">{{ assignment.title }} 的互评结果</h2>
    <div v-else class="loading">加载中...</div>
    <div v-if="error" class="error">{{ error }}</div>
    <table v-if="peerReviews.length > 0">
      <thead>
      <tr>
        <th>Review ID</th>
        <th>提交ID</th>
        <th>互评者ID</th>
        <th>互评者姓名</th>
        <th>分数</th>
        <th>评语</th>
        <th>互评时间</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="review in peerReviews" :key="review.reviewId">
        <td>{{ review.reviewId }}</td>
        <td>{{ review.submissionId }}</td>
        <td>{{ review.reviewerId }}</td>
        <td>{{ review.reviewerName }}</td>
        <td>{{ review.score }}</td>
        <td>{{ review.comment }}</td>
        <td>{{ formatDateTime(review.reviewTime) }}</td>
      </tr>
      </tbody>
    </table>
    <div v-if="peerReviews.length === 0 && !error && assignment">
      暂无互评信息
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import { ElMessage } from 'element-plus';

export default {
  name: 'TeacherPeerReviewView',
  data() {
    return {
      assignment: null,
      peerReviews: [],
      error: null
    };
  },
  created() {
    this.fetchAssignmentAndPeerReviews();
  },
  methods: {
    async fetchAssignmentAndPeerReviews() {
      const { classId, assignmentId } = this.$route.params;
      try {
        // 获取作业详情
        const assignmentResponse = await axios.get(`http://localhost:8080/assignments/${assignmentId}`);
        if (assignmentResponse.data && assignmentResponse.data.code === '0') {
          this.assignment = assignmentResponse.data.data;
          console.log("assignmentResponse.data", assignmentResponse.data);
        } else {
          this.error = assignmentResponse.data.msg || '获取作业详情失败';
          return;
        }

        // 获取互评信息
        const peerReviewResponse = await axios.get(`http://localhost:8080/assignments/${assignmentId}/peer-reviews`);
        if (peerReviewResponse.data && peerReviewResponse.data.code === '0') {
          this.peerReviews = peerReviewResponse.data.data;
          console.log("peerReviewResponse: ", peerReviewResponse.data);
        } else {
          this.error = peerReviewResponse.data.msg || '获取互评信息失败';
        }
      } catch (err) {
        console.error(err);
        this.error = '获取互评信息失败，请稍后重试';
      }
    },
    formatDateTime(dateTime) {
      if (!dateTime) return '无';
      const date = new Date(dateTime);
      return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
    }
  }
};
</script>

<style scoped>
.peer-review-teacher-view {
  padding: 20px;
  font-family: Arial, sans-serif;
}

.assignment-title {
  font-size: 24px;
  color: #00509e;
  margin-bottom: 20px;
}

.loading {
  font-size: 18px;
  color: #555;
}

.error {
  color: red;
  margin-bottom: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

thead th {
  background: #f2f2f2;
  padding: 8px;
}

tbody td {
  padding: 8px;
  border-bottom: 1px solid #ddd;
}
</style>
