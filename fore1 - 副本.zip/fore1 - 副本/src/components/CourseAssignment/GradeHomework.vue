<template>
  <div class="grade-homework">
    <h2>批改作业</h2>
    <table>
      <thead>
      <tr>
        <th>作业标题</th>
        <th>作业截止时间</th>
        <th>操作</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="(homework, index) in homeworks" :key="index">
        <td>{{ homework.title }}</td>
        <td>{{ formatDate(homework.endTime) }}</td>
        <td>
          <button @click="goToGradeAssignments(homework)">查看作业提交情况</button>
        </td>
      </tr>
      </tbody>
    </table>

    <!-- 可以添加加载状态或错误提示 -->
    <div v-if="loading">正在加载...</div>
    <div v-if="error">{{ error }}</div>
  </div>
</template>
<script>
import axios from 'axios'; // 确保已安装并引入axios

export default {
  data() {
    return {
      homeworks: [],
      loading: false,
      error: null,
      classId: null,
      studentId: null,
    };
  },

  created() {
    this.classId = this.$route.params.classId;
    this.teacherId = this.$route.params.teacherId || 4; // 如果没有在路由中传递studentId，可以默认设置为1或其他值
    this.fetchPendingAssignments();
  },

  methods: {
    async fetchPendingAssignments() {
      this.loading = true;

      try {
        const response = await axios.get(
            `http://localhost:8080/assignments/pending`,
            {
              params: {
                teacherId: this.teacherId, // 使用教师 ID 获取作业
              },
            }
        );

        console.log(response.data);
        console.log(this.teacherId);
        console.log(this.studentId);
        if (response.data && response.data.code === "0") {
          this.homeworks = response.data.data; // 假设成功返回的数据在data字段中
        } else {
          this.error = '无法获取作业列表';
        }
      } catch (err) {
        console.error(err);
        this.error = '请求失败，请稍后重试';
      } finally {
        this.loading = false;
      }
    },

    goToGradeAssignments(homework) {
      this.$emit('grade-assignment-selected', homework);
    },

    formatDate(dateArray) {
      if (Array.isArray(dateArray)) {
        const [year, month, day, hours, minutes] = dateArray;
        const date = new Date(year, month - 1, day, hours, minutes);
        const options = {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
        };
        return date.toLocaleString('zh-CN', options);
      } else if (dateArray) {
        const date = new Date(dateArray);
        const options = {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
        };
        return date.toLocaleString('zh-CN', options);
      } else {
        return '无效日期';
      }
    },
  },
};
</script>
<style scoped>
.grade-homework {
  padding: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

thead th,
tbody td {
  border-bottom: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}

.details {
  margin-top: 10px;
}
</style>
