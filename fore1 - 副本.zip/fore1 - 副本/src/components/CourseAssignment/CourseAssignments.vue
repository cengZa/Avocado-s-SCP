<template>
  <div class="assignments">
    <h2>作业管理</h2>
    <table>
      <thead>
      <tr>
        <th>作业标题</th>
        <th>开始时间</th>
        <th>截止时间</th>
        <th>提交人数</th>
        <th v-if="isStudent">提交时间</th>
        <th v-if="isStudent">得分</th>
        <th v-if="isStudent">批改状态</th>
        <th>状态</th> <!-- 新增状态列 -->
        <th>操作</th>
      </tr>
      </thead>

      <tbody>
      <tr v-for="(assignment, index) in assignments" :key="assignment.assignmentId">
        <td @click="viewAssignment(assignment)" class="assignment-title">{{ assignment.title }}</td>
        <td>{{ formatDateTime(assignment.startTime) }}</td>
        <td>{{ formatDateTime(assignment.endTime) }}</td>
        <td>{{ isTeacher ? assignment.submittedCount : (assignment.submission ? 1 : 0) }}</td>
        <td v-if="isStudent">{{ assignment.submission ? formatDateTime(assignment.submission.submitTime) : '未提交' }}</td>
        <td v-if="isStudent">{{ assignment.submission && assignment.submission.score !== null ? assignment.submission.score : '未评分' }}</td>
        <td v-if="isStudent">{{ assignment.submission && assignment.submission.status ? assignment.submission.status : '未批改' }}</td>
        <td>{{ getDisplayStatus(assignment) }}</td> <!-- 显示覆盖后的状态 -->
        <td>
          <button v-if="isStudent" @click.stop="openModal(assignment)">
            {{ assignment.submission ? '查看提交' : '提交作业' }}
          </button>
          <button v-if="isTeacher" @click.stop="submissionsDetail(assignment)">
            提交情况
          </button>
          <!-- 教师查看互评结果按钮 -->
          <button v-if="isTeacher && assignment.isPeerReview" @click.stop="viewPeerReviewResults(assignment)">
            查看互评结果
          </button>
          <!-- 学生查看互评入口 -->
          <button v-if="isStudent && assignment.isPeerReview && isPeerReviewTime(assignment)" @click.stop="viewPeerReview(assignment)">
            互评
          </button>
          <button v-if="isTeacher" @click.stop="deleteAssignment(assignment)" class="delete-button">
            删除作业
          </button>
        </td>
      </tr>
      </tbody>
    </table>

    <!-- Assignment Modal for submission -->
    <AssignmentModal
        v-if="role === 'Student' && isModalOpen"
        :isOpen="isModalOpen"
        :assignment="currentAssignment"
        @close="closeModal"
        @submit="handleSubmission"
    />
  </div>
</template>

<script>
import AssignmentModal from './AssignmentModal.vue';
import axios from 'axios';

export default {
  name: 'CourseAssignments',

  components: {
    AssignmentModal
  },

  data() {
    return {
      assignments: [],
      isModalOpen: false,
      currentAssignment: {},
      userId: null,
      classId: null,
      role: null
    };
  },

  computed:{
    isStudent() {
      return this.role === 'Student';
    },
    isTeacher() {
      return this.role === 'Teacher';
    }
  },

  created() {
    // 获取用户信息
    const userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    if (userInfo) {
      this.userId = userInfo.id;
      this.role = userInfo.role;
    }

    const selectedCourse = JSON.parse(sessionStorage.getItem('selectedCourse'));
    if (selectedCourse) {
      this.classId = selectedCourse.classId;
    }

    this.fetchAssignments();
  },

  methods: {
    async fetchAssignments() {
      try {

        let response;
        if (this.isStudent) {
          // 学生获取班级下的作业列表
          response = await axios.get(
              `http://localhost:8080/assignments/class/${this.classId}/student/${this.userId}`
          );
        } else if (this.isTeacher) {
          // 教师获取班级下自己发布的作业列表
          response = await axios.get(
              `http://localhost:8080/assignments/class/${this.classId}/publisher/${this.userId}`
          );
        } else {
          // 其他角色，暂不处理
          console.error('未知的用户角色');
          return;
        }

        console.log('fetch 中 response.data =', response.data);

        if (response.data && response.data.code === '0') {
          this.assignments = response.data.data;
        } else {
          console.error('获取作业失败:', response.data.msg);
          alert('获取作业失败，请重试！');
        }
      } catch (error) {
        console.error('获取作业失败:', error);
        alert('获取作业失败，请重试！');
      }
    },

    viewAssignment(assignment) {
      this.$emit('homework-selected', assignment);
      console.log(assignment);
    },

    openModal(assignment) {
      console.log('打开模态框:', assignment);
      this.currentAssignment = assignment;
      this.isModalOpen = true;
    },

    closeModal() {
      this.isModalOpen = false;
    },

    handleSubmission() {
      this.fetchAssignments();
      this.closeModal();
    },

    submissionsDetail(assignment) {
      this.$emit('submissionsDetail', assignment)
    },

    formatDateTime(dateTime) {
      const date = new Date(dateTime[0], dateTime[1] - 1, dateTime[2], dateTime[3], dateTime[4]);

      const formatter = new Intl.DateTimeFormat('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      });

      return formatter.format(date).replace(/\//g, '-');  // 将斜杠替换为横线，符合 YYYY-MM-DD 格式
    },

    async deleteAssignment(assignment){
      // 确认删除
      if (!confirm(`确定要删除作业 "${assignment.title}" 吗？此操作不可撤销。`)) {
        return;
      }
      try {
        const response = await axios.delete(
            `http://localhost:8080/assignments/${assignment.assignmentId}/publisher/${this.userId}`
        );

        if (response.data && response.data.code === '0') {
          alert('作业删除成功！');
          // 更新作业列表
          await this.fetchAssignments();
        } else {
          alert(response.data.msg || '删除作业失败，请重试！');
        }
      } catch (error) {
        console.error('删除作业失败:', error);
        alert('删除作业失败，请重试！');
      }
    },

    viewPeerReviewResults(assignment) {
      // 假设路由定义了 /course/:classId/assignments/:assignmentId/peer-review-results
      this.$router.push({
        name: 'TeacherPeerReviewView',
        params: { classId: this.classId, assignmentId: assignment.assignmentId }
      });
    },
    viewPeerReview(assignment) {
      // 假设路由定义了 /course/:classId/assignments/:assignmentId/peer-review
      this.$router.push({
        name: 'StudentPeerReview',
        params: { classId: this.classId, assignmentId: assignment.assignmentId }
      });
    },
    isPeerReviewTime(assignment) {
      console.log("in isPeerReviewTime", assignment);
      console.log("isPeerReview?" + assignment.isPeerReview);
      if (!assignment.isPeerReview) return false;

      const now = new Date();
      const endTime = new Date(assignment.endTime);
      const peerReviewDeadline = assignment.peerReviewDeadline ? new Date(assignment.peerReviewDeadline) : null;

      if (!peerReviewDeadline) {
        // 如果没有互评截止时间，默认互评期为作业截止后的24小时
        const defaultPeerReviewDeadline = new Date(endTime.getTime() + 24 * 60 * 60 * 1000);
        return now > endTime && now < defaultPeerReviewDeadline;
      }

      return now > endTime && now < peerReviewDeadline;
    },
    /**
     * 获取显示的状态，覆盖特定条件下的状态为“已完成”
     */
    getDisplayStatus(assignment) {
      // 优先检查作业是否已经截止或完成
      const now = new Date();
      const endTime = new Date(assignment.endTime);
      const peerReviewDeadline = assignment.peerReviewDeadline ? new Date(assignment.peerReviewDeadline) : null;

      // 判断是否已经过互评截止时间
      const isAfterPeerReviewDeadline = peerReviewDeadline ? now > peerReviewDeadline : false;

      // 如果作业已经截止或互评已经结束，无论其他状态如何，都显示“已完成”
      if (now > endTime && (peerReviewDeadline === null || now > peerReviewDeadline)) {
        return '已完成';
      }

      // 否则，显示实际状态
      return assignment.status;
    }

  }
};
</script>


<style scoped>
.assignments {
  margin: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

thead th {
  background-color: #f2f2f2;
  padding: 8px;
}

tbody td {
  padding: 8px;
  border-bottom: 1px solid #ddd;
}

.assignment-title {
  cursor: pointer;
  color: #007bff;
}

.assignment-title:hover {
  text-decoration: underline;
}

.delete-button {
  background-color: #dc3545;
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
  margin-left: 5px;
}

.delete-button:hover {
  background-color: #c82333;
}

</style>
