<template>
  <div class="assignment-details">
    <h2>{{ assignment.title }}</h2>

    <div class="assignment-content">
      <p class="description">{{ assignment.description }}</p>

      <!-- 显示下载链接 -->
      <div class="attachments">
        <h4>作业附件</h4>
        <button @click="downloadAttachments" :disabled="isDownloading">
          {{ isDownloading ? '下载中...' : '下载附件压缩包' }}
        </button>
      </div>

      <!-- 开始时间和截止时间 -->
      <div class="submission-time">
        <p>
          <strong>开始时间：</strong>
          {{ formatDate(assignment.startTime) }}
        </p>
        <p>
          <strong>截止时间：</strong>
          {{ formatDate(assignment.endTime) }}
        </p>
      </div>
    </div>

    <!-- 互评规则和截止日期 -->
    <div v-if="assignment.isPeerReview" class="peer-review-rules">
      <h4>互评规则</h4>
      <p>
        <strong>互评次数：</strong>
        {{ assignment.peerReviewCount }}
      </p>
      <p>
        <strong>互评分数范围：</strong>
        {{ assignment.peerReviewMinScore || 0 }} - {{ assignment.peerReviewMaxScore || 100 }}
      </p>
      <p>
        <strong>互评截止时间：</strong>
        {{ formatDate(assignment.peerReviewDeadline) }}
      </p>
    </div>
  </div>

    <!-- 错误处理 -->
    <div v-if="error" class="error-message">{{ error }}</div>

</template>

<script>
import axios from "axios";

export default {
  props: {
    assignment: {
      type: Object,
      required: true
    }
  },

  data() {
    return {
      error: null,
      isDownloading: false
    };
  },

  computed: {
    downloadUrl() {
      return `http://localhost:8080/assignments/${this.assignment.assignmentId}/attachments/download`;
    }
  },

  created() {
    console.log("assignment", this.assignment);
  },
  methods: {
    formatDate(dateArray) {
      if (Array.isArray(dateArray)) {
        const [year, month, day, hours, minutes] = dateArray;
        const date = new Date(year, month - 1, day, hours, minutes);
        return date.toLocaleString('zh-CN', {
          timeZone: 'Asia/Shanghai',
          hour12: false,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        });
      } else if (dateArray) {
        const date = new Date(dateArray);
        return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
      } else {
        return '无效日期';
      }
    },
    async downloadAttachments() {
      this.error = null;
      this.isDownloading = true;

      try {
        const response = await axios.get(this.downloadUrl, {
          responseType: 'blob' // 接收二进制数据
        });

        // 创建一个URL对象并触发下载
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'attachments.zip'); // 设置下载文件名
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (err) {
        console.error('下载附件失败:', err);
        if (err.response && err.response.data && err.response.data.msg) {
          this.error = `下载失败：${err.response.data.msg}`;
        } else if (err.message) {
          this.error = `下载失败：${err.message}`;
        } else {
          this.error = '下载附件失败！';
        }
      } finally {
        this.isDownloading = false;
      }
    }
  }
};
</script>
<style scoped>
.assignment-details {
  margin: 20px auto;
  max-width: 800px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
}

.assignment-details h2 {
  margin-bottom: 20px;
  font-size: 28px;
  color: #333;
  text-align: center;
}

.assignment-content {
  line-height: 1.6;
  color: #555;
}

.description {
  font-size: 16px;
  margin-bottom: 20px;
}

.attachments {
  margin-bottom: 20px;
}

.attachments h3 {
  font-size: 20px;
  margin-bottom: 10px;
}

.attachments a {
  display: inline-block;
  padding: 10px 15px;
  background-color: #007BFF;
  color: #fff;
  text-decoration: none;
  border-radius: 4px;
}

.submission-time {
  font-size: 14px;
  color: #777;
}

.submission-time p {
  margin: 5px 0;
}

.error-message {
  color: red;
  font-weight: bold;
  text-align: center;
  margin-top: 20px;
}
.peer-review-rules {
  margin-top: 20px;
  padding: 15px;
  background-color: #f8f9fa;
  border-left: 4px solid #17a2b8;
  border-radius: 4px;
}

.peer-review-rules h4 {
  font-size: 20px;
  margin-bottom: 10px;
  color: #17a2b8;
}

.peer-review-rules p {
  margin: 5px 0;
}

</style>
