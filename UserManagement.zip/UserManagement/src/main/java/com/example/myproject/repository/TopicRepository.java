package com.example.myproject.repository;

import com.example.myproject.model.Topic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * TopicRepository接口，继承JpaRepository，提供对Topic实体的CRUD操作。
 */
@Repository
public interface TopicRepository extends JpaRepository<Topic, Long> {

    /**
     * 根据帖子ID查找主题列表。
     * @param postId 帖子ID
     * @return List<Topic>
     */
    List<Topic> findByPost_PostId(Long postId);

    /**
     * 根据主题名称或标签进行模糊搜索。
     * @param topicName 主题名称关键词
     * @param tags 标签关键词
     * @return List<Topic>
     */
    List<Topic> findByTopicNameContainingOrTagsContaining(String topicName, String tags);
}
