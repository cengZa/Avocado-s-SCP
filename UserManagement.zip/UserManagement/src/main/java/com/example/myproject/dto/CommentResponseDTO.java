package com.example.myproject.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
@Setter
@Getter
/**
 * 用于返回评论信息的响应数据传输对象。
 */
public class CommentResponseDTO {

    private Long commentId;
    private Long topicId;
    private Long commenterId;
    private String content;
    private Instant commentTime;

}
