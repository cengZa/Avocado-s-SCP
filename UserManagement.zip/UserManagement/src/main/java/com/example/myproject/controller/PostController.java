package com.example.myproject.controller;

import com.example.myproject.dto.PostDTO;
import com.example.myproject.dto.PostResponseDTO;
import com.example.myproject.service.PostService;
import com.example.myproject.utils.Result;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * 帖子管理接口，处理与Post相关的HTTP请求。
 */
@RestController
@RequestMapping("/posts")
@Api(value = "帖子管理接口", tags = {"帖子管理"})
public class PostController {

    @Autowired
    private PostService postService;

    /**
     * 创建帖子（讨论区）。
     * 仅教师可以创建帖子。
     *
     * @param postDTO 包含班级ID和教师ID的请求数据
     * @return Result<PostResponseDTO>
     */
    @PostMapping("/create")
    @ApiOperation(value = "创建帖子", notes = "仅教师可以创建帖子")
    public Result createPost(
            @RequestBody @Valid @ApiParam(value = "帖子信息", required = true) PostDTO postDTO) {
        PostResponseDTO postresponseDTO = postService.createPost(postDTO.getClassId(), postDTO.getTeacherId());
        return Result.success(postresponseDTO, "帖子创建成功");

    }

    /**
     * 根据班级ID获取帖子。
     *
     * @param classId 班级ID
     * @return Result<PostResponseDTO>
     */
    @GetMapping("/class/{classId}")
    @ApiOperation(value = "获取帖子", notes = "根据班级ID获取帖子")
    public Result getPostByClassId(@PathVariable Long classId) {
        return postService.getPostByClassId(classId)
                .map(Result::success)
                .orElseGet(() -> Result.error("404", "帖子不存在"));
    }

    /**
     * 删除帖子
     * 仅教师可以删除帖子。只有教师的前端有这个按钮就好了
     *
     * @param postId 帖子ID
     * @return Result
     */
    @DeleteMapping("/{postId}")
    @ApiOperation(value = "删除帖子", notes = "仅教师可以删除帖子，只有教师的前端有这个按钮就好了")
    public Result deletePost(@PathVariable Long postId) {
        postService.deletePost(postId);
        return Result.success(null, "帖子删除成功");
    }
}
