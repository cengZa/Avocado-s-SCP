package com.example.myproject.controller;


import com.alibaba.fastjson.JSON;
import com.example.myproject.model.Assignment;
import com.example.myproject.model.AssignmentAttachment;
import com.example.myproject.service.AssignmentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@Api(tags = "作业管理")
@RestController
@RequestMapping("/assignments")
public class AssignmentController {

  @Autowired
  private AssignmentService assignmentService;

 @PostMapping("/create-assignment")
  public ResponseEntity<Assignment> createAssignment(
    @Valid @RequestPart("assignment")String assignment,
    @RequestPart(value = "attachments", required = false) MultipartFile[] attachments) throws IOException {
   System.out.println(assignment);
   Assignment assignment1 = JSON.parseObject(assignment, Assignment.class);
   System.out.println(assignment1);
    // 调用服务层处理上传的作业及附件
    Assignment createdAssignment = assignmentService.createAssignment(assignment1, attachments);
    return ResponseEntity.ok(createdAssignment);
  }

//  @ApiOperation(value = "根据ID获取作业")
//  @GetMapping("/{id}")
//  public ResponseEntity<Assignment> getAssignmentById(@PathVariable Long id) {
//    Assignment assignment = assignmentService.getAssignmentById(id);
//    return ResponseEntity.ok(assignment);
//  }
//
//  @ApiOperation(value = "更新作业")
//  @PutMapping("/{id}")
//  public ResponseEntity<Assignment> updateAssignment(@PathVariable Long id, @RequestBody Assignment assignment) {
//    Assignment updatedAssignment = assignmentService.updateAssignment(id, assignment);
//    return ResponseEntity.ok(updatedAssignment);
//  }
//
//  @ApiOperation(value = "删除作业")
//  @DeleteMapping("/{id}")
//  public ResponseEntity<Void> deleteAssignment(@PathVariable Long id) {
//    assignmentService.deleteAssignment(id);
//    return ResponseEntity.noContent().build();
//  }
}
