package com.example.myproject.service;

import com.example.myproject.dto.PostResponseDTO;
import com.example.myproject.model.Post;

import java.util.Optional;

/**
 * PostService接口，定义帖子相关的业务方法。
 */
public interface PostService {

    /**
     * 创建帖子（讨论区）。
     * @param classId 班级ID
     * @param teacherId 教师ID
     * @return 创建的Post对象
     */
    PostResponseDTO createPost(Long classId, Long teacherId);

    /**
     * 根据班级ID获取帖子。
     * @param classId 班级ID
     * @return Optional<Post>
     */
    Optional<PostResponseDTO> getPostByClassId(Long classId);

    /**
     * 删除帖子。
     * @param postId 帖子ID
     */
    void deletePost(Long postId);
}
