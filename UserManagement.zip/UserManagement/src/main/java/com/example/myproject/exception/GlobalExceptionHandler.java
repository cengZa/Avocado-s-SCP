package com.example.myproject.exception;

import com.example.myproject.utils.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.*;

/**
 * 全局异常处理器，捕获并处理全局的异常。
 */
@RestControllerAdvice  // 标记为全局异常处理器
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * 处理自定义的业务异常。
     */
    @ExceptionHandler(BaseException.class)
    @ResponseStatus(HttpStatus.OK)  // 设置HTTP状态码为200，表示请求成功，但业务处理有错误
    public Result handleBaseException(BaseException ex) {
        logger.error("业务异常：{}", ex.getMessage());
        return Result.error(ex.getCode(), ex.getMessage());
    }

    /**
     * 处理参数校验异常。
     */
    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result handleBindException(BindException ex) {
        String errorMessage = ex.getBindingResult().getFieldError().getDefaultMessage();
        logger.error("参数校验异常：{}", errorMessage);
        return Result.error("400", errorMessage);
    }

    /**
     * 处理其他未捕获的异常。
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result handleException(Exception ex) {
        logger.error("系统异常：", ex);
        return Result.error("500", "系统内部错误");
    }
}
