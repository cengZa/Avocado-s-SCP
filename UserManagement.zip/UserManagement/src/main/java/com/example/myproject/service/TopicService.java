package com.example.myproject.service;

import com.example.myproject.dto.TopicResponseDTO;
import com.example.myproject.model.Topic;

import java.util.List;

/**
 * TopicService接口，定义主题相关的业务方法。
 */
public interface TopicService {

    /**
     * 创建主题。
     * @param postId 帖子ID
     * @param topicerId 主题发起人ID
     * @param topicName 主题名称
     * @param tags 标签（可选）
     * @return TopicResponseDTO对象
     */
    TopicResponseDTO createTopic(Long postId, Long topicerId, String topicName, String tags);

    /**
     * 根据帖子ID获取主题列表。
     * @param postId 帖子ID
     * @return List<TopicResponseDTO>
     */
    List<TopicResponseDTO> getTopicsByPostId(Long postId);

    /**
     * 根据关键词搜索主题。
     * @param keyword 搜索关键词
     * @return List<Topic>
     */
    List<TopicResponseDTO> searchTopics(String keyword);

    /**
     * 删除主题。
     * @param topicId 主题ID
     */
    void deleteTopic(Long topicId);
}
