package com.example.myproject.service;

import com.example.myproject.model.Resource;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public interface ResourceService {
  void createClassFolder(Long classId);

   void createSubFolder(Long classId, Long parentFolderId, String folderName);

 void uploadFiles(Long classId, Long parentFolderId, List<MultipartFile> files) throws IOException ;
  boolean isFileExists(String folderPath, String fileName);
  // 获取班级文件夹结构
  List<Resource> getFolderStructure(Long classId);
  //获取一个文件夹下的子文件夹
  List<Resource> getSubFolder(Long parentFolderId);
  // 获取特定文件夹内容
 List<Resource> getFolderFiles(Long parentFolderId);
  void downloadFile(Long fileId, HttpServletResponse response) throws IOException;
  boolean deleteFile(Long fileId) ;

   List<Resource> searchFilesInFolder(Long parentFolderId, String searchTerm);



}
