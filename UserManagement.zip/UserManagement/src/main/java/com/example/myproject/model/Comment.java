package com.example.myproject.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

/**
 * Comment实体类，表示评论。
 */
@Getter
@Setter
@Entity  // 指定这是一个实体类，映射到数据库表
@Table(name = "comment")  // 指定数据库表名为 "comment"
public class Comment {

    @Id  // 指定主键
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // 主键生成策略为自增
    private Long commentId;  // 评论ID

    /**
     * 与Topic实体的多对一关系，一个评论属于一个主题。
     */
    @ManyToOne  // 多对一关系，多条评论对应一个主题
    @JoinColumn(name = "topic_id")  // 外键列名为 "topic_id"
    private Topic topic;  // 所属的主题

    /**
     * 与User实体的多对一关系，评论人。
     */
    @ManyToOne  // 多对一关系，多条评论对应一个用户
    @JoinColumn(name = "commenter_id")  // 外键列名为 "commenter_id"
    private User commenter;  // 评论人

    @Lob  // 指定大对象类型，用于存储大型文本
    private String content;  // 评论内容

    private Instant commentTime;  // 评论时间

    /**
     * 无参构造函数，初始化评论时间为当前时间。
     */
    public Comment() {
        this.commentTime = Instant.now();
    }

}