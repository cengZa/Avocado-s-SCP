package com.example.myproject.controller;

import com.example.myproject.dto.CommentDTO;
import com.example.myproject.dto.CommentResponseDTO;
import com.example.myproject.service.CommentService;
import com.example.myproject.utils.Result;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * 评论管理接口，处理与Comment相关的HTTP请求。
 */
@RestController
@RequestMapping("/comments")
@Api(value = "评论管理接口", tags = {"评论管理"})
public class CommentController {

    @Autowired
    private CommentService commentService;

    /**
     * 创建评论。
     * 学生和教师都可以创建评论。
     *
     * @param commentDTO 包含主题ID、评论人ID和评论内容的请求数据
     * @return Result<CommentResponseDTO>
     */
    @PostMapping("/create")
    @ApiOperation(value = "创建评论", notes = "学生和教师都可以创建评论")
    public Result createComment(
            @RequestBody @Valid @ApiParam(value = "评论信息", required = true) CommentDTO commentDTO) {

        System.out.println(commentDTO);

        CommentResponseDTO commentResponseDTO = commentService.createComment(
                commentDTO.getTopicId(),
                commentDTO.getCommenterId(),
                commentDTO.getContent()
        );
        return Result.success(commentResponseDTO, "评论创建成功");
    }


    /**
     * 根据主题ID获取评论列表。
     *
     * @param topicId 主题ID
     * @return Result<List<CommentResponseDTO>>
     */
    @GetMapping("/topic/{topicId}")
    @ApiOperation(value = "获取评论列表", notes = "根据主题ID获取评论列表")
    public Result getCommentsByTopicId(@PathVariable Long topicId) {
        List<CommentResponseDTO> comments = commentService.getCommentsByTopicId(topicId);
        return Result.success(comments);
    }

    /**
     * 删除评论。
     * 仅教师可以删除评论。
     *
     * @param commentId 评论ID
     * @return Result
     */
    @DeleteMapping("/{commentId}")
    @ApiOperation(value = "删除评论", notes = "仅教师可以删除评论")
    public Result deleteComment(@PathVariable Long commentId) {
        commentService.deleteComment(commentId);
        return Result.success(null, "评论删除成功");
    }
}
