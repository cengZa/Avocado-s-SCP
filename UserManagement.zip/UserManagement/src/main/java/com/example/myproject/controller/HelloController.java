package com.example.myproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ask")
public class HelloController {
  @GetMapping("/hello")

  public String hello() {
    return "I am Jack";
  }
}
