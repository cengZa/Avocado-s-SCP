package com.example.myproject.repository;

import com.example.myproject.model.AssignmentAttachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssignmentAttachmentRepository extends JpaRepository<AssignmentAttachment, Long> {

  // 根据作业ID查询附件
  List<AssignmentAttachment> findByAssignmentId(Long assignmentId);
}
