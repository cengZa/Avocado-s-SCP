package com.example.myproject.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Setter
@Getter
/**
 * 用于返回主题信息的响应数据传输对象。
 */
public class TopicResponseDTO {

    private Long topicId;
    private Long postId;
    private Long topicerId;
    private String topicName;
    private String tags;
    private Instant topicTime;


}
