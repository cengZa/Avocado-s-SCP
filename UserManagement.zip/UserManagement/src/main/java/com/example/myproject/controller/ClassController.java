package com.example.myproject.controller;

import com.example.myproject.service.ClassService;
import com.example.myproject.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/classes")
public class ClassController {

    @Autowired
    private ClassService classService;

    @GetMapping("/{classId}")
    public Result getClassDetails(@PathVariable long classId) {
        return classService.getClassDetails(classId);
    }
    @GetMapping("/todayClass")
    public Result getTodayClassDetails(
            @RequestParam long userId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        return classService.getTodayClassDetails(userId, date);
    }



}
