package com.example.myproject.service;

public class SubmissionService {
}
