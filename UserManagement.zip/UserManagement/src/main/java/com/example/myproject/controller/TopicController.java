package com.example.myproject.controller;

import com.example.myproject.dto.TopicDTO;
import com.example.myproject.dto.TopicResponseDTO;
import com.example.myproject.model.Topic;
import com.example.myproject.service.TopicService;
import com.example.myproject.utils.Result;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * 主题管理接口，处理与Topic相关的HTTP请求。
 */
@RestController
@RequestMapping("/topics")
@Api(value = "主题管理接口", tags = {"主题管理"})
public class TopicController {

    @Autowired
    private TopicService topicService;

    /**
     * 创建主题。
     * 学生和教师都可以创建主题。
     *
     * @param topicDTO 包含帖子ID、发起人ID、主题名称和标签的请求数据
     * @return Result<TopicResponseDTO>
     */
    @PostMapping("/create")
    @ApiOperation(value = "创建主题", notes = "学生和教师都可以创建主题")
    public Result createTopic(
            @RequestBody @Valid @ApiParam(value = "主题信息", required = true) TopicDTO topicDTO) {

        TopicResponseDTO topicResponseDTO = topicService.createTopic(
                topicDTO.getPostId(),
                topicDTO.getTopicerId(),
                topicDTO.getTopicName(),
                topicDTO.getTags()
        );
        return Result.success(topicResponseDTO, "主题创建成功");
    }


    /**
     * 根据帖子ID获取主题列表。
     *
     * @param postId 帖子ID
     * @return Result<List<TopicResponseDTO>>
     */
    @GetMapping("/post/{postId}")
    @ApiOperation(value = "获取主题列表", notes = "根据帖子ID获取主题列表")
    public Result getTopicsByPostId(@PathVariable Long postId) {
        List<TopicResponseDTO> topics = topicService.getTopicsByPostId(postId);
        return Result.success(topics);
    }

    /**
     * 根据关键词搜索主题。
     *
     * @param keyword 搜索关键词
     * @return Result<List<TopicResponseDTO>>
     */
    @GetMapping("/search")
    @ApiOperation(value = "搜索主题", notes = "根据关键词搜索主题")
    public Result searchTopics(@RequestParam String keyword) {
        List<TopicResponseDTO> topics = topicService.searchTopics(keyword);
        return Result.success(topics);
    }

    /**
     * 删除主题。
     * 仅教师可以删除主题。
     *
     * @param topicId 主题ID
     * @return Result
     */
    @DeleteMapping("/{topicId}")
    @ApiOperation(value = "删除主题", notes = "仅教师可以删除主题")
    public Result deleteTopic(@PathVariable Long topicId) {
        topicService.deleteTopic(topicId);
        return Result.success(null, "主题删除成功");
    }
}
