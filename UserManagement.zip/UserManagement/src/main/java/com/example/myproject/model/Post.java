package com.example.myproject.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

/**
 * Post实体类，表示帖子。
 */
@Setter
@Getter
@Entity  // 指定该类为实体类，JPA会将其映射到数据库表
@Table(name = "post")  // 指定映射的表名为 "post"
public class Post {

    @Id  // 指定主键
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // 主键生成策略，自动递增
    private Long postId;  // 帖子ID

    // Getter 和 Setter 方法
    /**
     * 关联到班级实体，表示该帖子所属的班级。
     * 一对一关系：一个帖子对应一个班级
     */

    @OneToOne
    @JoinColumn(name = "class_id")  // 指定外键列名为 "class_id"
    private Class classEntity;

    /**
     * 发帖人（教师）。
     * 一对多关系：一个帖子对应一个发帖人
     */
    @ManyToOne
    @JoinColumn(name = "poster_id")  // 指定外键列名为 "poster_id"
    private User poster;

    /**
     * 发帖时间，使用Instant表示时间戳。
     */
    private Instant postTime;

    /**
     * 默认构造方法，在创建对象时自动设置postTime为当前时间。
     */
    public Post() {
        this.postTime = Instant.now();
    }

}
