package com.example.myproject.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

/**
 * Topic实体类，表示主题。
 */
@Setter
@Getter
@Entity  // 指定这是一个实体类，映射到数据库表
@Table(name = "topic")  // 指定数据库表名为 "topic"
public class Topic {

    @Id  // 指定主键
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // 主键生成策略为自增
    private Long topicId;  // 主题ID

    // Getter 和 Setter 方法
    /**
     * 与Post实体的多对一关系，一个主题属于一个帖子。
     */
    @Setter
    @ManyToOne  // 多对一关系，多篇主题对应一个帖子
    @JoinColumn(name = "post_id")  // 外键列名为 "post_id"
    private Post post;  // 所属的帖子

    /**
     * 与User实体的多对一关系，主题发起人。
     */
    @Setter
    @ManyToOne
    @JoinColumn(name = "topicer_id")  // 外键列名为 "topicer_id"
    private User topicer;  // 主题发起人

    @Setter
    private String topicName;  // 主题名称

    @Setter
    private String tags;  // 标签（关键词）

    private Instant topicTime;  // 主题创建时间

    /**
     * 无参构造函数，初始化主题创建时间为当前时间。
     */
    public Topic() {
        this.topicTime = Instant.now();
    }

}
