package com.example.myproject.service.serviceImpl;


import com.example.myproject.model.Assignment;
import com.example.myproject.model.AssignmentAttachment;
import com.example.myproject.model.Resource;
import com.example.myproject.repository.AssignmentAttachmentRepository;
import com.example.myproject.repository.AssignmentRepository;
import com.example.myproject.service.AssignmentService;
import com.example.myproject.utils.FilesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
public class AssignmentServiceImpl implements AssignmentService {

  private static final String UPLOAD_DIR = "D:/assignment/";
  @Autowired
  private AssignmentRepository assignmentRepository;
  @Autowired
  private AssignmentAttachmentRepository assignmentAttachmentRepository;
  @Override
  public Assignment createAssignment(Assignment assignment, MultipartFile[] attachments) throws IOException {
    assignmentRepository.save(assignment);
   String folderPath=UPLOAD_DIR+'/'+assignment.getClassId();
    File folder = new File(folderPath);
    if (attachments != null) {
      for (MultipartFile file : attachments) {
        String fileName = file.getOriginalFilename();
        if (!FilesUtil.isExtensionAllowed(fileName)) {
          throw new IOException("不支持的文件类型: " + FilesUtil.getFileExtension(fileName));
        }
        // 将文件写入目标文件
        File destFile = new File(folder, fileName);
        file.transferTo(destFile);
        // 处理文件保存，例如保存到文件系统或数据库
        AssignmentAttachment attachment = new AssignmentAttachment();
        attachment.setAssignment(assignment);
        String filePath=folderPath+'/'+fileName;
        attachment.setFilePath(filePath);
        assignmentAttachmentRepository.save(attachment);
      }
    }
    return assignment;
  }

//  @Override
//  public List<Assignment> getAllAssignments() {
//    return assignmentRepository.findAll();
//  }
//
//  @Override
//  public Assignment getAssignmentById(Long id) {
//    return assignmentRepository.findById(id)
//      .orElseThrow(() -> new RuntimeException("作业未找到"));
//  }
//
//  @Override
//  public Assignment updateAssignment(Long id, Assignment assignment) {
//    Assignment existingAssignment = getAssignmentById(id);
//    existingAssignment.setTitle(assignment.getTitle());
//    existingAssignment.setDescription(assignment.getDescription());
//    existingAssignment.setFullScore(assignment.getFullScore());
//    existingAssignment.setAllowResubmit(assignment.getAllowResubmit());
//    existingAssignment.setAllowMultipleSubmissions(assignment.getAllowMultipleSubmissions());
//    existingAssignment.setStartTime(assignment.getStartTime());
//    existingAssignment.setEndTime(assignment.getEndTime());
//    existingAssignment.setPublished(assignment.getPublished());
//    return assignmentRepository.save(existingAssignment);
//  }
//
//  @Override
//  public void deleteAssignment(Long id) {
//    assignmentRepository.deleteById(id);
//  }
}
