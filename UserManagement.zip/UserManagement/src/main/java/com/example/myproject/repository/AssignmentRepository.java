package com.example.myproject.repository;


import com.example.myproject.model.Assignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssignmentRepository extends JpaRepository<Assignment, Long> {

  // 根据班级ID查询作业
  List<Assignment> findByClassId(Long classId);

  // 根据ID查询作业
  Assignment findByIdAndClassId(Long id, Long classId);
}
