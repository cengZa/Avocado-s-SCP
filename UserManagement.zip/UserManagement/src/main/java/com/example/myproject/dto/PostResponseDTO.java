package com.example.myproject.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Setter
@Getter
/**
 * 用于返回帖子信息的响应数据传输对象。
 */
public class PostResponseDTO {

    private Long postId;
    private Long classId;
    private Long teacherId;
    private Instant postTime;


}
