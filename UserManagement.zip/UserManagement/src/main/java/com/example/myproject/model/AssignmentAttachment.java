package com.example.myproject.model;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
@Table(name = "assignment_attachments")
public class AssignmentAttachment {



  @Id
  @ApiModelProperty(value = "作业附件ID", example = "1")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id; // 附件ID



  @ManyToOne
  @JoinColumn(name = "assignment_id", referencedColumnName = "id", nullable = false)
  @ApiModelProperty(value = "作业ID")
  private Assignment assignment; // 与 Assignment 的关联

  @ApiModelProperty(value = "文件路径")
  @Column(name = "file_path", nullable = false)
  private String filePath; // 附件路径

  @ApiModelProperty(value = "文件名")
  @Column(name = "file_name", nullable = false)
  private String fileName; // 文件名
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Assignment getAssignment() {
    return assignment;
  }

  public void setAssignment(Assignment assignment) {
    this.assignment = assignment;
  }
  public String getFilePath() {
    return filePath;
  }

  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

}
