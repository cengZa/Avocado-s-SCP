package com.example.myproject.exception;

/**
 * 违反唯一性异常
 */
public class UniqueException extends BaseException {

    public UniqueException(String message) {
        super("401", message);
    }
}