package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.TopicResponseDTO;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.model.Post;
import com.example.myproject.model.Topic;
import com.example.myproject.model.User;
import com.example.myproject.repository.PostRepository;
import com.example.myproject.repository.TopicRepository;
import com.example.myproject.service.TopicService;
import com.example.myproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * TopicService的实现类，处理主题相关的业务逻辑。
 */
@Service
public class TopicServiceImpl implements TopicService {

    @Autowired
    private TopicRepository topicRepository;

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private UserService userService;

    @Override
    public TopicResponseDTO createTopic(Long postId, Long topicerId, String topicName, String tags) {

        // 检查帖子是否存在
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("班级不存在"));

        // 检查用户是否存在
        User topicer = userService.getUserById(topicerId);
        if (topicer == null) {
            throw new ResourceNotFoundException("用户不存在");
        }

        // 创建新的Topic对象
        Topic topic = new Topic();
        topic.setPost(post);
        topic.setTopicer(topicer);
        topic.setTopicName(topicName);
        topic.setTags(tags);

        // 保存Topic对象到数据库
        topic = topicRepository.save(topic);

        // 转换为 TopicResponseDTO
        return convertToResponseDTO(topic);
    }

    @Override
    public List<TopicResponseDTO> getTopicsByPostId(Long postId) {
        List<Topic> topics = topicRepository.findByPost_PostId(postId);

        return topics.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<TopicResponseDTO> searchTopics(String keyword) {
        List<Topic> topics = topicRepository.findByTopicNameContainingOrTagsContaining(keyword, keyword);

        return topics.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteTopic(Long topicId) {
        topicRepository.deleteById(topicId);
    }


    private TopicResponseDTO convertToResponseDTO(Topic topic) {
        TopicResponseDTO dto = new TopicResponseDTO();
        dto.setTopicId(topic.getTopicId());
        dto.setPostId(topic.getPost().getPostId());
        dto.setTopicerId(topic.getTopicer().getId());
        dto.setTopicName(topic.getTopicName());
        dto.setTags(topic.getTags());
        dto.setTopicTime(topic.getTopicTime());
        return dto;
    }
}
