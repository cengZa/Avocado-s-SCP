package com.example.myproject.model;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
@Table(name = "submission_attachments")
public class SubmissionAttachment {

  @Id
  @ApiModelProperty(value = "提交附件ID", example = "1")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id; // 附件ID

  @ApiModelProperty(value = "提交ID")
  @Column(name = "submission_id", nullable = false)
  private Long submissionId; // 提交ID

  @ApiModelProperty(value = "附件路径")
  @Column(name = "attachment_path", nullable = false)
  private String attachmentPath; // 附件路径
  @ApiModelProperty(value = "文件名")
  @Column(name = "file_name", nullable = false)
  private String fileName; // 文件名

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getSubmissionId() {
    return submissionId;
  }

  public void setSubmissionId(Long submissionId) {
    this.submissionId = submissionId;
  }

  public String getAttachmentPath() {
    return attachmentPath;
  }

  public void setAttachmentPath(String attachmentPath) {
    this.attachmentPath = attachmentPath;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }




}
