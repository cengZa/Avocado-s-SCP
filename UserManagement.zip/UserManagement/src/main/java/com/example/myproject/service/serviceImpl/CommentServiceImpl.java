package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.CommentResponseDTO;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.model.Comment;
import com.example.myproject.model.Topic;
import com.example.myproject.model.User;
import com.example.myproject.repository.CommentRepository;
import com.example.myproject.repository.TopicRepository;
import com.example.myproject.service.CommentService;
import com.example.myproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * CommentService的实现类，处理评论相关的业务逻辑。
 */
@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private TopicRepository topicRepository;

    @Autowired
    private UserService userService;

    @Override
    public CommentResponseDTO createComment(Long topicId, Long commenterId, String content) {

        // 检查主题是否存在
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("主题不存在"));

        // 检查用户是否存在
        User commenter = userService.getUserById(commenterId);
        if (commenter == null) {
            throw new ResourceNotFoundException("用户不存在");
        }

        // 创建新的Comment对象
        Comment comment = new Comment();
        comment.setTopic(topic);
        comment.setCommenter(commenter);
        comment.setContent(content);

        // 保存Comment对象到数据库
        comment = commentRepository.save(comment);

        // 转换为 CommentResponseDTO
        return convertToResponseDTO(comment);
    }

    @Override
    public List<CommentResponseDTO> getCommentsByTopicId(Long topicId) {
        List<Comment> comments = commentRepository.findByTopic_TopicId(topicId);

        return comments.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteComment(Long commentId) {
        commentRepository.deleteById(commentId);
    }

    private CommentResponseDTO convertToResponseDTO(Comment comment) {
        CommentResponseDTO dto = new CommentResponseDTO();
        dto.setCommentId(comment.getCommentId());
        dto.setTopicId(comment.getTopic().getTopicId());
        dto.setCommenterId(comment.getCommenter().getId());
        dto.setContent(comment.getContent());
        dto.setCommentTime(comment.getCommentTime());
        return dto;
    }
}
