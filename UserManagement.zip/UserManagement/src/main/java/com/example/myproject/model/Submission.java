package com.example.myproject.model;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "submissions")
public class Submission {

  @Id
  @ApiModelProperty(value = "提交ID", example = "1")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id; // 提交ID

  @ApiModelProperty(value = "作业ID")
  @Column(name = "assignment_id", nullable = false)
  private Long assignmentId; // 作业ID

  @ApiModelProperty(value = "学生ID")
  @Column(name = "student_id", nullable = false)
  private Long studentId; // 学生ID

  @ApiModelProperty(value = "提交时间")
  @Column(name = "submission_time", nullable = false)
  private Date submissionTime; // 提交时间

  @ApiModelProperty(value = "提交的文字内容")
  @Column(name = "text_submission")
  private String textSubmission; // 提交的文字内容

  @ApiModelProperty(value = "得分")
  private Double score; // 得分
  @ApiModelProperty(value = "是否已批改")
  @Column(columnDefinition = "BOOLEAN DEFAULT FALSE")
  private Boolean graded; // 是否已批改
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getAssignmentId() {
    return assignmentId;
  }

  public void setAssignmentId(Long assignmentId) {
    this.assignmentId = assignmentId;
  }

  public Long getStudentId() {
    return studentId;
  }

  public void setStudentId(Long studentId) {
    this.studentId = studentId;
  }

  public Date getSubmissionTime() {
    return submissionTime;
  }

  public void setSubmissionTime(Date submissionTime) {
    this.submissionTime = submissionTime;
  }

  public String getTextSubmission() {
    return textSubmission;
  }

  public void setTextSubmission(String textSubmission) {
    this.textSubmission = textSubmission;
  }

  public Double getScore() {
    return score;
  }

  public void setScore(Double score) {
    this.score = score;
  }

  public Boolean getGraded() {
    return graded;
  }

  public void setGraded(Boolean graded) {
    this.graded = graded;
  }



}
