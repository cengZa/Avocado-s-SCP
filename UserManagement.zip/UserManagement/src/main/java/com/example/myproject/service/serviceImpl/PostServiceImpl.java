package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.PostResponseDTO;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.exception.UniqueException;
import com.example.myproject.model.Class;
import com.example.myproject.model.Post;
import com.example.myproject.model.User;
import com.example.myproject.repository.ClassRepository;
import com.example.myproject.repository.PostRepository;
import com.example.myproject.service.PostService;
import com.example.myproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * PostService的实现类，处理帖子相关的业务逻辑。
 */
@Service  // 标记为服务层组件，Spring会自动管理
public class PostServiceImpl implements PostService {

    @Autowired  // 自动注入PostRepository
    private PostRepository postRepository;

    @Autowired  // 自动注入ClassRepository
    private ClassRepository classRepository;

    @Autowired  // 自动注入UserService
    private UserService userService;

    @Override
    public PostResponseDTO createPost(Long classId, Long teacherId) {

        //检查帖子是否存在
        if (postRepository.findByClassEntity_Id(classId).isPresent()) {
            throw new UniqueException("帖子已存在");
        }

        // 检查班级是否存在
        Class classEntity = classRepository.findById(classId)
                .orElseThrow(() -> new ResourceNotFoundException("班级不存在"));

        // 检查教师是否存在
        User teacher = userService.getUserById(teacherId);
        if (teacher == null) {
            throw new ResourceNotFoundException("教师不存在");
        }

        // 创建并保存 Post 对象
        Post post = new Post();
        post.setClassEntity(classEntity);
        post.setPoster(teacher);
        post = postRepository.save(post);

        // 转换为 PostResponseDTO

        return convertToResponseDTO(post);
    }

    @Override
    public Optional<PostResponseDTO> getPostByClassId(Long classId) {
        Optional<Post> postOpt = postRepository.findByClassEntity_Id(classId);
        return postOpt.map(this::convertToResponseDTO);
    }

    @Override
    public void deletePost(Long postId) {
        postRepository.deleteById(postId);
    }

    private PostResponseDTO convertToResponseDTO(Post post) {
        PostResponseDTO dto = new PostResponseDTO();
        dto.setPostId(post.getPostId());
        dto.setClassId(post.getClassEntity().getId());
        dto.setTeacherId(post.getPoster().getId());
        dto.setPostTime(post.getPostTime());
        return dto;
    }
}
