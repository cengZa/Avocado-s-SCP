package com.example.myproject.service;


import com.example.myproject.utils.Result;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface AvatarService {

    /***
     * 上传图片
     * @param files 图片文件列表
     * @return 一个url列表，用于存在数据库中，或者返回给前端显示图片
     */
    List<String> uploadImage(List<MultipartFile> files);

    /***
     * 根据文件名称删除文件
     * @param fileName 文件名
     * @return
     */
    Result deleteFile(String fileName);

}