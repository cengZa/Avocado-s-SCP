package com.example.myproject.dto;

import javax.validation.constraints.NotNull;

/**
 * 用于创建帖子的请求数据传输对象。
 */
public class PostDTO {

    @NotNull(message = "班级ID不能为空")
    private Long classId;

    @NotNull(message = "教师ID不能为空")
    private Long teacherId;

    // Getter 和 Setter 方法

    public Long getClassId() {
        return classId;
    }

    public void setClassId(Long classId) {
        this.classId = classId;
    }

    public Long getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Long teacherId) {
        this.teacherId = teacherId;
    }
}
