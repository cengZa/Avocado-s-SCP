package com.example.myproject.service;

import com.example.myproject.utils.Result;

import java.time.LocalDate;

public interface ClassService {
    Result getClassDetails(long classId);

    Result getTodayClassDetails(long userId, LocalDate date);
}
