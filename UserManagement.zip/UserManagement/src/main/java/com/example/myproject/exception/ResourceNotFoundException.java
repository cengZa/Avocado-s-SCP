package com.example.myproject.exception;

/**
 * 资源未找到异常。
 */
public class ResourceNotFoundException extends BaseException {

    public ResourceNotFoundException(String message) {
        super("404", message);
    }
}
