package com.example.myproject.service.serviceImpl;

public class SubmissionServiceImpl {
}
