package com.example.myproject.repository;

import com.example.myproject.model.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * PostRepository接口，继承JpaRepository，提供对Post实体的CRUD操作。
 */
@Repository  // 指定这是一个仓库接口，Spring会自动检测并创建Bean
public interface PostRepository extends JpaRepository<Post, Long> {

    /**
     * 根据班级ID查找帖子。
     * @param classId 班级ID
     * @return Optional<Post>
     */
    Optional<Post> findByClassEntity_Id(Long classId);
}
