package com.example.myproject.service;


import com.example.myproject.model.Assignment;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface AssignmentService {
  Assignment createAssignment(Assignment assignment, MultipartFile[] attachments) throws IOException;
//  List<Assignment> getAllAssignments();
//  Assignment getAssignmentById(Long id);
//  Assignment updateAssignment(Long id, Assignment assignment);
//  void deleteAssignment(Long id);
}
