package com.example.myproject.dto;

import io.swagger.annotations.ApiModelProperty;

public class TodayCourseDTO {
    @ApiModelProperty(value = "课程名称", example = "计算机科学导论")
    private String courseName;

}
