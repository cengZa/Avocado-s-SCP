package com.example.myproject.model;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "assignments")
public class Assignment {

  @Id
  @ApiModelProperty(value = "作业ID", example = "1")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id; // 作业ID

  @ApiModelProperty(value = "班级ID")
  @Column(name = "class_id", nullable = false)
  private Long classId; // 班级ID

  @ApiModelProperty(value = "作业标题")
  @Column(nullable = false)
  private String title; // 作业标题

  @ApiModelProperty(value = "作业描述")
  private String description; // 作业描述

  @ApiModelProperty(value = "满分")
  private Double fullScore; // 作业满分

  @ApiModelProperty(value = "是否允许补交")
  @Column(name = "allow_resubmit", columnDefinition = "BOOLEAN DEFAULT FALSE")
  private Boolean allowResubmit; // 是否允许补交

  @ApiModelProperty(value = "是否允许多次提交")
  @Column(name = "allow_multiple_submissions", columnDefinition = "BOOLEAN DEFAULT FALSE")
  private Boolean allowMultipleSubmissions; // 是否允许多次提交

  @ApiModelProperty(value = "作业开始时间")
  @Column(name = "start_time", nullable = false)
  private Date startTime; // 作业开始时间

  @ApiModelProperty(value = "作业结束时间")
  @Column(name = "end_time", nullable = false)
  private Date endTime; // 作业结束时间

  @ApiModelProperty(value = "是否公布成绩")
  @Column(columnDefinition = "BOOLEAN DEFAULT FALSE")
  private Boolean published; // 是否公布成绩
//  @OneToMany(mappedBy = "assignment", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//  private List<AssignmentAttachment> attachments; // 作业附件列表

  public Integer getSubmissionCount() {
    return submissionCount;
  }

  public void setSubmissionCount(Integer submissionCount) {
    this.submissionCount = submissionCount;
  }

  @Column(name = "submission_count")
  private Integer submissionCount; // 提交人数

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getClassId() {
    return classId;
  }

  public void setClassId(Long classId) {
    this.classId = classId;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Double getFullScore() {
    return fullScore;
  }

  public void setFullScore(Double fullScore) {
    this.fullScore = fullScore;
  }

  public Boolean getAllowResubmit() {
    return allowResubmit;
  }

  public void setAllowResubmit(Boolean allowResubmit) {
    this.allowResubmit = allowResubmit;
  }

  public Boolean getAllowMultipleSubmissions() {
    return allowMultipleSubmissions;
  }

  public void setAllowMultipleSubmissions(Boolean allowMultipleSubmissions) {
    this.allowMultipleSubmissions = allowMultipleSubmissions;
  }

  public Date getStartTime() {
    return startTime;
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  public Date getEndTime() {
    return endTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }

  public Boolean getPublished() {
    return published;
  }

  public void setPublished(Boolean published) {
    this.published = published;
  }

//  public List<AssignmentAttachment> getAttachments() {
//    return attachments;
//  }
//
//  public void setAttachments(List<AssignmentAttachment> attachments) {
//    this.attachments = attachments;
//  }




}
