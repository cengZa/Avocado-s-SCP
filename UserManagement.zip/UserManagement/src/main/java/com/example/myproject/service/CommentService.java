package com.example.myproject.service;

import com.example.myproject.dto.CommentResponseDTO;
import com.example.myproject.model.Comment;

import java.util.List;

/**
 * CommentService接口，定义评论相关的业务方法。
 */
public interface CommentService {

    /**
     * 创建评论。
     * @param topicId 主题ID
     * @param commenterId 评论人ID
     * @param content 评论内容
     * @return CommentResponseDTO
     */
    CommentResponseDTO createComment(Long topicId, Long commenterId, String content);

    /**
     * 根据主题ID获取评论列表。
     * @param topicId 主题ID
     * @return List<Comment>
     */
    List<CommentResponseDTO> getCommentsByTopicId(Long topicId);

    /**
     * 删除评论。
     * @param commentId 评论ID
     */
    void deleteComment(Long commentId);
}
