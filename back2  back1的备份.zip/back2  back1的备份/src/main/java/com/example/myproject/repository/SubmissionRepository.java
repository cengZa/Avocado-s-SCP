package com.example.myproject.repository;

import com.example.myproject.model.Submission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    //用于老师查看作业时查询已提交的人数
    int countByAssignment_AssignmentId(Long assignmentId);

    List<Submission> findByAssignment_AssignmentId(Long assignmentId);

    boolean existsByAssignment_AssignmentIdAndStudent_IdAndStatus(Long assignmentId, Long studentId, Submission.SubmissionStatus status);

    List<Submission> findByAssignment_AssignmentIdAndStatus(Long assignmentId, Submission.SubmissionStatus status);

    boolean existsByAssignment_AssignmentIdAndStatus(Long assignmentId, Submission.SubmissionStatus submissionStatus);

    Optional<Submission> findByAssignment_AssignmentIdAndStudent_Id(Long assignmentId, Long studentId);

    long countByAssignment_AssignmentIdAndStatus(Long assignmentId, Submission.SubmissionStatus submissionStatus);

}
