package com.example.myproject.controller;


import com.example.myproject.dto.BoardDTO;
import com.example.myproject.dto.BoardResponseDTO;
import com.example.myproject.service.BoardService;
import com.example.myproject.utils.Result;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * 板块管理接口，处理与Board相关的HTTP请求。
 */
@RestController
@RequestMapping("/board")
@Api(value = "板块管理接口", tags = {"板块管理"})
public class BoardController {

  @Autowired
  private BoardService boardService;

  /**
   * 创建板块。
   * 仅教师可以创建板块。
   *
   * @param boardDTO 包含班级ID
   * @return Result<PostResponseDTO>
   */
  @PostMapping("/create")
  @ApiOperation(value = "创建板块", notes = "仅教师可以创建板块")
  public Result createPost(
    @ModelAttribute(value = "板块子信息") BoardDTO boardDTO) {
    BoardResponseDTO boardResponseDTO = boardService.createBoard(boardDTO.getClassId(),boardDTO.getBoardName());
    return Result.success(boardResponseDTO, "板块创建成功");

  }

  @PostMapping("/update")
  @ApiOperation(value = "修改板块名字", notes = "仅教师可以修改板块名字")
  public Result updateBoardName(
    @ModelAttribute(value = "板块子信息") BoardDTO boardDTO,
    @RequestParam @ApiParam(value = "新的板块名称", required = true) String newBoardName) {

    // 调用 service 层方法进行修改
    BoardResponseDTO boardResponseDTO = boardService.updateBoardName(boardDTO.getClassId(),boardDTO.getBoardName(), newBoardName);
    return Result.success(boardResponseDTO, "板块名称修改成功");
  }


  /**
   * 根据班级ID获取板块。
   *
   * @param classId 班级ID
   * @return Result<PostResponseDTO>
   */
  @GetMapping("/class/{classId}")
  @ApiOperation(value = "获取板块", notes = "根据班级ID获取板块")
  public Result getPostByClassId(@PathVariable Long classId) {
    List<BoardResponseDTO> boards = boardService.getBoardByClassId(classId);

    // 检查列表是否为空
    if (boards.isEmpty()) {
      return Result.error("404", "帖子不存在");
    } else {
      return Result.success(boards);
    }

  }

  /**
   * 删除板块
   * 仅教师可以删除板块。只有教师的前端有这个按钮就好了
   *
   * @param boardId 帖子ID
   * @return Result
   */
  @DeleteMapping("/{boardId}")
  @ApiOperation(value = "删除板块", notes = "仅教师可以删除板块，只有教师的前端有这个按钮就好了")
  public Result deleteBoard(@PathVariable Long boardId) {
    boardService.deleteBoard(boardId);
    return Result.success(null, "板块删除成功");
  }
}
