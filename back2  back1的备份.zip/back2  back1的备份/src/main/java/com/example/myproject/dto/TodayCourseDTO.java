package com.example.myproject.dto;

import io.swagger.annotations.ApiModelProperty;

public class TodayCourseDTO {

  private String courseName;   // 课程名称
  private String location;     // 上课地点
  private String startTime;    // 开始时间
  private String endTime;      // 结束时间
  private String teacherName;  // 教师名字

  // 构造函数
  public TodayCourseDTO(String courseName, String location, String startTime, String endTime, String teacherName) {
    this.courseName = courseName;
    this.location = location;
    this.startTime = startTime;
    this.endTime = endTime;
    this.teacherName = teacherName;
  }
  public String getCourseName() {
    return courseName;
  }

  public void setCourseName(String courseName) {
    this.courseName = courseName;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getStartTime() {
    return startTime;
  }

  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }

  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  public String getTeacherName() {
    return teacherName;
  }

  public void setTeacherName(String teacherName) {
    this.teacherName = teacherName;
  }

}
