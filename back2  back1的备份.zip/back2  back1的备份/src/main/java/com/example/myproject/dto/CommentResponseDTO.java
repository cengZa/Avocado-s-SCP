package com.example.myproject.dto;


import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
/**
 * 用于返回评论信息的响应数据传输对象。
 */
public class CommentResponseDTO {
  private Long commentId;
  private Long topicId;
  private Long commenterId;
  private String content;
  private Instant commentTime;



  private Long parentCommentId; // 父评论ID，用于表示评论是否是回复



  private List<CommentResponseDTO> replies = new ArrayList<>(); // 子评论（回复）
  private List<String> files; // 可以存储文件名或文件路径
  private List<String> images;

  public Long getCommentId() {
    return commentId;
  }

  public void setCommentId(Long commentId) {
    this.commentId = commentId;
  }

  public Long getTopicId() {
    return topicId;
  }

  public void setTopicId(Long topicId) {
    this.topicId = topicId;
  }

  public Long getCommenterId() {
    return commenterId;
  }

  public void setCommenterId(Long commenterId) {
    this.commenterId = commenterId;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public Instant getCommentTime() {
    return commentTime;
  }

  public void setCommentTime(Instant commentTime) {
    this.commentTime = commentTime;
  }

  public void setFiles(List<String> files) {
    this.files = files;
  }

  public void setImages(List<String> images) {
    this.images = images;
  }
  public List<CommentResponseDTO> getReplies() {
    return replies;
  }

  public void setReplies(List<CommentResponseDTO> replies) {
    this.replies = replies;
  }

  public List<String> getFiles() {
    return files;
  }

  public List<String> getImages() {
    return images;
  }
  public Long getParentCommentId() {
    return parentCommentId;
  }

  public void setParentCommentId(Long parentCommentId) {
    this.parentCommentId = parentCommentId;
  }

}
