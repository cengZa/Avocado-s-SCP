package com.example.myproject.dto;

import lombok.Data;
import lombok.Getter;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

@Getter

/**
 * 提交评分 DTO
 */
@Data
public class SubmissionGradeDTO {

    private Long gradeId;

    @NotNull(message = "提交ID不能为空")
    private Long submissionId;

    @NotNull(message = "评分者ID不能为空")
    private Long graderId;

    @NotNull(message = "分数不能为空")
    @DecimalMin(value = "0.0", message = "分数不能低于0")
    @DecimalMax(value = "100.0", message = "分数不能超过100")
    private Double score;

    private String comment;

    public Long getSubmissionId(){return this.submissionId;}
}
