package com.example.myproject.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.time.Instant;
import java.util.List;

@Entity
@Table(name = "notification")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@ApiModel("通知实体类")
public class Notification {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @ApiModelProperty(value = "通知ID", example = "1")
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "class_id", nullable = false)
  @JsonIgnore
  @ApiModelProperty(value = "班级ID", example = "1")
  private Class classEntity; // 关联班级实体
  @JsonProperty("title")
  @ApiModelProperty(value = "通知标题", example = "期末考试通知")
  private String title;

  @JsonProperty("content")
  @ApiModelProperty(value = "通知内容", example = "请同学们准备期末考试。")
  private String content;
  private Instant notificationTime;  // 评论时间


  @ElementCollection
  @CollectionTable(name = "notification_files", joinColumns = @JoinColumn(name = "notification_id"))
  @Column(name = "file_path")  // 这里是每个文件路径的列名
  @ApiModelProperty(value = "通知附件", example = "附件1.pdf")
  private List<String> files; // 可以存储文件名或文件路径

//照片和其他文件分开的原因是：照片和文字显示在一起
@ElementCollection
@CollectionTable(name = "notification_files", joinColumns = @JoinColumn(name = "notification_id"))
@Column(name = "image_path")  // 这里是每个文件路径的列名
  @ApiModelProperty(value = "通知图片", example = "image1.jpg")
  private List<String> images; // 可以存储图片名或图片路径
//每个学生的已读状态都不同
  @OneToMany(mappedBy = "notification", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @ApiModelProperty(value = "通知已读状态", notes = "每个学生对该通知的已读状态")
  @JsonBackReference
  private List<NotificationReadStatus> readStatuses; // 每条通知可以有多个学生的已读状态
  public Notification() {
    this.notificationTime = Instant.now();
  }
  // Getters and Setters
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
  public Class getClassEntity() {
    return classEntity;
  }

  public void setClassEntity(Class classEntity) {
    this.classEntity = classEntity;
  }
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }



  public List<NotificationReadStatus> getReadStatuses() {
    return readStatuses;
  }

  public void setReadStatuses(List<NotificationReadStatus> readStatuses) {
    this.readStatuses = readStatuses;
  }
  public List<String> getFiles() {
    return files;
  }

  public void setFiles(List<String> files) {
    this.files = files;
  }

  public List<String> getImages() {
    return images;
  }

  public void setImages(List<String> images) {
    this.images = images;
  }
  public Instant getNotificationTime() {
    return notificationTime;
  }


  public void setNotificationTime(Instant notificationTime) {
    this.notificationTime = notificationTime;
  }



}
