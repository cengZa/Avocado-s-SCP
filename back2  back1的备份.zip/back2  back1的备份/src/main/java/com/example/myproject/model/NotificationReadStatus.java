package com.example.myproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "notification_read_status")
@ApiModel("通知已读状态实体类")
public class NotificationReadStatus {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @ApiModelProperty(value = "通知已读状态记录ID", example = "1")
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "notification_id")
  @JsonManagedReference // 这是父对象（Notification）的引用
  @ApiModelProperty(value = "通知ID", example = "1")
  private Notification notification; // 通知（每个学生的已读状态是基于某个通知）

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "student_id")
  @JsonIgnore
  @ApiModelProperty(value = "学生ID", example = "22301115")
  private User student; // 学生（该学生对通知的已读状态）


  @JsonProperty("is_read")  // 确保JSON序列化时字段名是 'is_read'
  @ApiModelProperty(value = "是否已读", example = "true")
  private boolean readStatus;


  private Instant readTime;  // 评论时间

  public NotificationReadStatus() {
    this.readTime = Instant.now();
  }


  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "class_id", nullable = false)
  @JsonIgnore
  @ApiModelProperty(value = "班级ID")
  private Class classEntity;  // 关联班级实体
  public Class getClassEntity() {
    return classEntity;
  }

  public void setClassEntity(Class classEntity) {
    this.classEntity = classEntity;
  }



  // Getters and Setters
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Notification getNotification() {
    return notification;
  }

  public void setNotification(Notification notification) {
    this.notification = notification;
  }

  public User getStudent() {
    return student;
  }

  public void setStudent(User student) {
    this.student = student;
  }




  public boolean isReadStatus() {
    return readStatus;
  }

  public void setReadStatus(boolean readStatus) {
    this.readStatus = readStatus;
  }

  public Instant getReadTime() {
    return readTime;
  }

  public void setReadTime(Instant readTime) {
    this.readTime = readTime;
  }



}
