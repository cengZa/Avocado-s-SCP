package com.example.myproject.model;

public class QuestionRequest {
  private String question;


  // getter 和 setter
  public String getQuestion() {
    return question;
  }

  public void setQuestion(String question) {
    this.question = question;
  }
}
