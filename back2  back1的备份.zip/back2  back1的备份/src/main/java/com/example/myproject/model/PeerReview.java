package com.example.myproject.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * 互评实体类
 */
@Entity
@Table(name = "peer_review")
@Data
@NoArgsConstructor
public class PeerReview {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reviewId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "submission_id", nullable = false)
    private Submission submission; // 被互评的提交

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reviewer_id", nullable = false)
    private User reviewer; // 互评者

    @Column(nullable = false, precision = 5, scale = 2)
    private Double score; // 评分

    @Lob
    private String comment; // 评语

    @Column(nullable = false, updatable = false)
    private LocalDateTime reviewTime = LocalDateTime.now();
}
