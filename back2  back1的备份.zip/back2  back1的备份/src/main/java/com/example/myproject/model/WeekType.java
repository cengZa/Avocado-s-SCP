package com.example.myproject.model;

// 上课周类型的枚举
public enum WeekType {
  EVERY_WEEK,
  ODD_WEEK,
  EVEN_WEEK
}
