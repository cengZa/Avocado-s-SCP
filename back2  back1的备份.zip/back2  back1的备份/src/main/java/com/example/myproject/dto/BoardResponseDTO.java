package com.example.myproject.dto;

import com.example.myproject.model.Topic;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.List;

@Setter
@Getter
/**
 * 用于返回帖子信息的响应数据传输对象。
 */
public class BoardResponseDTO {




  private Long boardId;
  private Long classId;



  private String boardName;



  private List<Topic> topics;  // 一个板块可以有多个主题

  public Long getClassId() {
    return classId;
  }

  public void setClassId(Long classId) {
    this.classId = classId;
  }

  public String getBoardName() {
    return boardName;
  }

  public void setBoardName(String boardName) {
    this.boardName = boardName;
  }
  public List<Topic> getTopics() {
    return topics;
  }

  public void setTopics(List<Topic> topics) {
    this.topics = topics;
  }
  public Long getBoardId() {
    return boardId;
  }

  public void setBoardId(Long boardId) {
    this.boardId = boardId;
  }
}
