package com.example.myproject.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * 自定义异常基类，包含错误代码和错误信息。
 */
@Getter
@Setter
public class BaseException extends RuntimeException {

    private String code;
    private String message;

    public BaseException(String code, String message) {
        super(message); // 保留异常信息
        this.code = code;
        this.message = message;
    }

    public String getCode(){
        return this.code;
    }

}
