package com.example.myproject.service;
import com.example.myproject.utils.Result;
public interface CourseService {
  public Result getCourseDetails(long courseId);

}
