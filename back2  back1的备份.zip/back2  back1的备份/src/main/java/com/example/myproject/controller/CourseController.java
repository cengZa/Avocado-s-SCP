package com.example.myproject.controller;
import com.example.myproject.service.ClassService;
import com.example.myproject.service.CourseService;
import com.example.myproject.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
@RestController
@RequestMapping("/course")
public class CourseController {

  @Autowired
  private CourseService courseService;
  //根据课程id查询课程信息
  @GetMapping("/{courseId}")
  public Result getCourseDetails(@PathVariable long courseId) {
    return courseService.getCourseDetails(courseId);
  }


}
