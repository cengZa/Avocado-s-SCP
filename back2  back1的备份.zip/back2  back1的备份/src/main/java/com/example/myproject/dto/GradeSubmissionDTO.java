// 用于接收批改作业请求的DTO
package com.example.myproject.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@ApiModel("批改作业请求 DTO")
public class GradeSubmissionDTO {

    @ApiModelProperty(value = "分数", required = true)
    private Integer score;

    @ApiModelProperty("评语")
    private String comment;

}
