package com.example.myproject.repository;

import com.example.myproject.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * CommentRepository接口，继承JpaRepository，提供对Comment实体的CRUD操作。
 */
@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {

  /**
   * 根据主题ID查找评论列表。
   * @param topicId 主题ID
   * @return List<Comment>
   */
  List<Comment> findByTopic_TopicId(Long topicId);

  public List<Comment> findByTopic_TopicIdAndParentComment_CommentIdIsNull(Long topicId);
  public List<Comment> findByParentComment_CommentId(Long parentCommentId);



  Optional<Comment> findByCommentId(Long parentCommentId);

  List<Comment> findByParentComment_CommentIdIsNull();

  List<Comment> findByParentComment_CommentIdIsNotNull();
}
