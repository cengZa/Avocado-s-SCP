package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.BoardResponseDTO;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.exception.UniqueException;
import com.example.myproject.model.*;
import com.example.myproject.model.Board;
import com.example.myproject.model.Class;
import com.example.myproject.repository.BoardRepository;
import com.example.myproject.repository.ClassRepository;
import com.example.myproject.repository.BoardRepository;
import com.example.myproject.service.BoardService;
import com.example.myproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * PostService的实现类，处理帖子相关的业务逻辑。
 */
@Service  // 标记为服务层组件，Spring会自动管理
public class BoardServiceImpl implements BoardService {

  @Autowired  // 自动注入PostRepository
  private BoardRepository boardRepository;

  @Autowired  // 自动注入ClassRepository
  private ClassRepository classRepository;

  @Autowired  // 自动注入UserService
  private UserService userService;

  @Override
  public BoardResponseDTO createBoard(Long classId,String boardName) {

    //检查帖子是否存在
    if (boardRepository.findByClassEntity_IdAndBoardName(classId,boardName).isPresent()) {
      throw new UniqueException("板块已存在");
    }

    // 检查班级是否存在
    Class classEntity = classRepository.findById(classId)
      .orElseThrow(() -> new ResourceNotFoundException("班级不存在"));


    // 创建并保存 Board对象
    Board board = new Board();
    board.setClassEntity(classEntity);
    board.setBoardName(boardName);


    board.setTopics(new ArrayList<>());

    board = boardRepository.save(board);

    // 转换为 PostResponseDTO

    return convertToResponseDTO(board);
  }

  @Override
  public List<BoardResponseDTO> getBoardByClassId(Long classId) {
    List<Board> boards = boardRepository.findByClassEntity_Id(classId);
    return boards.stream()
      .map(this::convertToResponseDTO)  // 对每个Board进行转换
      .collect(Collectors.toList());   // 收集到List
  }

  @Override
  public void deleteBoard(Long boardId) {
    boardRepository.deleteById(boardId);
  }

  private BoardResponseDTO convertToResponseDTO(Board board) {
   BoardResponseDTO dto = new BoardResponseDTO();
    dto.setBoardId(board.getBoardId());
    dto.setBoardName(board.getBoardName());
    dto.setClassId(board.getClassEntity().getId());
   dto.setTopics(board.getTopics());
    return dto;
  }
  @Override
  public BoardResponseDTO updateBoardName(Long classId,String oldBoardName, String newBoardName){
    Optional<Board> boardOpt = boardRepository.findByClassEntity_IdAndBoardName(classId,oldBoardName);
    // 获取板块对象
    Board board = boardOpt.get();

    // 设置新的板块名称
    board.setBoardName(newBoardName);

    // 保存更新后的板块
    board = boardRepository.save(board);


    // 返回更新后的板块信息，转换为 BoardResponseDTO
    return convertToResponseDTO(board);

  }

}
