package com.example.myproject.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * 提交实体类
 */
@Entity
@Table(name = "submission",
        uniqueConstraints = {@UniqueConstraint(columnNames = {"assignment_id", "student_id"})})
@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = {"assignment", "student"})
public class Submission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long submissionId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignment_id", nullable = false)
    @JsonBackReference
    private Assignment assignment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    @JsonBackReference
    private User student;

    @Column(nullable = false, updatable = false)
    private LocalDateTime submitTime = LocalDateTime.now();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SubmissionStatus status = SubmissionStatus.已提交;

    @Column
    private Integer score; // 学生提交的得分

    @Lob
    private String comment; // 学生提交的评语

    @Column(length = 500, nullable = false)
    private String filePath; // 压缩后的ZIP文件路径

    /**
     * 提交状态枚举
     */
    public enum SubmissionStatus {
        已提交, 未批改, 已批改
    }
}
