package com.example.myproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 作业实体类
 */
@Entity
@Table(name = "assignment")
@Data
@NoArgsConstructor
public class Assignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long assignmentId;

    @Column(nullable = false, length = 255)
    private String title;

    @Lob
    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "publisher_id")
    private User publisher;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "class_id")
    private Class classEntity;

    @Column(nullable = false)
    private LocalDateTime startTime;  // 作业开始时间，使用 LocalDateTime

    @Column(nullable = false)
    private LocalDateTime endTime;  // 作业截止时间，使用 LocalDateTime

    @Column(nullable = false)
    private Boolean isPeerReview = false;

    private LocalDateTime peerReviewDeadline;  // 互评截止时间，使用 LocalDateTime

    private Integer peerReviewCount = 1;


    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AssignmentStatus status = AssignmentStatus.未开始;

    @Column(nullable = false, updatable = false)
    private Instant createTime = Instant.now();

    @Column(nullable = false)
    private Instant updateTime = Instant.now();

    // 作业附件
    @OneToMany(mappedBy = "assignment", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    // 使用 @JsonManagedReference 表示这是“管理者”一方
    @JsonManagedReference
    private List<AssignmentAttachment> attachments;

    // 提交列表
    @OneToMany(mappedBy = "assignment", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Submission> submissions;

    public enum AssignmentStatus {
        未开始, 进行中, 已完成, 已截止, 互评中
    }
}
