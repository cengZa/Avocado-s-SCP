package com.example.myproject.model;


import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.security.Timestamp;


@Entity
@Table(name = "resources")
public class Resource {

  @Id
  @ApiModelProperty(value = "资源ID", example = "1")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id; // 使用 BigInt 类型

  @ApiModelProperty(value = "文件名")
  private String fileName;

  @ApiModelProperty(value = "文件路径")
  private String filePath;



  @ApiModelProperty(value = "班级ID")
  @Column(name = "class_id")
  private Long classId; // 关联的班级 ID

  @ApiModelProperty(value = "父文件夹ID")
  @Column(name = "parent_folder_id")
  private Long parentFolderId; // 父文件夹的 ID, null 表示为根文件夹

  @ApiModelProperty(value = "是否为文件夹")
  @Column(name = "is_folder")
  private Boolean isFolder; // 是否为文件夹，true 表示文件夹，false 表示文件

  // Getters and Setters
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getFilePath() {
    return filePath;
  }

  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }

  public Long getClassId() {
    return classId;
  }

  public void setClassId(Long classId) {
    this.classId = classId;
  }

  public Long getParentFolderId() {
    return parentFolderId;
  }

  public void setParentFolderId(Long parentFolderId) {
    this.parentFolderId = parentFolderId;
  }

  public Boolean getIsFolder() {
    return isFolder;
  }

  public void setIsFolder(Boolean isFolder) {
    this.isFolder = isFolder;
  }
}
