package com.example.myproject.controller;

import com.example.myproject.service.ClassService;
import com.example.myproject.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/classes")
public class ClassController {

    @Autowired
    private ClassService classService;

    @GetMapping("/{classId}")
    public Result getClassDetails(@PathVariable long classId) {
        return classService.getClassDetails(classId);
    }

    @GetMapping("/student/{classId}")
    public Result getClassStudent(@PathVariable long classId) {
        return classService.getClassStudent(classId);
    }

    /**
     * 获取一个班的老师的具体细节
     *
     * @param classId
     * @return
     */
    @GetMapping("/teacher/{classId}")
    public Result getClassTeacher(@PathVariable long classId) {
        return classService.getClassTeacher(classId);
    }

    /**
     * 获取一个班的总人数
     *
     * @param classId
     * @return
     */
    @GetMapping("/getStudentNumber/{classId}")
    public Result getClassStudentNumber(@PathVariable long classId) {
        long studentCount = classService.getClassStudentNumber(classId);
        return new Result(studentCount); // 将 studentCount 包装在 Result 对象中}
    }

    @GetMapping("/todayClass")
    public Result getTodayClassDetails(
            @RequestParam long userId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return Result.success(classService.getTodayClassDetails(userId, date));
    }
}
