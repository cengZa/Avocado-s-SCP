package com.example.myproject.exception;

public class FileStorageException extends BaseException {
    public FileStorageException(String message) {
        super("408", message);
    }
}
