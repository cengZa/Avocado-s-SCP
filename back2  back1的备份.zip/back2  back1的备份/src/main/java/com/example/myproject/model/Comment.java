package com.example.myproject.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Comment实体类，表示评论。
 */
@Getter
@Setter
@Entity  // 指定这是一个实体类，映射到数据库表
@Table(name = "comment")  // 指定数据库表名为 "comment"
public class Comment {
  @Id  // 指定主键
  @GeneratedValue(strategy = GenerationType.IDENTITY)  // 主键生成策略为自增
  private Long commentId;  // 评论ID


  /**
   * 与Topic实体的多对一关系，一个评论属于一个主题。
   */
  @ManyToOne  // 多对一关系，多条评论对应一个主题
  @JoinColumn(name = "topic_id")  // 外键列名为 "topic_id"
  private Topic topic;  // 所属的主题

  /**
   * 与User实体的多对一关系，评论人。
   */
  @ManyToOne  // 多对一关系，多条评论对应一个用户
  @JoinColumn(name = "commenter_id")  // 外键列名为 "commenter_id"
  private User commenter;  // 评论人

  @Lob  // 指定大对象类型，用于存储大型文本
  private String content;  // 评论内容

  private Instant commentTime;  // 评论时间



  @ManyToOne(fetch = FetchType.LAZY)

  @JoinColumn(name = "parent_comment_id")
  private Comment parentComment; // 可选，关联父评论对象

  @OneToMany(mappedBy = "parentComment", cascade = CascadeType.ALL, orphanRemoval = true)
  private List<Comment> replies = new ArrayList<>(); // 当前评论的所有回复
  @ElementCollection
  @CollectionTable(name = "comment_files", joinColumns = @JoinColumn(name = "comment_id"))
  @Column(name = "file_path")  // 这里是每个文件路径的列名
  @ApiModelProperty(value = "主题附件", example = "附件1.pdf")
  private List<String> files; // 可以存储文件名或文件路径
  @ElementCollection
  @CollectionTable(name = "comment_files", joinColumns = @JoinColumn(name = "comment_id"))
  @Column(name = "image_path")  // 这里是每个文件路径的列名
  @ApiModelProperty(value = "主题附件", example = "附件1.pdf")
  private List<String> images; // 可以存储文件名或文件路径



  /**
   * 无参构造函数，初始化评论时间为当前时间。
   */
  public Comment() {
    this.commentTime = Instant.now();
  }
  public Topic getTopic() {
    return topic;
  }

  public void setTopic(Topic topic) {
    this.topic = topic;
  }

  public User getCommenter() {
    return commenter;
  }

  public void setCommenter(User commenter) {
    this.commenter = commenter;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public Instant getCommentTime() {
    return commentTime;
  }

  public void setCommentTime(Instant commentTime) {
    this.commentTime = commentTime;
  }
  public Long getCommentId() {
    return commentId;
  }

  public void setCommentId(Long commentId) {
    this.commentId = commentId;
  }
  public Comment getParentComment() {
    return parentComment;
  }

  public void setParentComment(Comment parentComment) {
    this.parentComment = parentComment;
  }

  public List<Comment> getReplies() {
    return replies;
  }

  public void setReplies(List<Comment> replies) {
    this.replies = replies;
  }

  public List<String> getFiles() {
    return files;
  }

  public void setFiles(List<String> files) {
    this.files = files;
  }

  public List<String> getImages() {
    return images;
  }

  public void setImages(List<String> images) {
    this.images = images;
  }
}
