package com.example.myproject.controller;

import com.example.myproject.dto.TopicDTO;
import com.example.myproject.dto.TopicResponseDTO;
import com.example.myproject.model.Notification;
import com.example.myproject.model.Topic;
import com.example.myproject.service.TopicService;
import com.example.myproject.utils.Result;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

/**
 * 主题管理接口，处理与Topic相关的HTTP请求。
 */
@RestController
@RequestMapping("/topics")
@Api(value = "主题管理接口", tags = {"主题管理"})
public class TopicController {

  @Autowired
  private TopicService topicService;

  /**
   * 创建主题。
   * 学生和教师都可以创建主题。
   *
   * @param topicDTO 包含帖子ID、发起人ID、主题名称和标签的请求数据
   * @return Result<TopicResponseDTO>
   */
  @PostMapping("/create")
  @ApiOperation(value = "创建主题", notes = "学生和教师都可以创建主题")
  public Result createTopic(
    @ModelAttribute(value = "主题信息") TopicDTO topicDTO,
    @RequestParam(value = "files", required = false) List<MultipartFile> files,
    @RequestParam(value = "images", required = false) List<MultipartFile> images ) {
    try {
      // 调用service层逻辑
      TopicResponseDTO createdTopic = topicService.createTopic(topicDTO, files, images);
      // 返回成功响应
      return Result.success(createdTopic, "主题上传成功");
    } catch (Exception e) {
      // 返回错误信息
      return Result.error("500", "已经有这个主题");
    }
  }


  /**
   * 根据板块ID获取主题列表。
   *
   * @param boardId 帖子ID
   * @return Result<List<TopicResponseDTO>>
   */
  @GetMapping("/board/{boardId}")
  @ApiOperation(value = "获取主题列表", notes = "根据帖子ID获取主题列表")
  public Result getTopicsByBoardId(@PathVariable Long boardId) {
    List<TopicResponseDTO> topics = topicService.getTopicsByBoardId(boardId);
    return Result.success(topics,"获取主题成功");
  }

  /**
   * 获取所有主题列表。
   *
   * @return Result<List<TopicResponseDTO>>
   */
  @GetMapping("/getAllTopics/{classId}")
  @ApiOperation(value = "获取所有主题列表", notes = "返回所有主题的列表")
  public Result getAllTopics(@PathVariable Long classId) {
    List<TopicResponseDTO> topics = topicService.getAllTopics(classId); // 调用服务层获取所有主题
    return Result.success(topics, "获取所有主题成功");
  }
  /**
   * 获取主题。
   *
   * @return
   */
  @GetMapping("/topic/{topicId}")
  @ApiOperation(value = "获取所有主题列表", notes = "返回所有主题的列表")
  public Result getTopic(@PathVariable Long topicId) {
    TopicResponseDTO topic = topicService.getTopic(topicId); // 调用服务层获取所有主题
    return Result.success(topic, "获取所有主题成功");
  }

  /**
   * 根据关键词搜索主题。
   *
   * @param keyword 搜索关键词
   * @return Result<List<TopicResponseDTO>>
   */
  @GetMapping("/search")
  @ApiOperation(value = "搜索主题", notes = "根据关键词搜索主题")
  public Result searchTopics(@RequestParam Long boardId,@RequestParam String keyword) {
    List<TopicResponseDTO> topics = topicService.searchTopics(boardId,keyword);
    // 如果没有找到主题，返回提示消息
    if (topics == null || topics.isEmpty()) {
      return Result.success(null, "未搜索到主题");
    }
    return Result.success(topics, "成功查询主题");
  }

  /**
   * 删除主题。
   * 仅教师可以删除主题。
   *
   * @param topicId 主题ID
   * @return Result
   */
  @DeleteMapping("/{topicId}")
  @ApiOperation(value = "删除主题", notes = "仅教师可以删除主题")
  public Result deleteTopic(@PathVariable Long topicId) {
    topicService.deleteTopic(topicId);
    return Result.success(null, "主题删除成功");
  }
}
