package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.CommentDTO;
import com.example.myproject.dto.CommentResponseDTO;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.model.Comment;
import com.example.myproject.model.Topic;
import com.example.myproject.model.User;
import com.example.myproject.repository.CommentRepository;
import com.example.myproject.repository.TopicRepository;
import com.example.myproject.service.CommentService;
import com.example.myproject.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * CommentService的实现类，处理评论相关的业务逻辑。
 */
@Service
public class CommentServiceImpl implements CommentService {
  @Resource
  private HttpServletRequest request;
  @Autowired
  private CommentRepository commentRepository;

  @Autowired
  private TopicRepository topicRepository;

  @Autowired
  private UserService userService;

  @Override
  public CommentResponseDTO createComment(CommentDTO commentDTO, List<MultipartFile> files, List<MultipartFile> images)throws Exception {


    Long topicId = commentDTO.getTopicId();
    System.out.println("Topic ID: " + topicId);
    Logger logger = LoggerFactory.getLogger(getClass());
    logger.info("主题iddddddd",topicId );
    Topic topic = topicRepository.findByTopicId(topicId)
      .orElseThrow(() -> new ResourceNotFoundException("主题不存在aaaaaaaaaaaaa"));

    // 检查用户是否存在
    User commenter = userService.getUserById(commentDTO.getCommenterId());
    if (commenter == null) {
      throw new ResourceNotFoundException("用户不存在");
    }

    // 创建新的Comment对象
    Comment comment = new Comment();
    comment.setTopic(topic);
    comment.setCommenter(commenter);
    comment.setContent(commentDTO.getContent());

    if(commentDTO.getParentCommentId()==null){
      comment.setParentComment(null); // 确保没有父评论
    }
    Comment parentComment = null; // 默认没有父评论
    if (commentDTO.getParentCommentId() != null) {
      parentComment = commentRepository.findByCommentId(commentDTO.getParentCommentId())
        .orElseThrow(() -> new RuntimeException("父评论不存在"));
    }
    comment.setParentComment(parentComment);  // 如果 parentComment 是 null，不会影响

    comment.setReplies(new ArrayList<>());
    if (files != null && !files.isEmpty()) {
      List<String> fileUrls = new ArrayList<>();
      String filesDirectory = "/D:/discussion/comments/";  // 服务器上保存文件的目录

      for (MultipartFile file : files) {
        String fileName = file.getOriginalFilename();
        String filePath = filesDirectory + fileName;

        try {
          // 将文件保存到指定目录
          file.transferTo(new File(filePath));
          // 构造可以通过浏览器访问的 URL
          // 获取基础路径，包含协议（http/https）、服务器名、端口和上下文路径
          String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
          String httpUrl = basePath + "/comment/" + fileName;  // 拼凑出可以访问的 URL，根路径下直接访问文件

          fileUrls.add(httpUrl);

          logger.info("文件路径保存成功: {}", httpUrl);
        } catch (IOException e) {
          logger.error("保存文件失败: {}", e.getMessage(), e);
          throw e;  // 如果保存文件失败，则抛出异常
        }
      }

      // 设置多个文件的 URL 路径
     comment.setFiles(fileUrls);
    } else {
      logger.info("未提供文件，跳过文件保存.");
    }


// 处理图片附件（支持多个图片）
    if (images != null && !images.isEmpty()) {
      List<String> imageUrls = new ArrayList<>();
      String imagesDirectory = "/D:/discussion/comments/";  // 图片保存目录

      for (MultipartFile image : images) {
        String imageName = image.getOriginalFilename(); // 获取图片文件名
        String imagePath = imagesDirectory + imageName;  // 拼接保存路径

        try {
          // 将图片保存到指定目录
          image.transferTo(new File(imagePath));
          // 生成可以通过浏览器访问的 URL
          String baseUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() ;
          String imageUrl=baseUrl+"/comment/"+imageName;
          imageUrls.add(imageUrl);

          logger.info("图片路径保存成功: {}", imageUrl);
        } catch (IOException e) {
          logger.error("保存图片失败: {}", e.getMessage(), e);
          throw e;  // 如果保存图片失败，则抛出异常
        }
      }

      // 设置多个图片的 URL 路径
      comment.setImages(imageUrls);
    } else {
      logger.info("未提供图片，跳过图片保存.");
    }
    // 保存Comment对象到数据库
    comment = commentRepository.save(comment);

    // 转换为 CommentResponseDTO
    return convertToResponseDTO(comment);
  }
  @Override
  public List<CommentResponseDTO> getCommentsByTopicId(Long topicId) {
    // 获取所有一级评论（没有父评论的评论）
    List<Comment> topLevelComments = commentRepository.findByTopic_TopicIdAndParentComment_CommentIdIsNull(topicId);

    // 对一级评论进行转换，并获取二级评论
    return topLevelComments.stream()
      .map(comment -> {
        // 转换一级评论为 DTO
        CommentResponseDTO responseDTO = convertToResponseDTO(comment);

        // 获取并设置该一级评论的二级评论
        List<CommentResponseDTO> replyDTOs = getRepliesForComment(comment.getCommentId());
        responseDTO.setReplies(replyDTOs);

        return responseDTO;
      })
      .collect(Collectors.toList());
  }
  @Override
  public CommentResponseDTO getCommentById(Long commentId) {

    Optional<Comment> comment = commentRepository.findByCommentId(commentId);

    if (comment.isPresent()) {
      CommentResponseDTO responseDTO = convertToResponseDTO(comment.get());

      List<Comment> replies = commentRepository.findByParentComment_CommentId(commentId);

      List<CommentResponseDTO> replyDTOs = replies.stream()
        .map(this::convertToResponseDTO)
        .collect(Collectors.toList());
      responseDTO.setReplies(replyDTOs);

      return responseDTO;
    } else {
      return null;
    }
  }


  // 获取某个一级评论的二级评论
  private List<CommentResponseDTO> getRepliesForComment(Long parentCommentId) {
    // 获取所有该父评论下的二级评论
    List<Comment> replies = commentRepository.findByParentComment_CommentId(parentCommentId);

    // 转换为 DTO 并返回
    return replies.stream()
      .map(this::convertToResponseDTO)
      .collect(Collectors.toList());
  }
  @Override
  public List<CommentResponseDTO> getAllComments() {

    // 获取所有一级评论（没有父评论的评论）
    List<Comment> topLevelComments = commentRepository.findByParentComment_CommentIdIsNull(); // 仅获取一级评论

    // 创建一个 Map 用于存储二级评论，按父评论 ID 分组
    Map<Long, List<CommentResponseDTO>> repliesMap = new HashMap<>();

    // 获取所有二级评论（有父评论的评论）
    List<Comment> secondLevelComments = commentRepository.findByParentComment_CommentIdIsNotNull(); // 获取所有二级评论

    // 将二级评论转换为 DTO，并按父评论 ID 分组
    secondLevelComments.stream()
      .map(this::convertToResponseDTO) // 将二级评论转换为 DTO
      .forEach(reply -> {
        // 将二级评论按父评论 ID 分组存入 repliesMap
        repliesMap.computeIfAbsent(reply.getParentCommentId(), k -> new ArrayList<>()).add(reply);
      });

    // 将一级评论转换为 DTO，并为每个一级评论设置其对应的二级评论
    List<CommentResponseDTO> mainComments = topLevelComments.stream()
      .map(comment -> {
        // 将一级评论转换为 DTO
        CommentResponseDTO dto = convertToResponseDTO(comment);

        // 获取该一级评论对应的二级评论
        List<CommentResponseDTO> replies = repliesMap.get(dto.getCommentId());
        if (replies != null) {
          dto.setReplies(replies); // 设置该一级评论的所有二级评论
        }

        return dto; // 返回转换后的一级评论 DTO
      })
      .collect(Collectors.toList());

    return mainComments;  // 返回包含一级评论及其二级评论的列表
  }

  @Override
  public void deleteComment(Long commentId) {
    commentRepository.deleteById(commentId);
  }
  private CommentResponseDTO convertToResponseDTO(Comment comment) {
    CommentResponseDTO dto = new CommentResponseDTO();
    dto.setCommentId(comment.getCommentId());
    dto.setTopicId(comment.getTopic().getTopicId());
    dto.setCommenterId(comment.getCommenter().getId());
    dto.setContent(comment.getContent());
    dto.setCommentTime(comment.getCommentTime());
    dto.setFiles(comment.getFiles());
    dto.setImages(comment.getImages());

    // 设置父评论 ID，如果存在
    if (comment.getParentComment() != null) {
      dto.setParentCommentId(comment.getParentComment().getCommentId());
    }

    // 没有二级评论时，返回空列表
    dto.setReplies(new ArrayList<>());

    return dto;
  }

}
