package com.example.myproject.dto;

import javax.validation.constraints.NotNull;

/**
 * 用于创建帖子的请求数据传输对象。
 */
public class BoardDTO {

  @NotNull(message = "班级ID不能为空")
  private Long classId;




  @NotNull(message = "板块名字不能为空")
  private String boardName;  // 板块名称


  // Getter 和 Setter 方法

  public Long getClassId() {
    return classId;
  }

  public void setClassId(Long classId) {
    this.classId = classId;
  }
  public String getBoardName() {
    return boardName;
  }

  public void setBoardName(String boardName) {
    this.boardName = boardName;
  }

}
