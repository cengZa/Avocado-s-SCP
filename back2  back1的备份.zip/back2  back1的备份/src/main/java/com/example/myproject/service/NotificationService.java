package com.example.myproject.service;
import com.example.myproject.dto.NotificationDTO;
import com.example.myproject.model.Notification;
import com.example.myproject.model.NotificationReadStatus;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface NotificationService {

  /**
   * 发布通知
   * @return 发布的通知
   */
  Notification createNotification(NotificationDTO notificationDTO,List<MultipartFile> files, List<MultipartFile> images) throws IOException;

  /**
   * 根据班级ID获取所有通知
   * @param classId 班级ID
   * @return 班级的所有通知
   */
  List<Notification> getAllNotificationsByClass(Long classId);
  List<NotificationReadStatus> getAll(Long studentId);

  /**
   * 获取指定班级中的指定通知的已读人数
   * @param classId 班级ID
   * @param notificationId 通知ID
   * @return 已读人数
   */
  long getReadCountForNotification(Long classId, Long notificationId);



  /**
   * 获取学生的通知状态（已读/未读）
   * @param studentId 学生ID
   * @return 学生的所有通知及其状态
   */
  List<NotificationReadStatus> getReadStatusForStudent(Long classId,Long studentId);



  /**
   * 标记通知为已读
   * @param studentId 学生ID
   * @param notificationId 通知ID
   * @return 更新后的通知状态
   */
  NotificationReadStatus markAsRead(Long classId,Long studentId, Long notificationId);
  Notification getNotificationDetail(Long notificationId);
}
