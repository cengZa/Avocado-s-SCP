package com.example.myproject.dto;

import com.example.myproject.model.Notification;
import io.swagger.annotations.ApiModelProperty;

public class ReadStatusDTO {

  @ApiModelProperty(value = "学生ID", example = "22301115")
  private Long studentId;

  @ApiModelProperty(value = "通知ID", example = "1")
  private Long notificationId;

  @ApiModelProperty(value = "已读状态", example = "true")
  private boolean readStatus;

  @ApiModelProperty(value = "已读时间", example = "2024-11-01T10:30:00")
  private String readAt;

  // Getters and Setters
  public Long getStudentId() {
    return studentId;
  }

  public void setStudentId(Long studentId) {
    this.studentId = studentId;
  }



  public String getReadAt() {
    return readAt;
  }

  public void setReadAt(String readAt) {
    this.readAt = readAt;
  }
  public boolean isReadStatus() {
    return readStatus;
  }

  public void setReadStatus(boolean readStatus) {
    this.readStatus = readStatus;
  }
  public Long getNotificationId() {
    return notificationId;
  }

  public void setNotificationId(Long notificationId) {
    this.notificationId = notificationId;
  }
}
