package com.example.myproject.service;

import com.example.myproject.dto.BoardResponseDTO;

import java.util.List;
import java.util.Optional;

/**
 * PostService接口，定义帖子相关的业务方法。
 */
public interface BoardService {

  /**
   * 创建板块（讨论区）。
   * @param classId 班级ID
   * @return 创建的Board对象
   */
  BoardResponseDTO createBoard(Long classId,String boardName);

  /**
   * 根据班级ID获取帖子。
   * @param classId 班级ID
   * @return Optional<Post>
   */
List<BoardResponseDTO> getBoardByClassId(Long classId);

  /**
   * 删除帖子。
   * @param boardId 帖子ID
   */
  void deleteBoard(Long boardId);

  BoardResponseDTO updateBoardName(Long classId,String oldBoardName, String newBoardName);
}
