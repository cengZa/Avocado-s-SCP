package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.SubmissionGradeDTO;
import com.example.myproject.dto.SubmissionGradeResponseDTO;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.model.Submission;
import com.example.myproject.model.SubmissionGrade;
import com.example.myproject.model.User;
import com.example.myproject.repository.SubmissionGradeRepository;
import com.example.myproject.repository.SubmissionRepository;
import com.example.myproject.repository.UserRepository;
import com.example.myproject.service.SubmissionGradeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 提交评分服务实现类
 */
@Service
public class SubmissionGradeServiceImpl implements SubmissionGradeService {

    @Autowired
    private SubmissionGradeRepository submissionGradeRepository;

    @Autowired
    private SubmissionRepository submissionRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public SubmissionGradeResponseDTO gradeSubmission(Long submissionId, SubmissionGradeDTO submissionGradeDTO) {
        // 验证提交是否存在
        Submission submission = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new ResourceNotFoundException("提交不存在"));

        // 验证批改人（教师）是否存在
        User grader = userRepository.findById(submissionGradeDTO.getGraderId())
                .orElseThrow(() -> new ResourceNotFoundException("批改人不存在"));

        // 创建 SubmissionGrade 对象
        SubmissionGrade grade = new SubmissionGrade();
        grade.setSubmission(submission);
        grade.setStudent(grader);
        grade.setScore(submissionGradeDTO.getScore());
        grade.setComment(submissionGradeDTO.getComment());

        // 保存评分
        grade = submissionGradeRepository.save(grade);

        // 更新提交状态为已批改
        submission.setStatus(Submission.SubmissionStatus.已批改);
        submissionRepository.save(submission);

        // 转换为 GradeResponseDTO
        return convertToResponseDTO(grade);
    }

    @Override
    public SubmissionGradeResponseDTO getGrade(Long submissionId, Long graderId) {
        // Implementation here
        return null;
    }

    private SubmissionGradeResponseDTO convertToResponseDTO(SubmissionGrade grade) {
        SubmissionGradeResponseDTO dto = new SubmissionGradeResponseDTO();
        BeanUtils.copyProperties(grade, dto);
        dto.setGradeId(grade.getGradeId());
        dto.setSubmissionId(grade.getSubmission().getSubmissionId());
        dto.setGraderId(grade.getStudent().getId());
        return dto;
    }
}
