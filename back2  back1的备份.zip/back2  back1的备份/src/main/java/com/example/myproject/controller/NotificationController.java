package com.example.myproject.controller;

import com.example.myproject.dto.NotificationDTO;
import com.example.myproject.model.Notification;
import com.example.myproject.model.NotificationReadStatus;
import com.example.myproject.repository.NotificationRepository;
import com.example.myproject.service.ClassService;
import com.example.myproject.service.NotificationService;
import com.example.myproject.utils.FilesUtil;
import com.example.myproject.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

  @Autowired
  private NotificationService notificationService;
  @Autowired
  private ClassService classService;
  @Autowired
  private NotificationRepository notificationRepository;

  /**
   * 教师端：发布通知
   * 教师可以发布新的通知，通知会被保存到数据库。
   *
   * @param notificationDTO 通知数据传输对象
   * @return Result 封装的创建结果
   */

  @PostMapping("/create")
  public Result createNotification(
    @ModelAttribute NotificationDTO notificationDTO,
    @RequestParam(value = "files", required = false) List<MultipartFile> files,  // files 变为可选
    @RequestParam(value = "images", required = false) List<MultipartFile> images  // images 变为可选
  ) {
    try {
      // 调用service层逻辑
      Notification createdNotification = notificationService.createNotification(notificationDTO, files, images);
      // 返回成功响应
      return Result.success(createdNotification, "通知上传成功");
    } catch (Exception e) {
      // 返回错误信息
      return Result.error("500", "通知上传失败");
    }
  }

  /**
   * 教师端：获取某个班级的所有通知（不区分已读未读）
   * 教师可以查看指定班级的所有通知。
   */
  @GetMapping("/getAllByClass/{classId}")
  public List<Notification> getAllNotificationsByClass(@PathVariable Long classId) {
    return notificationService.getAllNotificationsByClass(classId);
  }

  /**
   * 获取指定班级的指定通知的已读人数和总学生人数
   *
   * @param classId        班级ID
   * @param notificationId 通知ID
   * @return 已读人数和总人数的字符串格式
   */

  @GetMapping("/getReadCount")
  public String getReadCount(@RequestParam Long classId, @RequestParam Long notificationId) {
    long readCount = notificationService.getReadCountForNotification(classId, notificationId);
    long totalCount = classService.getClassStudentNumber(classId);
    return "已读人数: " + readCount + " / 总学生人数: " + totalCount;
  }

  /**
   * 学生端：查看所有通知（区分已读与未读）
   * 学生可以查看所有通知并看到哪些是已读，哪些是未读。
   */
  //存在问题，不能看到通知id
  @GetMapping("/getAllForStudent")
  public List<NotificationReadStatus> getAllNotificationsForStudent(@RequestParam Long classId, @RequestParam Long studentId) {
    return notificationService.getReadStatusForStudent(classId, studentId);
  }

  /**
   * 学生端：查看未读通知
   * 学生可以查看所有未读的通知，这些通知会有一个标识（如圆点）。
   */
  @GetMapping("/getUnreadForStudent")
  public List<Notification> getUnreadNotificationsForStudent(@RequestParam Long classId, @RequestParam Long studentId) {
    return notificationRepository.findAll().stream()
      .filter(notification ->
        // 检查通知是否属于指定班级
        notification.getClassEntity().getId().equals(classId) &&
          // 检查通知的阅读状态，确保未读
          notification.getReadStatuses().stream()
            .anyMatch(status ->
              status.getStudent().getId().equals(studentId) &&
                !status.isReadStatus()))
      .collect(Collectors.toList());
  }

  /**
   * 学生端：查看已读通知（根据班级筛选）
   * 获取指定班级下学生的所有已读通知。
   */
  @GetMapping("/getReadForStudent")
  public List<Notification> getReadNotificationsForStudent(
    @RequestParam Long classId, @RequestParam Long studentId) {
    return notificationRepository.findAll().stream()
      .filter(notification ->
        // 检查通知是否属于指定班级
        notification.getClassEntity().getId().equals(classId) &&
          // 检查通知的阅读状态，确保已读
          notification.getReadStatuses().stream()
            .anyMatch(status ->
              status.getStudent().getId().equals(studentId) &&
                status.isReadStatus()))
      .collect(Collectors.toList());
  }

  @GetMapping("/getAll")
  public List<NotificationReadStatus> getAll(
    @RequestParam Long studentId) {
    return notificationService.getAll(studentId);

  }

  /**
   * 学生端：打开通知并标记为已读
   * 当学生点击通知查看时，会将该通知标记为已读。
   */
  @PostMapping("/markAsRead")
  public NotificationReadStatus markNotificationAsRead(@RequestParam Long classId, @RequestParam Long studentId, @RequestParam Long notificationId) {
    return notificationService.markAsRead(classId, studentId, notificationId);
  }
  // 获取通知详情
  @GetMapping("/notification/{notificationId}")
  public Notification getNotificationDetail(@PathVariable Long notificationId) {
    return notificationService.getNotificationDetail(notificationId);
  }


  /**
   * 根据文件路径下载附件
   * @param
   * @return 附件文件
   * @throws IOException 文件读取异常
   */
  //传递的路径是编码过的还是未编码，得看前端收的的是怎么样的，等前端！！！！
  private static final String FILE_DIRECTORY = "D:/notifications/";

  @GetMapping("/download/{fileName}")
  public ResponseEntity<Void> downloadFile(@PathVariable String fileName, HttpServletResponse response) {
    File file = new File(FILE_DIRECTORY + fileName);
    try {
      // 调用工具方法进行文件下载
      FilesUtil.downloadFile(file, response);
      return ResponseEntity.ok().build();
    } catch (IOException e) {
      return ResponseEntity.status(404).build(); // 文件未找到
    }
  }

}
