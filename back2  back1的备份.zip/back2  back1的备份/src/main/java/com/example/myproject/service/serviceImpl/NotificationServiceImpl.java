package com.example.myproject.service.serviceImpl;
import com.example.myproject.dto.NotificationDTO;
import com.example.myproject.model.*;
import com.example.myproject.model.Class;
import com.example.myproject.repository.*;
import com.example.myproject.utils.FilesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.example.myproject.service.NotificationService;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;


import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpServletRequest;
@Service
public class NotificationServiceImpl implements NotificationService {

  @Autowired
  private NotificationRepository notificationRepository;

  @Autowired
  private NotificationReadStatusRepository notificationReadStatusRepository;

  @Autowired
  private ClassUserRepository classUserRepository;
  @Autowired
  private ClassRepository classRepository;
  @Autowired
  private UserRepository userRepository;
  private static final String uploadDir = "D:/notifications/"; // 基础目录
  /**
   * Servlet请求域对象
   */
  @Resource
  private HttpServletRequest request;

  /**
   * 发布通知
   * @return 发布的通知
   */
  @Override
  @Transactional
  public Notification createNotification(NotificationDTO notificationDTO, List<MultipartFile> files,List<MultipartFile> images) throws IOException {
    Logger logger = LoggerFactory.getLogger(this.getClass());
    // 获取班级信息
    Class classEntity = classRepository.findById(notificationDTO.getClassId())
      .orElseThrow(() -> new RuntimeException("班级不存在"));
    logger.info("找到了班级！！！！！！！: {}", classEntity.getId());
    // 获取该班级的所有学生
//    List<User> students = classUserRepository.findByClassEntityId(classEntity.getId());
    List<User>students = classUserRepository.findStudentByClassId(classEntity.getId());
    logger.info("班级size!!!!!!!: {}", students.size());
    // 创建通知实体类
    Notification notification = new Notification();
    notification.setClassEntity(classEntity);
    notification.setTitle(notificationDTO.getTitle());
    notification.setContent(notificationDTO.getContent());

    // 处理文件附件（支持多个文件）
    if (files != null && !files.isEmpty()) {
      List<String> fileUrls = new ArrayList<>();
      String filesDirectory = "/D:/notifications/";  // 服务器上保存文件的目录

      for (MultipartFile file : files) {
        String fileName = file.getOriginalFilename();
        String filePath = filesDirectory + fileName;

        try {
          // 将文件保存到指定目录
          file.transferTo(new File(filePath));
          // 构造可以通过浏览器访问的 URL
          // 获取基础路径，包含协议（http/https）、服务器名、端口和上下文路径
          String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
          String httpUrl = basePath + "/notification/" + fileName;  // 拼凑出可以访问的 URL，根路径下直接访问文件

          fileUrls.add(httpUrl);

          logger.info("文件路径保存成功: {}", httpUrl);
        } catch (IOException e) {
          logger.error("保存文件失败: {}", e.getMessage(), e);
          throw e;  // 如果保存文件失败，则抛出异常
        }
      }

      // 设置多个文件的 URL 路径
      notification.setFiles(fileUrls);
    } else {
      logger.info("未提供文件，跳过文件保存.");
    }


// 处理图片附件（支持多个图片）
    if (images != null && !images.isEmpty()) {
      List<String> imageUrls = new ArrayList<>();
      String imagesDirectory = "/D:/notifications/";  // 图片保存目录

      for (MultipartFile image : images) {
        String imageName = image.getOriginalFilename(); // 获取图片文件名
        String imagePath = imagesDirectory + imageName;  // 拼接保存路径

        try {
          // 将图片保存到指定目录
          image.transferTo(new File(imagePath));
          // 生成可以通过浏览器访问的 URL
          String baseUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() ;
          String imageUrl=baseUrl+"/notification/"+imageName;
          imageUrls.add(imageUrl);

          logger.info("图片路径保存成功: {}", imageUrl);
        } catch (IOException e) {
          logger.error("保存图片失败: {}", e.getMessage(), e);
          throw e;  // 如果保存图片失败，则抛出异常
        }
      }

      // 设置多个图片的 URL 路径
      notification.setImages(imageUrls);
    } else {
      logger.info("未提供图片，跳过图片保存.");
    }

    // 初始化每个学生的通知已读状态为未读
    List<NotificationReadStatus> readStatuses = new ArrayList<>();
    for (User student : students) {
      NotificationReadStatus status = new NotificationReadStatus();
      status.setNotification(notification);
      status.setStudent(student);
      status.setReadStatus(false); // 默认未读
      status.setReadTime(null); // 未读状态没有已读时间
      status.setClassEntity(classEntity);
      readStatuses.add(status);
    }

    // 将已读状态关联到通知
    notification.setReadStatuses(readStatuses);
    logger.info("Notification read statuses initialized for {} students.", students.size());

    // 保存通知并返回
    return notificationRepository.save(notification);
  }

  /**
   * 根据班级ID获取所有通知
   * @param classId 班级ID
   * @return 班级的所有通知
   */
  @Override
  public List<Notification> getAllNotificationsByClass(Long classId) {
    return notificationRepository.findByClassEntityId(classId);
  }
  @Override
  public List<NotificationReadStatus> getAll(Long studentId) {
    // 1. 获取学生所在的所有班级
    List<Class> classEntities = classUserRepository.findClassByStudentId(studentId);

    // 2. 获取这些班级的所有通知
    List<Notification> notifications = new ArrayList<>();
    List<NotificationReadStatus> notificationStatuses = new ArrayList<>();
    for (Class classEntity : classEntities) {
      List<NotificationReadStatus> classNotifications = notificationReadStatusRepository.findByStudentIdAndClassEntityId(studentId, classEntity.getId());
      notificationStatuses.addAll(classNotifications);
    }

return notificationStatuses;
  }

  /**
   * 获取指定班级中的指定通知的已读人数
   * @param classId 班级ID
   * @param notificationId 通知ID
   * @return 已读人数
   */
  @Override
  public long getReadCountForNotification(Long classId, Long notificationId) {
    return notificationReadStatusRepository.countByNotificationIdAndClassEntityIdAndReadStatus(notificationId, classId, true);
  }

  /**
   * 获取学生的通知状态（已读/未读）
   * @param studentId 学生ID
   * @return 学生的所有通知及其状态
   */
  @Override
  public List<NotificationReadStatus> getReadStatusForStudent(Long classId, Long studentId) {
    return notificationReadStatusRepository.findByStudentIdAndClassEntityId(studentId, classId);
  }

  /**
   * 标记通知为已读
   * @param studentId 学生ID
   * @param notificationId 通知ID
   * @return 更新后的通知状态
   */
  @Override
  public NotificationReadStatus markAsRead(Long classId,Long studentId, Long notificationId) {
    // 查找当前学生在该班级下的通知已读状态
    NotificationReadStatus status = notificationReadStatusRepository.findByStudentIdAndNotificationIdAndClassEntityId(studentId, notificationId, classId);

    // 设置为已读
    status.setReadStatus(true);
status.setReadTime(Instant.now());

    // 保存并返回更新后的通知已读状态
    return notificationReadStatusRepository.save(status);
  }
@Override
// 获取通知的详情
public Notification getNotificationDetail(Long notificationId) {
  // 假设你有一个 Notification 实体与数据库表映射
  return notificationRepository.findById(notificationId)
    .orElseThrow(() -> new RuntimeException("Notification not found"));
}


}
