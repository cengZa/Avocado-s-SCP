package com.example.myproject.repository;


import com.example.myproject.model.Resource;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface ResourceRepository extends JpaRepository<Resource, Long> {
  List<Resource> findByFilePath(String folderPath);
  // 根据班级 ID 查询资源
  List<Resource> findByClassId(Long classId);
 Optional<Resource> findById(Long parentFolderId);
  // 查询特定父文件夹ID下的所有子文件夹
  List<Resource> findByParentFolderIdAndIsFolderTrue(Long parentFolderId);
  List<Resource> findByParentFolderIdAndIsFolderFalse(Long parentFolderId);

  List<Resource> findByParentFolderId(Long parentFolderId);
  List<Resource> findByParentFolderIdAndFileNameContainingAndIsFolderFalse(Long parentFolderId,String  searchTerm);
 Resource findByClassIdAndParentFolderIdIsNull(Long classId); // 获取根文件夹


}
