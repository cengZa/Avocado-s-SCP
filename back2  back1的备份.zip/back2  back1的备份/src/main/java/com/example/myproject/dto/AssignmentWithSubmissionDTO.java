package com.example.myproject.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 作业与提交信息的 DTO 用于学生端，包含作业信息及该学生的提交信息。
 */
@Data
public class AssignmentWithSubmissionDTO {

    private Long assignmentId;
    private String title;
    private String description;
    private Long publisherId;
    private Long classId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Boolean isPeerReview;
    private String status;

    private Integer peerReviewCount;
    private Integer peerReviewMinScore;
    private Integer peerReviewMaxScore;
    private LocalDateTime peerReviewDeadline;


    // 提交信息，若未提交则为 null
    private SubmissionResponseDTO submission;
}
