package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.*;
import com.example.myproject.exception.BadRequestException;
import com.example.myproject.exception.BaseException;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.model.*;
import com.example.myproject.model.Class;
import com.example.myproject.repository.*;
import com.example.myproject.service.AssignmentService;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


/**
 * 作业服务实现类
 */
@Service
public class AssignmentServiceImpl implements AssignmentService {

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private ClassRepository classRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AssignmentAttachmentRepository assignmentAttachmentRepository;

    @Autowired
    private SubmissionRepository submissionRepository;

    @Autowired
    private ClassUserRepository classUserRepository;

    @Autowired
    private PeerReviewRepository peerReviewRepository;

    @Value("${file.upload-dir}")
    private String uploadDir;

    /**
     * 教师 发布 作业
     */
    @Override
    public AssignmentResponseDTO createAssignment(AssignmentDTO assignmentDTO, List<MultipartFile> files) {
        // 验证发布人是否存在assignment
        User publisher = userRepository.findById(assignmentDTO.getPublisherId())
                .orElseThrow(() -> new ResourceNotFoundException("发布人不存在"));

        // 验证班级是否存在
        Class classEntity = classRepository.findById(assignmentDTO.getClassId())
                .orElseThrow(() -> new ResourceNotFoundException("班级不存在"));

        // 创建 Assignment 对象
        Assignment assignment = new Assignment();
        BeanUtils.copyProperties(assignmentDTO, assignment);
        assignment.setPublisher(publisher);
        assignment.setClassEntity(classEntity);
        assignment.setCreateTime(Instant.now());
        assignment.setUpdateTime(Instant.now());
        assignment.setIsPeerReview(assignmentDTO.getIsPeerReview());
        if(assignment.getIsPeerReview()){
            assignment.setPeerReviewDeadline(assignmentDTO.getPeerReviewDeadline());
            assignment.setPeerReviewCount(assignmentDTO.getPeerReviewCount());
        }

        // 保存 Assignment
        assignment = assignmentRepository.save(assignment);

        // 多文件上传处理
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                saveAssignmentAttachment(assignment, file);
            }
        }

        // TODO: 通知相关学生（待实现）

        // 转换为 AssignmentResponseDTO
        return convertToResponseDTO(assignment);
    }

    /**
     * 处理作业上传时 附件的保存
     */
    @Override
    public void saveAssignmentAttachment(Assignment assignment, MultipartFile file) {

        // 文件名清理
        String originalFileName = StringUtils.cleanPath(file.getOriginalFilename());

        // 文件类型白名单
        List<String> allowedMimeTypes = Arrays.asList(
                "image/jpeg",
                "image/png",
                "application/pdf",
                "text/plain",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/zip",
                "application/x-rar-compressed"
        );
        if (!allowedMimeTypes.contains(file.getContentType())) {
            throw new BadRequestException("不支持的文件类型");
        }

        // 文件大小限制（例如 10MB）
        long maxSize = 10 * 1024 * 1024;
        if (file.getSize() > maxSize) {
            throw new BadRequestException("文件大小超过限制（10MB）");
        }

        // 生成唯一文件名
        String fileExtension = "";
        int dotIndex = originalFileName.lastIndexOf('.');
        if (dotIndex > 0) {
            fileExtension = originalFileName.substring(dotIndex);
        }
        String uniqueFileName = UUID.randomUUID() + fileExtension;

        // 构建文件路径
        Path assignmentDir = Paths.get(uploadDir, "assignments", String.valueOf(assignment.getAssignmentId()));
        try {
            Files.createDirectories(assignmentDir);
        } catch (IOException e) {
            throw new BaseException("无法创建作业目录", e.getMessage());
        }

        Path targetLocation = assignmentDir.resolve(uniqueFileName);

        try {
            // 保存文件到本地
            file.transferTo(targetLocation.toFile());
        } catch (IOException e) {
            throw new BaseException("文件保存失败", e.getMessage());
        }

        // 保存附件信息到数据库
        AssignmentAttachment attachment = new AssignmentAttachment();
        attachment.setAssignment(assignment);
        attachment.setFileName(originalFileName);
        attachment.setFilePath(targetLocation.toString());
        attachment.setUploadTime(Instant.now());

        assignmentAttachmentRepository.save(attachment);
    }

    public AssignmentResponseDTO convertToResponseDTO(Assignment assignment) {
        AssignmentResponseDTO dto = new AssignmentResponseDTO();
        BeanUtils.copyProperties(assignment, dto);
        dto.setAssignmentId(assignment.getAssignmentId());
        return dto;
    }

    //********************************************************************************

    /**
     * 学生查看作业
     */
    @Override
    public List<AssignmentWithSubmissionDTO> getAssignmentsForStudent(Long classId, Long studentId) {
        List<Assignment> assignments = assignmentRepository.findByClassEntity_Id(classId);
        return assignments.stream().map(assignment -> {
            AssignmentWithSubmissionDTO dto = new AssignmentWithSubmissionDTO();
            BeanUtils.copyProperties(assignment, dto);
            dto.setAssignmentId(assignment.getAssignmentId());
            dto.setPublisherId(assignment.getPublisher() != null ? assignment.getPublisher().getId() : null);
            dto.setClassId(assignment.getClassEntity() != null ? assignment.getClassEntity().getId() : null);

            // 查询学生在该作业下的提交
            Optional<Submission> submissionOpt = submissionRepository.findByAssignment_AssignmentIdAndStudent_Id(
                    assignment.getAssignmentId(), studentId);

            Submission submission = submissionOpt.orElse(null);

            // 根据当前时间更新状态
            LocalDateTime now = LocalDateTime.now();
            Assignment.AssignmentStatus updatedStatus = updateAssignmentStatus(assignment, submission, now);
            assignment.setStatus(updatedStatus);
            assignmentRepository.save(assignment);

            // 返回状态
            dto.setStatus(updatedStatus.name());

            if (submission != null) {
                SubmissionResponseDTO submissionDTO = convertToSubmissionResponseDTO(submission);
                dto.setSubmission(submissionDTO);
                dto.setPeerReviewCount(assignment.getPeerReviewCount());
                dto.setPeerReviewDeadline(assignment.getPeerReviewDeadline());


            } else {
                dto.setSubmission(null);
            }

            return dto;
        }).collect(Collectors.toList());
    }



    /**
     * 教师查看作业
     */
    @Override
    public List<AssignmentResponseDTO> getAssignmentsForTeacher(Long classId, Long publisherId) {
        List<Assignment> assignments = assignmentRepository.findByClassEntity_IdAndPublisher_Id(classId, publisherId);

        LocalDateTime now = LocalDateTime.now();

        return assignments.stream()
                .map(assignment -> {
                    // 此时没有 submission 对象，我们传 null
                    Assignment.AssignmentStatus updatedStatus = updateAssignmentStatus(assignment, null, now);
                    assignment.setStatus(updatedStatus);
                    assignmentRepository.save(assignment);

                    AssignmentResponseDTO dto = convertToResponseDTO(assignment);
                    int submittedCount = submissionRepository.countByAssignment_AssignmentId(assignment.getAssignmentId());
                    dto.setSubmittedCount(submittedCount);
                    dto.setStatus(updatedStatus);
                    return dto;
                })
                .collect(Collectors.toList());
    }


    //********************************************************************************

    /**
     * 删除指定的作业
     *
     * @param assignmentId 作业 ID
     * @param publisherId  发布人（教师）ID
     */
    @Override
    @Transactional
    public void deleteAssignment(Long assignmentId, Long publisherId) {
        // 查找作业
        Assignment assignment = assignmentRepository.findById(assignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("作业不存在"));

        // 验证发布人是否为当前用户
        if (!assignment.getPublisher().getId().equals(publisherId)) {
            throw new BadRequestException("您无权删除此作业");
        }

        // 删除作业（假设级联删除提交和附件）
        assignmentRepository.delete(assignment);
    }

    /**
     *  提供作业对应附件下载功能：
     * @return File
     */
    @Override
    public File createZipFileForAttachments(Long assignmentId) {
        List<AssignmentAttachment> attachments = assignmentAttachmentRepository.findByAssignment_AssignmentId(assignmentId);
        if (attachments.isEmpty()) {
            throw new ResourceNotFoundException("没有找到附件");
        }

        // 使用系统临时目录
        Path tempDir;
        try {
            tempDir = Files.createTempDirectory("assignment_" + assignmentId);
        } catch (IOException e) {
            throw new BaseException("无法创建临时目录", e.getMessage());
        }

        Path zipFilePath = tempDir.resolve("attachments.zip");
        File zipFile = zipFilePath.toFile();

        Set<String> fileNamesInZip = new HashSet<>();

        try (FileOutputStream fos = new FileOutputStream(zipFile);
             BufferedOutputStream bos = new BufferedOutputStream(fos);
             ZipOutputStream zos = new ZipOutputStream(bos)) {

            for (AssignmentAttachment attachment : attachments) {
                Path filePath = Paths.get(attachment.getFilePath());
                File file = filePath.toFile();

                if (file.exists()) {
                    String originalFileName = StringUtils.cleanPath(attachment.getFileName());

                    // 生成唯一文件名
                    String uniqueFileName = generateUniqueFileName(originalFileName, fileNamesInZip);
                    fileNamesInZip.add(uniqueFileName);

                    try (FileInputStream fis = new FileInputStream(file);
                         BufferedInputStream bis = new BufferedInputStream(fis)) {
                        ZipEntry zipEntry = new ZipEntry(uniqueFileName);
                        zos.putNextEntry(zipEntry);

                        byte[] buffer = new byte[4096];
                        int length;
                        while ((length = bis.read(buffer)) >= 0) {
                            zos.write(buffer, 0, length);
                        }

                        zos.closeEntry();
                    }
                }
            }
        } catch (IOException e) {
            throw new BaseException("创建压缩文件失败", e.getMessage());
        }

        return zipFile;
    }

    /**
     * 生成唯一文件名，避免重复
     */
    private String generateUniqueFileName(String originalFileName, Set<String> existingFileNames) {
        String baseName = FilenameUtils.getBaseName(originalFileName);
        String extension = FilenameUtils.getExtension(originalFileName);
        String uniqueFileName = baseName + "." + extension;

        while (existingFileNames.contains(uniqueFileName)) {
            uniqueFileName = baseName + "_" + UUID.randomUUID() + "." + extension;
            // 防止无限循环
            if (uniqueFileName.length() > 255) {
                throw new BaseException("400","无法生成唯一的文件名");
            }
        }

        return uniqueFileName;
    }

    /**
     * 学生提交作业
     *
     * @param assignmentId 作业ID
     * @param studentId    学生ID
     * @param files        提交的文件列表（可选）
     * @return SubmissionResponseDTO 提交的详细信息
     */
    @Override
    @Transactional
    public SubmissionResponseDTO submitAssignment(Long assignmentId, Long studentId, List<MultipartFile> files) {
        // 验证作业是否存在
        Assignment assignment = assignmentRepository.findById(assignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("作业不存在"));

        // 检查作业状态是否允许提交
        if (assignment.getStatus() == Assignment.AssignmentStatus.未开始) {
            throw new BadRequestException("作业尚未开始，无法提交");
        }
        if (assignment.getStatus() == Assignment.AssignmentStatus.已截止) {
            throw new BadRequestException("作业已截止，无法提交");
        }

        // 检查是否已经有提交记录
        Optional<Submission> existingSubmissionOpt = submissionRepository.findByAssignment_AssignmentIdAndStudent_Id(assignmentId, studentId);
        Submission submission;
        if (existingSubmissionOpt.isPresent()) {
            submission = existingSubmissionOpt.get();
            // 根据需求，可以选择是否允许重新提交或更新提交
            if (submission.getStatus() == Submission.SubmissionStatus.已批改) {
                throw new BadRequestException("该作业已批改，无法重新提交");
            }
            // 更新提交记录
            submission.setSubmitTime(LocalDateTime.now());
            submission.setStatus(Submission.SubmissionStatus.已提交);
            submission.setScore(null);
            submission.setComment(null);
            // 处理文件上传
            if (files != null && !files.isEmpty()) {
                // 删除旧的ZIP文件
                if (submission.getFilePath() != null) {
                    File oldZipFile = new File(submission.getFilePath());
                    if (oldZipFile.exists()) {
                        oldZipFile.delete();
                    }
                }
                // 保存新的ZIP文件
                String zipFilePath = saveAndCompressFiles(submission, files);
                submission.setFilePath(zipFilePath);
            }
            submissionRepository.save(submission);
        } else {
            // 创建新的提交记录
            submission = new Submission();
            submission.setAssignment(assignment);
            User student = userRepository.findById(studentId)
                    .orElseThrow(() -> new ResourceNotFoundException("学生不存在"));
            submission.setStudent(student);
            submission.setSubmitTime(LocalDateTime.now());
            submission.setStatus(Submission.SubmissionStatus.已提交);

            // 处理文件上传
            if (files != null && !files.isEmpty()) {
                String zipFilePath = saveAndCompressFiles(submission, files);
                System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+zipFilePath);
                submission.setFilePath(zipFilePath);
            }
            submissionRepository.save(submission);
        }

        // 首先根据当前时间和提交情况更新submission状态
        LocalDateTime now = LocalDateTime.now();
        Submission.SubmissionStatus newSubStatus = updateSubmissionStatus(submission, assignment, now);
        submission.setStatus(newSubStatus);
        submissionRepository.save(submission);

        // 更新作业状态，因为新的提交可能使作业变为已完成
        Submission anySubmission = submissionRepository.findByAssignment_AssignmentIdAndStudent_Id(assignmentId, studentId).orElse(null);
        Assignment.AssignmentStatus newAssignStatus = updateAssignmentStatus(assignment, anySubmission, now);
        assignment.setStatus(newAssignStatus);
        assignmentRepository.save(assignment);

        return convertToSubmissionResponseDTO(submission);
    }

    /**
     * 保存并压缩提交的多个文件为一个ZIP文件
     *
     * @param submission 提交记录
     * @param files      上传的文件列表
     * @return 压缩后的ZIP文件路径
     */
    private String saveAndCompressFiles(Submission submission, List<MultipartFile> files) {
        // 验证文件类型和大小
        List<String> allowedMimeTypes = Arrays.asList(
                "image/jpeg",
                "image/png",
                "application/pdf",
                "text/plain",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/zip",
                "application/x-rar-compressed"
        );
        long maxSize = 10 * 1024 * 1024; // 10MB per file

        // 创建提交目录
        Path submissionDir = Paths.get(uploadDir, "submissions", String.valueOf(submission.getSubmissionId()));
        try {
            Files.createDirectories(submissionDir);
        } catch (IOException e) {
            throw new BaseException("无法创建提交目录", e.getMessage());
        }

        // 临时目录用于存放上传的文件
        Path tempDir;
        try {
            tempDir = Files.createTempDirectory("submission_" + submission.getSubmissionId());
        } catch (IOException e) {
            throw new BaseException("无法创建临时目录", e.getMessage());
        }

        // 保存所有上传的文件到临时目录
        for (MultipartFile file : files) {
            String originalFileName = StringUtils.cleanPath(file.getOriginalFilename());

            if (!allowedMimeTypes.contains(file.getContentType())) {
                throw new BadRequestException("不支持的文件类型: " + originalFileName);
            }

            if (file.getSize() > maxSize) {
                throw new BadRequestException("文件大小超过限制（10MB）: " + originalFileName);
            }

            String uniqueFileName = generateUniqueFileName(originalFileName, tempDir);

            Path targetLocation = tempDir.resolve(uniqueFileName);
            try {
                file.transferTo(targetLocation.toFile());
            } catch (IOException e) {
                throw new BaseException("文件保存失败: " + originalFileName, e.getMessage());
            }
        }

        // 压缩所有文件到一个ZIP文件
        String zipFileName = "submission_" + submission.getSubmissionId() + ".zip";
        Path zipFilePath = submissionDir.resolve(zipFileName);
        try (FileOutputStream fos = new FileOutputStream(zipFilePath.toFile());
             ZipOutputStream zos = new ZipOutputStream(fos)) {

            Files.walk(tempDir)
                    .filter(Files::isRegularFile)
                    .forEach(filePath -> {
                        String fileName = filePath.getFileName().toString();
                        try (FileInputStream fis = new FileInputStream(filePath.toFile())) {
                            ZipEntry zipEntry = new ZipEntry(fileName);
                            zos.putNextEntry(zipEntry);

                            byte[] buffer = new byte[4096];
                            int length;
                            while ((length = fis.read(buffer)) >= 0) {
                                zos.write(buffer, 0, length);
                            }

                            zos.closeEntry();
                        } catch (IOException e) {
                            throw new RuntimeException("创建ZIP文件失败: " + fileName, e);
                        }
                    });

        } catch (IOException e) {
            throw new BaseException("创建ZIP文件失败", e.getMessage());
        }

        // 删除临时目录和其中的文件
        try {
            Files.walk(tempDir)
                    .sorted(Comparator.reverseOrder())
                    .map(Path::toFile)
                    .forEach(File::delete);
        } catch (IOException e) {
        }

        return zipFilePath.toString();
    }

    /**
     * 生成唯一文件名，避免重复 为saveAndCompressFiles服务
     *
     * @param originalFileName 原始文件名
     * @param tempDir          临时目录路径
     * @return 唯一的文件名
     */
    private String generateUniqueFileName(String originalFileName, Path tempDir) {
        String baseName = FilenameUtils.getBaseName(originalFileName);
        String extension = FilenameUtils.getExtension(originalFileName);
        String uniqueFileName = baseName + "." + extension;

        Path filePath = tempDir.resolve(uniqueFileName);
        while (Files.exists(filePath)) {
            uniqueFileName = baseName + "_" + UUID.randomUUID().toString() + "." + extension;
            filePath = tempDir.resolve(uniqueFileName);
        }

        return uniqueFileName;
    }


    /**
     * 将 Submission 转换为 SubmissionResponseDTO
     *
     * @param submission 提交记录
     * @return SubmissionResponseDTO
     */
    private SubmissionResponseDTO convertToSubmissionResponseDTO(Submission submission) {
        SubmissionResponseDTO dto = new SubmissionResponseDTO();
        BeanUtils.copyProperties(submission, dto);
        dto.setSubmissionId(submission.getSubmissionId());
        dto.setAssignmentId(submission.getAssignment().getAssignmentId());
        dto.setStudentId(submission.getStudent().getId());
        dto.setStatus(submission.getStatus().name());

        // 新增获取学生的昵称
        if (submission.getStudent() != null && submission.getStudent().getNickname() != null) {
            dto.setStudent_name(submission.getStudent().getNickname());
        } else {
            dto.setStudent_name(null); //或根据业务设置默认值
        }

        return dto;
    }

    public Assignment.AssignmentStatus updateAssignmentStatus(Assignment assignment, Submission submission, LocalDateTime now) {
        LocalDateTime start = assignment.getStartTime();
        LocalDateTime end = assignment.getEndTime();

        if (submission != null) {
            // 学生已提交 => 已完成
            return Assignment.AssignmentStatus.已完成;
        } else {
            // 学生还未提交
            if (now.isBefore(start)) {
                return Assignment.AssignmentStatus.未开始;
            } else if (!now.isAfter(end)) {
                // now在 [start, end] 之间
                return Assignment.AssignmentStatus.进行中;
            } else {
                // now > end
                if (assignment.getIsPeerReview()) {
                    LocalDateTime peerReviewDeadline = assignment.getPeerReviewDeadline();
                    if (peerReviewDeadline != null && now.isBefore(peerReviewDeadline)) {
                        // 允许互评且当前时间在互评截止时间之前
                        return Assignment.AssignmentStatus.互评中;
                    }
                }
                // 否则已截止
                return Assignment.AssignmentStatus.已截止;
            }
        }
    }

    public Submission.SubmissionStatus updateSubmissionStatus(Submission submission, Assignment assignment, LocalDateTime now) {
        LocalDateTime end = assignment.getEndTime();

        if (submission.getScore() != null) {
            // 已有分数（已批改）
            return Submission.SubmissionStatus.已批改;
        } else {
            // 无分数，尚未批改
            if (now.isAfter(end)) {
                // 截止时间已过，但还未批改 => 未批改
                return Submission.SubmissionStatus.未批改;
            } else {
                // 截止时间未过 => 已提交
                return Submission.SubmissionStatus.已提交;
            }
        }
    }

    @Override
    public List<SubmissionResponseDTO> getSubmissionsByAssignment(Long assignmentId) {
        List<Submission> submissionList = submissionRepository.findByAssignment_AssignmentId(assignmentId);
        return submissionList.stream()
                .map(this::convertToSubmissionResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public SubmissionResponseDTO gradeSubmission(Long assignmentId, Long submissionId, GradeSubmissionDTO gradeRequest) {
        // 验证提交是否存在
        Submission submission = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new ResourceNotFoundException("提交记录不存在"));

        // 验证作业ID是否匹配
        if (!submission.getAssignment().getAssignmentId().equals(assignmentId)) {
            throw new BadRequestException("提交记录与作业不匹配");
        }

        // 根据需求，可以检查用户权限（是否为此作业的教师）
        // TODO: 添加权限验证逻辑

        // 更新分数与评语
        submission.setScore(gradeRequest.getScore());
        submission.setComment(gradeRequest.getComment());

        // 更新状态为已批改
        submission.setStatus(Submission.SubmissionStatus.已批改);
        submissionRepository.save(submission);

        return convertToSubmissionResponseDTO(submission);
    }

    @Override
    public Resource getSubmissionFile(Long assignmentId, Long submissionId) {
        Submission submission = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new ResourceNotFoundException("提交记录不存在"));

        if (!submission.getAssignment().getAssignmentId().equals(assignmentId)) {
            throw new BadRequestException("提交记录与作业不匹配");
        }

        File file = new File(submission.getFilePath());
        if (!file.exists()) {
            throw new ResourceNotFoundException("提交的附件文件不存在");
        }

        try {
            return new UrlResource(file.toURI());
        } catch (MalformedURLException e) {
            throw new BadRequestException("文件读取失败:" + e.getMessage());
        }
    }

    @Override
    public AssignmentResponseDTO getAssignmentById(Long assignmentId) {
        Assignment assignment = assignmentRepository.findById(assignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("作业不存在"));


        return convertToResponseDTO(assignment);
    }

    //************************************************************************


    @Override
    public List<AssignmentResponseDTO> getAssignmentsByPublisher(Long publisherId) {
        List<Assignment> assignments = assignmentRepository.findByPublisher_Id(publisherId);
        return assignments.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AssignmentResponseDTO> getAssignmentsByClass(Long classId) {
        List<Assignment> assignments = assignmentRepository.findByClassEntity_Id(classId);
        return assignments.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }



    @Override
    public List<SubmissionResponseDTO> getSubmissionsForPeerReview(Long assignmentId, Long studentId) {
        // 获取作业
        Assignment assignment = assignmentRepository.findById(assignmentId)
                .orElseThrow(() -> new ResourceNotFoundException("作业不存在"));

        LocalDateTime now = LocalDateTime.now();
        // 确保开启互评、当前时间在作业截止后且在互评截止前
        if (!Boolean.TRUE.equals(assignment.getIsPeerReview())) {
            throw new BadRequestException("该作业未开启互评");
        }
        if (now.isBefore(assignment.getEndTime())) {
            throw new BadRequestException("互评尚未开始，请在作业截止后互评");
        }
        if (assignment.getPeerReviewDeadline() == null || now.isAfter(assignment.getPeerReviewDeadline())) {
            throw new BadRequestException("互评已结束或未设置互评截止时间");
        }

        // 获取该作业的所有已提交的提交记录(已提交或者未批改的提交)
        // 可根据需求只对"已提交"的进行互评，假设全部提交完成即可互评:
        List<Submission> allSubmissions = submissionRepository.findByAssignment_AssignmentId(assignmentId);

        // 过滤掉自己的提交
        List<Submission> candidateSubmissions = allSubmissions.stream()
                .filter(s -> !s.getStudent().getId().equals(studentId))
                .collect(Collectors.toList());

        if (candidateSubmissions.isEmpty()) {
            // 没有可供互评的提交
            return Collections.emptyList();
        }

        int peerReviewCount = assignment.getPeerReviewCount() != 1? assignment.getPeerReviewCount() : 1;
        // 简单逻辑：随机抽取peerReviewCount个提交
        Collections.shuffle(candidateSubmissions);
        List<Submission> picked = candidateSubmissions.stream()
                .limit(peerReviewCount)
                .toList();

        return picked.stream().map(this::convertToSubmissionResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public PeerReviewResponseDTO performPeerReview(PeerReviewDTO peerReviewDTO) {
        // 获取提交记录
        Submission submission = submissionRepository.findById(peerReviewDTO.getSubmissionId())
                .orElseThrow(() -> new ResourceNotFoundException("提交记录不存在"));

        Assignment assignment = submission.getAssignment();
        LocalDateTime now = LocalDateTime.now();

        // 检查是否互评开启
        if (!Boolean.TRUE.equals(assignment.getIsPeerReview())) {
            throw new BadRequestException("该作业未开启互评功能");
        }

        // 检查互评截止时间
        if (assignment.getPeerReviewDeadline() == null || now.isAfter(assignment.getPeerReviewDeadline())) {
            throw new BadRequestException("已过互评截止时间，无法进行互评");
        }

        // 验证互评者
        User reviewer = userRepository.findById(peerReviewDTO.getReviewerId())
                .orElseThrow(() -> new ResourceNotFoundException("互评者不存在"));

        if (reviewer.getId().equals(submission.getStudent().getId())) {
            throw new BadRequestException("无法对自己的提交进行互评");
        }

        // （可选）验证该submission是否在该reviewer的互评目标中
        // 简单化不做验证或在需求中说明不需严格校验

        // 创建并保存互评记录
        PeerReview peerReview = new PeerReview();
        peerReview.setSubmission(submission);
        peerReview.setReviewer(reviewer);
        peerReview.setScore(peerReviewDTO.getScore());
        peerReview.setComment(peerReviewDTO.getComment());
        peerReview.setReviewTime(LocalDateTime.now());

        peerReview = peerReviewRepository.save(peerReview);

        return convertToPeerReviewResponseDTO(peerReview);
    }

    @Override
    public List<PeerReviewResponseDTO> getPeerReviewsByAssignment(Long assignmentId) {
        List<PeerReview> reviews = peerReviewRepository.findBySubmission_Assignment_AssignmentId(assignmentId);

        return reviews.stream()
                .map(this::convertToPeerReviewResponseDTO)
                .collect(Collectors.toList());
    }

    // 辅助方法：转换 PeerReview -> PeerReviewResponseDTO
    private PeerReviewResponseDTO convertToPeerReviewResponseDTO(PeerReview peerReview) {
        PeerReviewResponseDTO dto = new PeerReviewResponseDTO();
        dto.setReviewId(peerReview.getReviewId());
        dto.setSubmissionId(peerReview.getSubmission().getSubmissionId());
        dto.setReviewerId(peerReview.getReviewer().getId());
        dto.setScore(peerReview.getScore());
        dto.setComment(peerReview.getComment());
        dto.setReviewTime(peerReview.getReviewTime());
        dto.setReviewerName(peerReview.getReviewer().getNickname()); // 假设reviewer有nickname
        return dto;
    }












    @Override
    public List<AssignmentResponseDTO> getAssignmentsByCourse(Long courseId) {
        List<Assignment> assignments = assignmentRepository.findByClassEntity_Course_Id(courseId);
        return assignments.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AssignmentResponseDTO> getAssignmentsWithPendingSubmissions(Long teacherId) {
        List<Assignment> assignments = assignmentRepository.findByPublisher_Id(teacherId);
        return assignments.stream()
                .filter(assignment -> submissionRepository.existsByAssignment_AssignmentIdAndStatus(
                        assignment.getAssignmentId(), Submission.SubmissionStatus.未批改))
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AssignmentResponseDTO> getAssignmentsWithPendingSubmissionsByStudent(Long classId, Long studentId) {
        List<Assignment> assignments = assignmentRepository.findByClassEntity_Id(classId);
        return assignments.stream()
                .filter(assignment -> submissionRepository.existsByAssignment_AssignmentIdAndStudent_IdAndStatus(
                        assignment.getAssignmentId(), studentId, Submission.SubmissionStatus.未批改))
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AssignmentResponseDTO> getAssignmentsByStudent(Long studentId) {

        // 获取学生参与的所有班级关联
        List<ClassUser> classUsers = classUserRepository.findClassUserByStudentId(studentId);
//        List<Class> classes = classUserRepository.findClassByStudentId(studentId);

        // 提取班级ID列表
        List<Long> classIds = classUsers.stream()
                .map(classUser -> classUser.getClassEntity().getId())
                .collect(Collectors.toList());

        if (classIds.isEmpty()) {
            throw new ResourceNotFoundException("未找到学生参与的班级");
        }

        // 获取这些班级下的所有作业
        List<Assignment> assignments = assignmentRepository.findByClassEntity_IdIn(classIds);

        // 转换为 DTO
        return assignments.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }




}
