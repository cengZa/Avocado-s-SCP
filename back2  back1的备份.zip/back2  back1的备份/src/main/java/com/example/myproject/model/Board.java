package com.example.myproject.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.List;

/**
 * Post实体类，表示帖子。
 */
@Setter
@Getter
@Entity  // 指定该类为实体类，JPA会将其映射到数据库表
@Table(name = "board")  // 指定映射的表名为 "board"
public class Board {

  @Id  // 指定主键
  @GeneratedValue(strategy = GenerationType.IDENTITY)  // 主键生成策略，自动递增
  private Long boardId;  //板块id

  // Getter 和 Setter 方法
  /**
   * 关联到班级实体，表示该帖子所属的班级。
   * 一对一关系：一个帖子对应一个班级
   */


  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "class_id", nullable = false)
  @JsonIgnore
  @ApiModelProperty(value = "班级ID", example = "1")
  private Class classEntity;



  /**
   * 关联到子版块实体（可选）。表示该帖子所属的子版块
   */
  @OneToMany(mappedBy = "board", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @JsonBackReference
  private List<Topic> topics;  // 一个板块可以有多个主题

  private String boardName;  // 板块名称


  /**
   * 默认构造方法，在创建对象时自动设置postTime为当前时间。
   */


  public Class getClassEntity() {
    return classEntity;
  }

  public void setClassEntity(Class classEntity) {
    this.classEntity = classEntity;
  }


  public Long getBoardId() {
    return boardId;
  }

  public void setBoardId(Long boardId) {
    this.boardId = boardId;
  }

  public List<Topic> getTopics() {
    return topics;
  }

  public void setTopics(List<Topic> topics) {
    this.topics = topics;
  }


  public void setBoardName(String boardName) {
    this.boardName = boardName;
  }

  public String getBoardName() {
    return boardName;
  }

}
