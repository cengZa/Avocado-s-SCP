package com.example.myproject.exception;

/**
 * 文件下载相关的异常
 */
public class FileDownloadException extends BaseException {
    public FileDownloadException(String code, String message) {
        super(code, message);
    }

    public FileDownloadException(String message) {
        super("500", message);
    }
}
