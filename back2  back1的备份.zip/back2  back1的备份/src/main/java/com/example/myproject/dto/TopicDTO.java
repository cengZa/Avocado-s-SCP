package com.example.myproject.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 用于创建主题的请求数据传输对象。
 */
public class TopicDTO {


  @NotNull(message = "帖子ID不能为空")
  private Long boardId;

  @NotNull(message = "发起人ID不能为空")
  private Long topicerId;

  @NotBlank(message = "主题名称不能为空")
  private String topicName;

  private String tags;



  private String description;

  // Getter 和 Setter 方法



  public Long getTopicerId() {
    return topicerId;
  }

  public void setTopicerId(Long topicerId) {
    this.topicerId = topicerId;
  }

  public String getTopicName() {
    return topicName;
  }

  public void setTopicName(String topicName) {
    this.topicName = topicName;
  }

  public String getTags() {
    return tags;
  }

  public void setTags(String tags) {
    this.tags = tags;
  }
  public Long getBoardId() {
    return boardId;
  }

  public void setBoardId(Long boardId) {
    this.boardId = boardId;
  }
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

}
