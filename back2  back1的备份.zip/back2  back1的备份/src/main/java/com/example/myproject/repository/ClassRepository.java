package com.example.myproject.repository;

import com.example.myproject.model.Class;
import com.example.myproject.model.User;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ClassRepository extends JpaRepository<Class, Long> {
  Optional<Class> findById(Long classId);
    List<Class> findByIdIn(List<Long> classIds); // 根据班级ID列表查找班级

    // 根据教师ID查找班级
    List<Class> findByTeacher_Id(Long teacherId); // 使用 teacher_Id 访问 Teacher 实体的 ID

  @Query("SELECT c.teacher FROM Class c WHERE c.id = :classId")
  User findTeacherByClassId(@Param("classId") Long classId);
}
