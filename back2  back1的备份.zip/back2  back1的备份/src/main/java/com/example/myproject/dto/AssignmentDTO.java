package com.example.myproject.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Generated;
import lombok.Getter;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.time.LocalDateTime;

/**
 * 作业请求数据传输对象
 */
@ApiModel("作业请求数据传输对象")
@Data
@Getter
public class AssignmentDTO {

    @ApiModelProperty(value = "作业标题", required = true)
    @NotBlank(message = "作业标题不能为空")
    private String title;

    @ApiModelProperty("作业描述")
    private String description;

    @ApiModelProperty(value = "发布人ID", required = true)
    @NotNull(message = "发布人ID不能为空")
    private Long publisherId;

    @ApiModelProperty(value = "班级ID", required = true)
    @NotNull(message = "班级ID不能为空")
    private Long classId;

    @ApiModelProperty(value = "开始时间", required = true)
    @NotNull(message = "开始时间不能为空")
    @Future(message = "开始时间必须是未来的时间")
    private LocalDateTime startTime;

    @ApiModelProperty(value = "截止时间", required = true)
    @NotNull(message = "截止时间不能为空")
    @Future(message = "截止时间必须是未来的时间")
    private LocalDateTime endTime;

    @ApiModelProperty("是否开启互评")
    private Boolean isPeerReview = false;

    @ApiModelProperty("互评截止时间")
    private LocalDateTime peerReviewDeadline;

    @ApiModelProperty("每个学生需要互评多少份作业")
    private Integer peerReviewCount;
}
