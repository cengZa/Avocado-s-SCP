package com.example.myproject.repository;



import com.example.myproject.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
  // 可以根据需要定义自定义查询方法
  List<Notification> findByClassEntityId(Long classId);

  Notification findById(long id);
}
