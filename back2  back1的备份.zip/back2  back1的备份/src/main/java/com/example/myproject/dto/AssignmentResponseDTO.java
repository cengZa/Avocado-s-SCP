package com.example.myproject.dto;

import com.example.myproject.model.Assignment;
import lombok.Data;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDateTime;

/**
 * 作业响应数据传输对象 用于教师端，包含作业信息及提交人数。
 */
@Data
@Setter
public class AssignmentResponseDTO {
    private Long assignmentId;
    private String title;
    private String description;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Boolean isPeerReview;

    private Integer peerReviewCount;
    private Integer peerReviewMinScore;
    private Integer peerReviewMaxScore;

    private LocalDateTime peerReviewDeadline;
    private Assignment.AssignmentStatus status = Assignment.AssignmentStatus.未开始; // 设置默认值
    private int submittedCount;
}
