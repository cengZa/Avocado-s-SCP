package com.example.myproject.service;


import com.baidubce.qianfan.core.auth.Auth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.baidubce.qianfan.Qianfan;
import com.baidubce.qianfan.model.chat.ChatResponse;

@Service
public class WenXinService {

  //@Value("${api.key}")
  //private String apiKey;

  //@Value("${api.skey}")
  //private String skey;

  private final RestTemplate restTemplate;
  //Qianfan qianfan = new Qianfan(Auth.TYPE_OAUTH,apiKey, skey);
  Qianfan qianfan = new Qianfan(Auth.TYPE_OAUTH,"xohYNF2xecpXhQRL2S1Q8XMO", "x93khrzc9eRARNZDBsng7vtnBvBYaWB9");

  @Autowired
  public WenXinService(RestTemplate restTemplate) {
    this.restTemplate = restTemplate;
  }

  public String getResponse(String question) {
    System.out.println(question);
    // 指定模型
    ChatResponse resp = qianfan.chatCompletion()
      .model("ERNIE-4.0-8K")
      .addMessage("user", question)
      .execute();
    System.out.println(resp.getResult());


//        HttpHeaders headers = new HttpHeaders();
//        headers.set("Authorization", "Bearer " + apiKey);
//
//        String requestBody = "{ \"question\": \"" + question + "\" }";
//        HttpEntity<String> request = new HttpEntity<>(requestBody, headers);
//
//        ResponseEntity<String> response = restTemplate.exchange(
//                apiUrl,
//                HttpMethod.POST,
//                request,
//                String.class
//        );
//
//        return response.getBody();
    System.out.println(resp);
    return resp.getResult();
    //return "ok";
  }
}
