package com.example.myproject.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * 提交评分实体类
 */
@Entity
@Table(name = "submission_grade")
@Data
@NoArgsConstructor
public class SubmissionGrade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long gradeId;

    @ManyToOne
    @JoinColumn(name = "submission_id")
    private Submission submission;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private User student; // 被评分的学生

    @ManyToOne
    @JoinColumn(name = "grader_id")
    private User grader; // 评分者

    @Column(nullable = false, precision = 5, scale = 2)
    private Double score;

    @Lob
    private String comment;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createTime = LocalDateTime.now();
}
