package com.example.myproject.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 互评响应数据传输对象
 */
@Data
public class PeerReviewResponseDTO {

    private Long reviewId;
    private Long submissionId;
    private Long reviewerId;
    private Double score;
    private String comment;
    private LocalDateTime reviewTime;
    private String reviewerName;  // 可选，用于前端显示
}
