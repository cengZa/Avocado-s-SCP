package com.example.myproject.repository;

import com.example.myproject.model.PeerReview;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PeerReviewRepository extends JpaRepository<PeerReview, Long> {

    List<PeerReview> findBySubmission_Assignment_AssignmentId(Long assignmentId);

    List<PeerReview> findByReviewer_IdAndSubmission_Assignment_AssignmentId(Long reviewerId, Long assignmentId);
}

