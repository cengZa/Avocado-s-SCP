package com.example.myproject.service.serviceImpl;

import com.example.myproject.model.ClassSchedule;
import com.example.myproject.model.Course;
import com.example.myproject.repository.ClassScheduleRepository;
import com.example.myproject.repository.CourseRepository;
import com.example.myproject.service.CourseService;
import com.example.myproject.service.UserService;
import com.example.myproject.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
@Service
public class CourseServiceImpl implements  CourseService {
  @Autowired
  private CourseRepository courseRepository;
  public Result getCourseDetails(long courseId) {
//查询课程信息
    Optional<Course>course=courseRepository.findById(courseId);
    return Result.success(course);
  }
}
