package com.example.myproject.dto;

import com.example.myproject.model.Submission;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 包含评分的提交 DTO
 */
@Data
public class SubmissionWithGradeDTO {

    private Long submissionId;
    private Long assignmentId;
    private Long studentId;
    private String studentName;
    private LocalDateTime submitTime;
    private Submission.SubmissionStatus status;
    private Double score;
    private String comment;
}
