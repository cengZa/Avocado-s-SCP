package com.example.myproject.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.List;

@Setter
@Getter
/**
 * 用于返回主题信息的响应数据传输对象。
 */
public class TopicResponseDTO {


  private Long topicId;



  private Long boardId;
  private Long topicerId;
  private String topicName;
  private String tags;


  private List<String> files; // 可以存储文件名或文件路径
  private List<String> images;

  private String description;




  private Instant topicTime;
  public Long getTopicId() {
    return topicId;
  }

  public void setTopicId(Long topicId) {
    this.topicId = topicId;
  }



  public Long getTopicerId() {
    return topicerId;
  }

  public void setTopicerId(Long topicerId) {
    this.topicerId = topicerId;
  }

  public String getTopicName() {
    return topicName;
  }

  public void setTopicName(String topicName) {
    this.topicName = topicName;
  }

  public String getTags() {
    return tags;
  }

  public void setTags(String tags) {
    this.tags = tags;
  }


  public Long getBoardId() {
    return boardId;
  }

  public void setBoardId(Long boardId) {
    this.boardId = boardId;
  }

  public List<String> getFiles() {
    return files;
  }

  public void setFiles(List<String> files) {
    this.files = files;
  }

  public List<String> getImages() {
    return images;
  }

  public void setImages(List<String> images) {
    this.images = images;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
  public Instant getTopicTime() {
    return topicTime;
  }

  public void setTopicTime(Instant topicTime) {
    this.topicTime = topicTime;
  }

}
