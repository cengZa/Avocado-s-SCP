package com.example.myproject.service;

import com.example.myproject.dto.NotificationDTO;
import com.example.myproject.dto.TopicDTO;
import com.example.myproject.dto.TopicResponseDTO;
import com.example.myproject.model.Topic;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * TopicService接口，定义主题相关的业务方法。
 */
public interface TopicService {

  /**
   * 创建主题
   * @param topicDTO
   * @param files
   * @param images
   * @return
   */
  TopicResponseDTO createTopic(TopicDTO topicDTO, List<MultipartFile> files, List<MultipartFile> images)throws  Exception;

  /**
   * 根据帖子ID获取主题列表。
   * @param boardId 帖子ID
   * @return List<TopicResponseDTO>
   */
  List<TopicResponseDTO> getTopicsByBoardId(Long boardId);


  List<TopicResponseDTO> getAllTopics(Long classId);
 TopicResponseDTO getTopic(Long topicId);
  List<TopicResponseDTO> searchTopics(Long board,String keyword);

  /**
   * 删除主题。
   * @param topicId 主题ID
   */
  void deleteTopic(Long topicId);
}
