package com.example.myproject.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 用于创建评论的请求数据传输对象。
 */
public class CommentDTO {

  @NotNull(message = "主题ID不能为空")
  private Long topicId;

  @NotNull(message = "评论人ID不能为空")
  private Long commenterId;

  @NotBlank(message = "评论内容不能为空")
  private String content;



  private Long parentCommentId; // 父评论ID，用于表示评论是否是回复


  // Getter 和 Setter 方法



  public Long getCommenterId() {
    return commenterId;
  }

  public void setCommenterId(Long commenterId) {
    this.commenterId = commenterId;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }
  public Long getParentCommentId() {
    return parentCommentId;
  }

  public void setParentCommentId(Long parentCommentId) {
    this.parentCommentId = parentCommentId;
  }
  public Long getTopicId() {
    return topicId;
  }

  public void setTopicId(Long topicId) {
    this.topicId = topicId;
  }
}
