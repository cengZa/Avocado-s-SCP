package com.example.myproject.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * 提交请求数据传输对象
 */
@ApiModel("提交请求数据传输对象")
@Data
public class SubmissionDTO {

    @ApiModelProperty(value = "作业ID", required = true)
    @NotNull(message = "作业ID不能为空")
    private Long assignmentId;

    @ApiModelProperty(value = "学生ID", required = true)
    @NotNull(message = "学生ID不能为空")
    private Long studentId;

    // 可以添加备注等其他字段
}
