package com.example.myproject.repository;

import com.example.myproject.model.SubmissionGrade;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SubmissionGradeRepository extends JpaRepository<SubmissionGrade, Long> {

    Optional<SubmissionGrade> findBySubmission_SubmissionId(Long submissionId);

    boolean existsBySubmission_SubmissionId(Long submissionId);

    void deleteBySubmission_SubmissionId(Long submissionId);
}
