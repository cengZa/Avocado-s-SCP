package com.example.myproject.exception;

/**
 * 资源未找到异常。
 */
public class BadRequestException extends BaseException {

    public BadRequestException(String message) {
        super("401", message);
    }
}
