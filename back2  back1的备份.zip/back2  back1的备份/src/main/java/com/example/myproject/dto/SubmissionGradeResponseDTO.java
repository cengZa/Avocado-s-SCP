package com.example.myproject.dto;

import lombok.Data;

import java.time.Instant;

/**
 * 评分响应数据传输对象
 */
@Data
public class SubmissionGradeResponseDTO {
    private Long gradeId;
    private Long submissionId;
    private Long graderId;
    private Double score;
    private String comment;
    private Instant createTime;
}
