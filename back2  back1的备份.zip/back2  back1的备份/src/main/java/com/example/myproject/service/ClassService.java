package com.example.myproject.service;

import com.example.myproject.dto.TodayCourseDTO;
import com.example.myproject.model.Course;
import com.example.myproject.utils.Result;

import java.time.LocalDate;
import java.util.List;

public interface ClassService {
    Result getClassDetails(long classId);

    List<TodayCourseDTO> getTodayClassDetails(long userId, LocalDate date);
    Result getClassStudent(long classId);
    Result getClassTeacher(long classId);
    Long getClassStudentNumber(long classId);


}
