package com.example.myproject.service;

import com.example.myproject.dto.SubmissionGradeDTO;
import com.example.myproject.dto.SubmissionGradeResponseDTO;

public interface SubmissionGradeService {

    SubmissionGradeResponseDTO gradeSubmission(Long submissionId, SubmissionGradeDTO submissionGradeDTO);

    SubmissionGradeResponseDTO getGrade(Long submissionId, Long graderId);
}
