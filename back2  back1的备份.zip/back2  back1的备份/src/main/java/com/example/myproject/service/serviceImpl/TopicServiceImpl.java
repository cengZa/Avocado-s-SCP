package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.TopicDTO;
import com.example.myproject.dto.TopicResponseDTO;
import com.example.myproject.exception.ResourceNotFoundException;
import com.example.myproject.model.Board;
import com.example.myproject.model.Topic;
import com.example.myproject.model.User;
import com.example.myproject.repository.BoardRepository;
import com.example.myproject.repository.TopicRepository;
import com.example.myproject.service.TopicService;
import com.example.myproject.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * TopicService的实现类，处理主题相关的业务逻辑。
 */
@Service
public class TopicServiceImpl implements TopicService {

  @Autowired
  private TopicRepository topicRepository;

  @Autowired
  private BoardRepository boardRepository;

  @Autowired
  private UserService userService;
  @Resource
  private HttpServletRequest request;

  @Override
  public TopicResponseDTO createTopic(TopicDTO topicDTO, List<MultipartFile> files, List<MultipartFile> images) throws Exception{
    // 检查板块是否存在
    Board board = boardRepository.findById(topicDTO.getBoardId())
      .orElseThrow(() -> new ResourceNotFoundException("板块不存在"));

    // 检查用户是否存在
    User topicer = userService.getUserById(topicDTO.getTopicerId());
    if (topicer == null) {
      throw new ResourceNotFoundException("用户不存在");
    }

    // 创建新的Topic对象
    Topic topic = new Topic();
    topic.setBoard(board);
    topic.setTopicer(topicer);
    topic.setTopicName(topicDTO.getTopicName());
    topic.setTags(topicDTO.getTags());
    topic.setDescription(topicDTO.getDescription());

    Logger logger = LoggerFactory.getLogger(this.getClass());
    // 处理文件附件（支持多个文件）
    // 处理文件附件（支持多个文件）
    if (files != null && !files.isEmpty()) {
      List<String> fileUrls = new ArrayList<>();
      String filesDirectory = "/D:/discussion/Topics/";  // 服务器上保存文件的目录

      for (MultipartFile file : files) {
        String fileName = file.getOriginalFilename();
        String filePath = filesDirectory + fileName;

        try {
          // 将文件保存到指定目录
          file.transferTo(new File(filePath));
          // 构造可以通过浏览器访问的 URL
          // 获取基础路径，包含协议（http/https）、服务器名、端口和上下文路径
          String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
          String httpUrl = basePath + "/topic/" + fileName;  // 拼凑出可以访问的 URL，根路径下直接访问文件

          fileUrls.add(httpUrl);

          logger.info("文件路径保存成功: {}", httpUrl);
        } catch (IOException e) {
          logger.error("保存文件失败: {}", e.getMessage(), e);
          throw e;  // 如果保存文件失败，则抛出异常
        }
      }

      // 设置多个文件的 URL 路径
     topic.setFiles(fileUrls);
    } else {
      logger.info("未提供文件，跳过文件保存.");
    }


// 处理图片附件（支持多个图片）
    if (images != null && !images.isEmpty()) {
      List<String> imageUrls = new ArrayList<>();
      String imagesDirectory = "/D:/discussion/Topics/";  // 图片保存目录

      for (MultipartFile image : images) {
        String imageName = image.getOriginalFilename(); // 获取图片文件名
        String imagePath = imagesDirectory + imageName;  // 拼接保存路径

        try {
          // 将图片保存到指定目录
          image.transferTo(new File(imagePath));
          // 生成可以通过浏览器访问的 URL
          String baseUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() ;
          String imageUrl=baseUrl+"/topic/"+imageName;
          imageUrls.add(imageUrl);

          logger.info("图片路径保存成功: {}", imageUrl);
        } catch (IOException e) {
          logger.error("保存图片失败: {}", e.getMessage(), e);
          throw e;  // 如果保存图片失败，则抛出异常
        }
      }

      // 设置多个图片的 URL 路径
      topic.setImages(imageUrls);
    } else {
      logger.info("未提供图片，跳过图片保存.");
    }

    topic = topicRepository.save(topic);
    // 转换为 TopicResponseDTO
    return convertToResponseDTO(topic);
  }

  @Override
  public List<TopicResponseDTO> getTopicsByBoardId(Long boardId) {
    Logger logger = LoggerFactory.getLogger(TopicServiceImpl.class);

    List<Topic> topics = topicRepository.findByBoard_BoardId(boardId);
    if (topics.isEmpty()) {
      logger.info("No topics found for board ID: {}", boardId);
    } else {
      logger.info("Found {} topics for board ID: {}", topics.size(), boardId);
    }
    return topics.stream()
      .map(this::convertToResponseDTO)
      .collect(Collectors.toList());
  }

  @Override
  public List<TopicResponseDTO> searchTopics(Long boardId,String keyword) {
    // 根据 boardId 查找主题
    List<Topic> topics = topicRepository.findByBoard_BoardId(boardId);

    // 如果没有找到板块下的主题，直接返回空列表
    if (topics.isEmpty()) {
      return new ArrayList<>();
    }

    if (keyword == null || keyword.trim().isEmpty()) {
      // 返回所有板块下的主题，转换为 TopicResponseDTO
      return topics.stream()
        .map(this::convertToResponseDTO)
        .collect(Collectors.toList());
    }
    // 过滤出包含关键字的主题（按主题名称、标签、描述字段进行匹配）
    List<Topic> filteredTopics = topics.stream()
      .filter(topic ->
        (topic.getTopicName() != null && topic.getTopicName().contains(keyword)) ||
          (topic.getTags() != null && topic.getTags().contains(keyword)) ||
          (topic.getDescription() != null && topic.getDescription().contains(keyword))
      )
      .collect(Collectors.toList());

    // 如果没有找到匹配的主题，返回空列表
    if (filteredTopics.isEmpty()) {
      return new ArrayList<>();  // 返回空列表表示没有匹配的主题
    }

    // 返回匹配的主题列表，转换为 TopicResponseDTO
    return filteredTopics.stream()
      .map(this::convertToResponseDTO)
      .collect(Collectors.toList());
  }
@Override
public List<TopicResponseDTO> getAllTopics(Long classId) {
  // 获取日志记录器
  Logger logger = LoggerFactory.getLogger(getClass());

  // 打印日志，查看是否进入该方法
  // 获取所有主题
  List<Topic> topics = topicRepository.findAll(); // 获取所有主题

  // 如果没有找到任何主题，打印日志
  if (topics.isEmpty()) {
    logger.info("没有找到任何主题。");
  } else {
    // 打印主题数量
    logger.info("找到的主题数量: {}", topics.size());
  }

  // 获取与班级相关的所有板块
  List<Board> boards = boardRepository.findByClassEntity_Id(classId); // 根据班级ID获取所有板块
  if (boards.isEmpty()) {
    logger.info("没有找到与班级ID {} 相关的板块。", classId);
  } else {
    logger.info("找到与班级ID {} 相关的板块数量: {}", classId, boards.size());
  }

  // 筛选出属于指定班级的主题
  List<TopicResponseDTO> filteredTopics = topics.stream()
    .filter(topic -> {
      // 获取主题对应的板块ID
      Long boardId = topic.getBoard().getBoardId();
      // 查询对应板块
      Board board = boardRepository.findByBoardId(boardId).orElse(null);

      // 打印日志，检查每个板块的班级信息
      if (board != null) {
        logger.debug("主题ID: {}，对应板块ID: {}，班级ID: {}", topic.getTopicId(), boardId, board.getClassEntity().getId());
      }

      // 检查板块是否属于指定的班级
      return board != null && boards.stream()
        .anyMatch(b -> b.getBoardId().equals(boardId)); // 检查主题的板块ID是否在班级相关的板块中
    })
    // 使用 convertToResponseDTO 方法转换为 TopicResponseDTO
    .map(this::convertToResponseDTO)
    .collect(Collectors.toList()); // 收集过滤后的结果并返回

  // 打印最终过滤后的主题数量
  logger.info("筛选后的主题数量: {}", filteredTopics.size());

  // 返回筛选后的主题列表
  return filteredTopics;
}
@Override
 public TopicResponseDTO getTopic(Long topicId){
    Optional<Topic> optionalTopic=topicRepository.findByTopicId(topicId);
  Topic topic = optionalTopic.get();
  return convertToResponseDTO(topic);


}
  @Override
  public void deleteTopic(Long topicId) {
    topicRepository.deleteById(topicId);
  }


  private TopicResponseDTO convertToResponseDTO(Topic topic) {
    TopicResponseDTO dto = new TopicResponseDTO();
    dto.setTopicId(topic.getTopicId());
    dto.setBoardId(topic.getBoard().getBoardId());
    dto.setTopicerId(topic.getTopicer().getId());
    dto.setTopicName(topic.getTopicName());
    dto.setTags(topic.getTags());
    dto.setFiles(topic.getFiles());
    dto.setImages(topic.getImages());
    dto.setDescription(topic.getDescription());
    dto.setTopicTime(topic.getTopicTime());
    return dto;
  }
}
