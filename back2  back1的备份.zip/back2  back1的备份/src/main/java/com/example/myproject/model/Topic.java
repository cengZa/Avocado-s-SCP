package com.example.myproject.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.File;
import java.time.Instant;
import java.util.List;

/**
 * Topic实体类，表示主题。
 */
@Setter
@Getter
@Entity  // 指定这是一个实体类，映射到数据库表
@Table(name = "topic")  // 指定数据库表名为 "topic"
public class Topic {
  @Id  // 指定主键
  @GeneratedValue(strategy = GenerationType.IDENTITY)  // 主键生成策略为自增
  private Long topicId;  // 主题ID

  /**
   * 与Post实体的多对一关系，一个主题属于一个帖子。
   */

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "board_id")  // 外键列名为 "post_id"
  @JsonManagedReference // 这是父对象（Notification）的引用
  private Board board; // 所属的板块

  /**
   * 与User实体的多对一关系，主题发起人。
   */

  @ManyToOne
  @JoinColumn(name = "topicer_id")  // 外键列名为 "topicer_id"
  @JsonIgnore
  private User topicer;  // 主题发起人

  private String topicName;  // 主题名称
  private String tags;  // 标签（关键词）



  private Instant topicTime;  // 评论时间


  private String description;//主题内容

  @ElementCollection
  @CollectionTable(name = "topic_files", joinColumns = @JoinColumn(name = "topic_id"))
  @Column(name = "file_path")  // 这里是每个文件路径的列名
  @ApiModelProperty(value = "主题附件", example = "附件1.pdf")
  private List<String> files; // 可以存储文件名或文件路径
  @ElementCollection
  @CollectionTable(name = "topic_files", joinColumns = @JoinColumn(name = "topic_id"))
  @Column(name = "image_path")  // 这里是每个文件路径的列名
  @ApiModelProperty(value = "主题附件", example = "附件1.pdf")
  private List<String> images; // 可以存储文件名或文件路径
  public Topic() {
    this.topicTime = Instant.now();
  }


  /**
   * 无参构造函数，初始化主题创建时间为当前时间。
   */

  public Long getTopicId() {
    return topicId;
  }

  public void setTopicId(Long topicId) {
    this.topicId = topicId;
  }



  public User getTopicer() {
    return topicer;
  }

  public void setTopicer(User topicer) {
    this.topicer = topicer;
  }

  public String getTopicName() {
    return topicName;
  }

  public void setTopicName(String topicName) {
    this.topicName = topicName;
  }

  public String getTags() {
    return tags;
  }

  public void setTags(String tags) {
    this.tags = tags;
  }


  public List<String> getFiles() {
    return files;
  }

  public void setFiles(List<String> files) {
    this.files = files;
  }

  public List<String> getImages() {
    return images;
  }

  public void setImages(List<String> images) {
    this.images = images;
  }
  public Board getBoard() {
    return board;
  }

  public void setBoard(Board board) {
    this.board = board;
  }
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
  public Instant getTopicTime() {
    return topicTime;
  }

  public void setTopicTime(Instant topicTime) {
    this.topicTime = topicTime;
  }
}
