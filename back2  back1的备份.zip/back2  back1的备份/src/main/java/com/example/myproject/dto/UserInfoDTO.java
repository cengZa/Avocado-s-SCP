package com.example.myproject.dto;



import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel("个人信息 DTO")
public class UserInfoDTO{


    @ApiModelProperty(value = "用户ID", example = "101")
    private Long id;//用户id

    @ApiModelProperty(value = "学号和工号", example = "22301115")
    private String username;//学号或工号
    @ApiModelProperty(value = "姓名", example = "崔叶林")
    private String nickname;//姓名


  @ApiModelProperty(value = "学院", example = "软件学院")
  private String academy;//姓名
    @ApiModelProperty(value = "头像")
    private String avatar;//创建用户头像
    @ApiModelProperty(value = "邮箱")
    private String email;//邮箱

    @ApiModelProperty(value = "头像图片列表")
    private String[] avatars;//头像图片列表


    @ApiModelProperty(value = "密码")
    private String password;//头像图片列表

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String[] getAvatars() {
        return avatars;
    }

    public void setAvatars(String[] avatars) {
        this.avatars = avatars;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
  public String getAcademy() {
    return academy;
  }

  public void setAcademy(String academy) {
    this.academy = academy;
  }

}
