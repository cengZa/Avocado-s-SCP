package com.example.myproject.repository;

import com.example.myproject.model.Assignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AssignmentRepository extends JpaRepository<Assignment, Long> {

    List<Assignment> findByPublisher_Id(Long publisherId);

    List<Assignment> findByClassEntity_Id(Long classId);

    List<Assignment> findByClassEntity_Course_Id(Long courseId);

    List<Assignment> findByClassEntity_IdIn(List<Long> classIds);

    //用来让老师查看作业
    List<Assignment> findByClassEntity_IdAndPublisher_Id(Long classId, Long publisherId);
}
