package com.example.myproject.controller;

import com.example.myproject.dto.*;
import com.example.myproject.exception.BadRequestException;
import com.example.myproject.exception.BaseException;

import com.example.myproject.service.AssignmentService;
import com.example.myproject.utils.Result;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.File;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.List;

/**
 * 作业管理控制器
 */
@RestController
@RequestMapping("/assignments")
@Api(tags = "作业管理接口")
public class AssignmentController {

    @Autowired
    private AssignmentService assignmentService;


    /**
     * 发布作业
     */
    @PostMapping("/create")
    @ApiOperation(value = "发布作业", notes = "教师发布新的作业与附件")
    public Result<AssignmentResponseDTO> createAssignment(
            @Valid @ApiParam(value = "作业信息", required = true) @RequestPart("assignment") AssignmentDTO assignmentDTO,
            @ApiParam(value = "附件文件") @RequestPart(value = "files", required = false) List<MultipartFile> files) {
        AssignmentResponseDTO responseDTO = assignmentService.createAssignment(assignmentDTO, files);
        return Result.success(responseDTO, "作业发布成功");
    }

    /**
     * 获取教师在特定班级发布的所有作业及提交人数
     */
    @GetMapping("/class/{classId}/publisher/{publisherId}")
    @ApiOperation(value = "获取教师的作业列表", notes = "教师查看自己发布的班级的作业列表")
    public Result<List<AssignmentResponseDTO>> getTeacherAssignments(@PathVariable Long classId, @PathVariable Long publisherId) {
        List<AssignmentResponseDTO> assignments = assignmentService.getAssignmentsForTeacher(classId, publisherId);
        return Result.success(assignments, "老师获取作业列表成功");
    }

    /**
     * 获取学生在特定班级的所有作业及其提交信息
     */
    @GetMapping("/class/{classId}/student/{studentId}")
    @ApiOperation(value = "获取学生的作业列表", notes = "学生可以在指定班级下查看作业列表，显示是否已提交")
    public Result<List<AssignmentWithSubmissionDTO>> getStudentAssignments(
            @PathVariable Long classId,
            @PathVariable Long studentId) {
        List<AssignmentWithSubmissionDTO> assignments = assignmentService.getAssignmentsForStudent(classId, studentId);
        return Result.success(assignments, "获取作业列表成功");
    }

    /**
     * 查看作业详情
     */
    @GetMapping("/{assignmentId}")
    @ApiOperation(value = "查看作业详情", notes = "查看作业的详细信息")
    public Result<AssignmentResponseDTO> getAssignmentById(@PathVariable Long assignmentId) {
        AssignmentResponseDTO assignment = assignmentService.getAssignmentById(assignmentId);
        return Result.success(assignment);
    }

    /**
     * 删除指定的作业
     *
     * @param assignmentId 作业 ID
     * @param publisherId  发布人（教师）ID
     * @return 操作结果
     */
    @DeleteMapping("/{assignmentId}/publisher/{publisherId}")
    @ApiOperation(value = "删除作业", notes = "教师删除自己发布的作业")
    public Result<Void> deleteAssignment(
            @PathVariable Long assignmentId,
            @PathVariable Long publisherId) {
        assignmentService.deleteAssignment(assignmentId, publisherId);
        return Result.success(null, "作业删除成功");
    }

    /**
     * 下载作业的所有附件
     */
    //TODO:  他会在该位置生成压缩文件 这样在实际生产中很有问题 那个压缩文件应该是临时文件 响应回去后删掉才行
    @GetMapping("/{assignmentId}/attachments/download")
    @ApiOperation(value = "下载作业的所有附件", notes = "下载指定作业的所有附件")
    public ResponseEntity<Resource> downloadAllAssignmentAttachments(@PathVariable Long assignmentId) {
        File zipFile = assignmentService.createZipFileForAttachments(assignmentId);

        Resource resource;
        try {
            resource = new UrlResource(zipFile.toURI());
        } catch (MalformedURLException e) {
            throw new RuntimeException("文件读取失败", e);
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/zip"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"attachments.zip\"")
                .body(resource);
    }

    /**
     * 提交作业 submission
     */
    @PostMapping("/{assignmentId}/submissions")
    @ApiOperation(value = "提交作业", notes = "学生提交作业，可以包含文件附件")
    @ApiResponses({
            @ApiResponse(code = 200, message = "提交成功"),
            @ApiResponse(code = 400, message = "提交失败"),
            @ApiResponse(code = 404, message = "作业未找到")
    })
    public Result<SubmissionResponseDTO> submitAssignment(
            @PathVariable Long assignmentId,
            @RequestParam Long studentId,
            @RequestParam(value = "files", required = false) List<MultipartFile> files) {
        SubmissionResponseDTO submission = assignmentService.submitAssignment(assignmentId, studentId, files);
        return Result.success(submission, "提交成功");
    }

    @GetMapping("/{assignmentId}/submissions")
    @ApiOperation(value = "获取指定作业的提交列表", notes = "教师或有权限的用户查看所有提交信息")
    public Result<List<SubmissionResponseDTO>> getSubmissionsByAssignment(@PathVariable Long assignmentId) {
        List<SubmissionResponseDTO> submissions = assignmentService.getSubmissionsByAssignment(assignmentId);
        return Result.success(submissions, "查询成功");
    }


    /**
     * 教师批改学生的作业提交
     */
    @PostMapping("/{assignmentId}/submissions/{submissionId}/grade")
    @ApiOperation(value = "批改作业", notes = "教师为学生的作业提交打分并给出评语")
    public Result<SubmissionResponseDTO> gradeSubmission(
            @PathVariable Long assignmentId,
            @PathVariable Long submissionId,
            @RequestBody GradeSubmissionDTO gradeRequest) {
        SubmissionResponseDTO updatedSubmission = assignmentService.gradeSubmission(assignmentId, submissionId, gradeRequest);
        return Result.success(updatedSubmission, "批改成功");
    }

    /**
     * 下载学生提交的作业附件ZIP文件
     */
    @GetMapping("/{assignmentId}/submissions/{submissionId}/download")
    @ApiOperation(value = "下载学生提交的作业附件", notes = "下载学生提交的压缩包文件")
    public ResponseEntity<Resource> downloadSubmissionFile(
            @PathVariable Long assignmentId,
            @PathVariable Long submissionId) {
        Resource resource = assignmentService.getSubmissionFile(assignmentId, submissionId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"submission_" + submissionId + ".zip\"")
                .body(resource);
    }

    @ApiOperation(value = "获取可互评的提交列表", notes = "学生在作业截止后获取需要自己互评的提交列表")
    @GetMapping("/{assignmentId}/peer-review-targets")
    public Result<List<SubmissionResponseDTO>> getSubmissionsForPeerReview(
            @PathVariable Long assignmentId,
            @RequestParam Long studentId) {
        List<SubmissionResponseDTO> submissions = assignmentService.getSubmissionsForPeerReview(assignmentId, studentId);
        return Result.success(submissions, "获取互评目标成功");
    }

    @ApiOperation(value = "进行互评", notes = "学生对指定的提交进行互评")
    @PostMapping("/{assignmentId}/peer-review")
    public Result<PeerReviewResponseDTO> performPeerReview(
            @PathVariable Long assignmentId,
            @RequestBody PeerReviewDTO peerReviewDTO) {
        PeerReviewResponseDTO response = assignmentService.performPeerReview(peerReviewDTO);
        return Result.success(response, "互评成功");
    }

    @ApiOperation(value = "查看作业下的互评详情", notes = "教师查看某作业所有互评信息")
    @GetMapping("/{assignmentId}/peer-reviews")
    public Result<List<PeerReviewResponseDTO>> getPeerReviewsByAssignment(@PathVariable Long assignmentId) {
        List<PeerReviewResponseDTO> reviews = assignmentService.getPeerReviewsByAssignment(assignmentId);
        return Result.success(reviews, "查询成功");
    }










    /**
     * 获取课程的所有作业
     */
    @GetMapping("/course/{courseId}")
    @ApiOperation(value = "获取课程的所有作业", notes = "根据课程ID获取所有作业")
    public Result<List<AssignmentResponseDTO>> getAssignmentsByCourse(@PathVariable Long courseId) {
        List<AssignmentResponseDTO> assignments = assignmentService.getAssignmentsByCourse(courseId);
        return Result.success(assignments);
    }

    /**
     * 获取有未批改提交的作业
     */
    @GetMapping("/pending")
    @ApiOperation(value = "获取有未批改提交的作业", notes = "教师获取发布的有未批改提交的作业")
    public Result<List<AssignmentResponseDTO>> getAssignmentsWithPendingSubmissions(@RequestParam Long teacherId) {
        List<AssignmentResponseDTO> assignments = assignmentService.getAssignmentsWithPendingSubmissions(teacherId);
        return Result.success(assignments);
    }

    /**
     * 获取目标班级下目标学生的有未批改提交的作业
     */
    @GetMapping("/class/{classId}/student/{studentId}/pending")
    @ApiOperation(value = "获取目标班级下目标学生的有未批改提交的作业", notes = "获取目标班级下目标学生的有未批改提交的作业")
    public Result<List<AssignmentResponseDTO>> getAssignmentsWithPendingSubmissionsByStudent(
            @PathVariable Long classId, @PathVariable Long studentId) {
        List<AssignmentResponseDTO> assignments = assignmentService.getAssignmentsWithPendingSubmissionsByStudent(classId, studentId);
        return Result.success(assignments);
    }

    /**
     * 获取目标学生的所有作业
     */
    @GetMapping("/student/{studentId}/all")
    @ApiOperation(value = "获取学生的所有作业", notes = "学生可以看到自己参与的所有班级的所有作业")
    public Result<List<AssignmentResponseDTO>> getAssignmentsByStudent(@PathVariable Long studentId) {
        List<AssignmentResponseDTO> assignments = assignmentService.getAssignmentsByStudent(studentId);
        return Result.success(assignments, "获取作业列表成功");
    }

    /**
     * 查看作业列表（根据发布人）
     */
    @GetMapping("/publisher/{publisherId}")
    @ApiOperation(value = "查看作业列表", notes = "教师查看自己发布的作业列表")
    public Result<List<AssignmentResponseDTO>> getAssignmentsByPublisher(@PathVariable Long publisherId) {
        List<AssignmentResponseDTO> assignments = assignmentService.getAssignmentsByPublisher(publisherId);
        return Result.success(assignments);
    }

    /**
     * 查看作业列表（根据课程 其实在这里是班级）
     */
    @GetMapping("/class/{classId}")
    @ApiOperation(value="查看作业列表", notes = "查看自己班级的作业列表")
    public Result<List<AssignmentResponseDTO>> getStudentAssignments0(@PathVariable Long classId) {
        List<AssignmentResponseDTO> assignments = assignmentService.getAssignmentsByClass(classId);
        return Result.success(assignments);
    }
}
