package com.example.myproject.controller;

import com.alibaba.fastjson.JSONObject;
import com.baidubce.qianfan.Qianfan;
import com.baidubce.qianfan.core.auth.Auth;
import com.baidubce.qianfan.model.chat.ChatResponse;
import com.example.myproject.model.QuestionRequest;
import com.example.myproject.service.WenXinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import com.google.gson.Gson;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Stream;

@RestController("/ai")
public class WenXinController {

  @Autowired
  private WenXinService wenXinService;

  private final Gson gson = new Gson();

  @PostMapping("/sole")
  public String askQuestion(@RequestBody QuestionRequest request) {
    //return "ok";
    return wenXinService.getResponse(request.getQuestion());
  }

  // 处理流式聊天接口
  @PostMapping("/ask")
  public Flux<String> testStream(@RequestBody QuestionRequest request) {
    // 获取 qianfan 的流式响应
    return Flux.create(sink -> {
      // 使用 qianfan 的 API 获取流式数据
      Qianfan qianfan= new Qianfan(Auth.TYPE_OAUTH,"xohYNF2xecpXhQRL2S1Q8XMO", "x93khrzc9eRARNZDBsng7vtnBvBYaWB9");

      qianfan.chatCompletion()
        .addMessage("user", request.getQuestion())
        .executeStream()
        .forEachRemaining(chunk -> {
          sink.next(chunk.getResult());
        });
      sink.complete();  // 数据发送完成
    });
  }

}
