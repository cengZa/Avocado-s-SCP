package com.example.myproject.repository;

import com.example.myproject.model.NotificationReadStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationReadStatusRepository extends JpaRepository<NotificationReadStatus, Long> {


  // 根据通知ID和班级ID查询已读人数
  long countByNotificationIdAndClassEntityIdAndReadStatus(Long notificationId, Long classId, boolean read);
  // 根据学生ID和班级ID查询所有通知及其状态
  List<NotificationReadStatus> findByStudentIdAndClassEntityId(Long studentId, Long classId);
  // 根据学生ID、通知ID和班级ID查询
  NotificationReadStatus findByStudentIdAndNotificationIdAndClassEntityId(Long studentId, Long notificationId, Long classId);
}
