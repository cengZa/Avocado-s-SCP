package com.example.myproject.service;

import com.example.myproject.dto.*;
import com.example.myproject.model.Assignment;
import com.example.myproject.model.Submission;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.time.LocalDateTime;
import java.util.List;

public interface AssignmentService {

    AssignmentResponseDTO createAssignment(AssignmentDTO assignmentDTO, List<MultipartFile> files);
    void saveAssignmentAttachment(Assignment assignment, MultipartFile file);

    List<AssignmentResponseDTO> getAssignmentsByPublisher(Long publisherId);

    List<AssignmentWithSubmissionDTO> getAssignmentsForStudent(Long classId, Long studentId); // 学生在目标班级下获取作业列表，包含提交信息
    List<AssignmentResponseDTO> getAssignmentsForTeacher(Long classId, Long publisherId);// 老师拿自己班级自己发布的作业
    void deleteAssignment(Long assignmentId, Long publisherId); //删除指定的作业
//    void updateAssignmentSatus(Long assignmentId);
    AssignmentResponseDTO getAssignmentById(Long assignmentId);

    File createZipFileForAttachments(Long assignmentId);
    SubmissionResponseDTO submitAssignment(Long assignmentId, Long studentId, List<MultipartFile> files);
    Assignment.AssignmentStatus updateAssignmentStatus(Assignment assignment, Submission submission, LocalDateTime now);
    Submission.SubmissionStatus updateSubmissionStatus(Submission submission, Assignment assignment, LocalDateTime now);
    SubmissionResponseDTO gradeSubmission(Long assignmentId, Long submissionId, GradeSubmissionDTO gradeRequest);
    Resource getSubmissionFile(Long assignmentId, Long submissionId);
    List<SubmissionResponseDTO> getSubmissionsByAssignment(Long assignmentId);

    List<SubmissionResponseDTO> getSubmissionsForPeerReview(Long assignmentId, Long studentId);// 获取需要该学生互评的提交列表（不包括自己的提交）
    PeerReviewResponseDTO performPeerReview(PeerReviewDTO peerReviewDTO);// 学生对指定的提交进行互评
    List<PeerReviewResponseDTO> getPeerReviewsByAssignment(Long assignmentId);// 教师查看某作业下的所有互评信息



    List<AssignmentResponseDTO> getAssignmentsByClass(Long classId);

    List<AssignmentResponseDTO> getAssignmentsByCourse(Long courseId);

    List<AssignmentResponseDTO> getAssignmentsWithPendingSubmissions(Long teacherId);

    List<AssignmentResponseDTO> getAssignmentsWithPendingSubmissionsByStudent(Long classId, Long studentId);

    List<AssignmentResponseDTO> getAssignmentsByStudent(Long studentId);



}
