package com.example.myproject.repository;

import com.example.myproject.model.AssignmentAttachment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AssignmentAttachmentRepository extends JpaRepository<AssignmentAttachment, Long> {

    List<AssignmentAttachment> findByAssignment_AssignmentId(Long assignmentId);
}
