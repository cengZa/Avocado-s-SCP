package com.example.myproject.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.time.Instant;

/**
 * 作业附件实体类
 */
@Entity
@Table(name = "assignment_attachment")
@Data
@NoArgsConstructor
public class AssignmentAttachment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attachmentId;

    @ManyToOne
    @JoinColumn(name = "assignment_id")
    // 使用 @JsonBackReference 表示这是“被管理者”一方
    @JsonBackReference
    private Assignment assignment;

    @Column(length = 255)
    private String fileName;

    @Column(length = 255)
    private String filePath;

    @Column(nullable = false, updatable = false)
    private Instant uploadTime = Instant.now();
}
