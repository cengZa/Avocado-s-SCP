package com.example.myproject.service.serviceImpl;

import com.example.myproject.dto.ClassCourseInfoDTO;
import com.example.myproject.dto.TodayCourseDTO;
import com.example.myproject.model.ClassSchedule;
import com.example.myproject.model.Course;
import com.example.myproject.model.User;
import com.example.myproject.model.WeekType;
import com.example.myproject.repository.ClassRepository;
import com.example.myproject.repository.ClassScheduleRepository;
import com.example.myproject.repository.ClassUserRepository;
import com.example.myproject.service.ClassService;
import com.example.myproject.service.UserService;
import com.example.myproject.utils.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.time.temporal.WeekFields;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ClassServiceImpl implements ClassService {

    @Autowired
    private ClassScheduleRepository classScheduleRepository;
    @Autowired
    private UserService userService;
    @Autowired
    private ClassUserRepository classUserRepository;
  @Autowired
  private ClassRepository classRepository;
    @Override
    @Transactional(readOnly = true)
    public Result getClassDetails(long classId) {
        // 查询班级信息
        List<ClassSchedule> classSchedules = classScheduleRepository. findByClassId(classId);

        if (classSchedules.isEmpty()) {
            return Result.error("500","班级信息不存在");
        }

        // 返回班级信息
        return Result.success(classSchedules);
    }

  @Override
  public List<TodayCourseDTO> getTodayClassDetails(long userId, LocalDate date) {

    // 创建日志对象
   final Logger logger = LoggerFactory.getLogger(ClassServiceImpl.class);

    // 1. 获取用户所有课程信息
    logger.info("正在获取用户 {} 的所有课程信息", userId);
    List<ClassCourseInfoDTO> allCourses = userService.getStudentCourses(userId);
    logger.info("已成功获取 {} 门课程，用户 ID: {}", allCourses.size(), userId);

    // 2. 提取所有班级ID
    logger.info("正在提取课程信息中的班级ID...");
    List<Long> classIds = allCourses.stream()
      .map(ClassCourseInfoDTO::getClassId) // 获取每个课程的班级ID
      .collect(Collectors.toList());
    logger.debug("已提取班级ID列表: {}", classIds);

    // 3. 根据班级ID查询课程表信息
    logger.info("正在根据班级ID查询课程表...");
    List<ClassSchedule> schedules = classScheduleRepository.findByClassEntity_IdIn(classIds);
    logger.info("已成功获取 {} 条课程表信息", schedules.size());

    // 4. 获取今天是星期几
    String todayDay = date.getDayOfWeek().name().substring(0, 1) + date.getDayOfWeek().name().substring(1).toLowerCase();

    logger.info("今天是: {}", todayDay);

    // 5. 判断今天是单周还是双周
    boolean isOddWeek = isOddWeek(date);
    logger.info("今天是单周: {}", isOddWeek);

    // 6. 过滤符合日期条件的课程表记录
    logger.info("正在过滤出符合今天日期 {} 和单双周条件的课程安排", todayDay);

    List<ClassSchedule> todaySchedules = schedules.stream()
      .filter(schedule -> {
        // 获取课程的 class_days 字段并检查是否包含今天的星期
        String classDays = schedule.getClassDays();
        boolean matchesDay = classDays.contains(todayDay); // 判断日期是否匹配

        // 判断单双周
        boolean matchesWeek = matchesWeekType(schedule.getWeekType(), isOddWeek);

        // 只有日期和单双周都匹配的课程才符合条件
        return matchesDay && matchesWeek;
      })
      .collect(Collectors.toList());

    logger.info("今日课程表中共找到 {} 条符合条件的课程", todaySchedules.size());

    // 7. 构造 DTO，使用从 allCourses 提取的教师信息
    logger.info("正在为符合条件的课程表构建 DTO...");
    List<TodayCourseDTO> result = todaySchedules.stream().map(schedule -> {
      // 找到当前 schedule 的班级对应的课程信息
      ClassCourseInfoDTO courseInfo = allCourses.stream()
        .filter(info -> info.getClassId().equals(schedule.getClassEntity().getId())) // 根据班级ID匹配课程信息
        .findFirst()
        .orElseThrow(() -> new RuntimeException("未找到班级ID为 " + schedule.getClassEntity().getId() + " 的课程信息"));

      // 打印当前正在构建的 DTO 信息
      logger.debug("正在构建 DTO，课程名称: {}, 教师: {}", courseInfo.getCourseName(), courseInfo.getTeacherName());

      // 返回 TodayCourseDTO
      return new TodayCourseDTO(
        courseInfo.getCourseName(),             // 从 ClassCourseInfoDTO 获取课程名称
        schedule.getLocation(),                // 课程地点
        schedule.getStartTime(),    // 课程开始时间
        schedule.getEndTime(),      // 课程结束时间
        courseInfo.getTeacherName()            // 从 ClassCourseInfoDTO 获取教师名字
      );
    }).collect(Collectors.toList());

    logger.info("成功为 {} 门课程构建 DTO", result.size());

    // 返回结果
    return result;
  }

  // 判断当前日期是否为单周
  private boolean isOddWeek(LocalDate date) {
    // 获取当前日期是今年的第几周
    int weekOfYear = date.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);

    // 如果周次是奇数，则为单周
    return weekOfYear % 2 != 0;
  }

  // 判断课程的 week_type 是否与当前周次匹配
  private boolean matchesWeekType(WeekType weekType, boolean isOddWeek) {
    switch (weekType) {
      case EVERY_WEEK:
        return true;  // 每周都有课程
      case ODD_WEEK:
        return isOddWeek;  // 仅在单周
      case EVEN_WEEK:
        return !isOddWeek;  // 仅在双周
      default:
        return false;  // 未知的周次类型
    }
  }

  // 判断当前日期是否为单周


  @Override
  public Result getClassStudent(long classId){
      //查询一个班级的所有学生的信息
      List<User> user= classUserRepository.findStudentByClassId(classId);
      return Result.success(user);
    }
  @Override
  public Result getClassTeacher(long classId){
    //查询一个班级的所有学生的信息
    User user= classRepository.findTeacherByClassId(classId);
    return Result.success(user);
  }
  @Override
  public Long getClassStudentNumber(long classId){
    long studentNumber= classUserRepository.countByClassEntityId(classId);
    return studentNumber;
  }

}
