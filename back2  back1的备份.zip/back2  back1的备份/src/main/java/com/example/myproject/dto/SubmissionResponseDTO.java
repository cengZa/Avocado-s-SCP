// 更新后的 SubmissionResponseDTO
package com.example.myproject.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
@ApiModel("提交响应 DTO")
public class SubmissionResponseDTO {

    @ApiModelProperty("提交ID")
    private Long submissionId;

    @ApiModelProperty("作业ID")
    private Long assignmentId;

    @ApiModelProperty("学生ID")
    private Long studentId;

    @ApiModelProperty("学生姓名")
    private String student_name;

    @ApiModelProperty("提交时间")
    private LocalDateTime submitTime;

    @ApiModelProperty("提交状态")
    private String status;  // 已提交, 未批改, 已批改

    @ApiModelProperty("分数")
    private Integer score;

    @ApiModelProperty("评语")
    private String comment;

    @ApiModelProperty("文件路径（ZIP文件）")
    private String filePath;

}
