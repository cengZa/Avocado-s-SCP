package com.example.myproject.service.serviceImpl;


import com.example.myproject.model.Resource;
import com.example.myproject.repository.ResourceRepository;
import com.example.myproject.service.ResourceService;
import com.example.myproject.utils.FilesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ResourceServiceImpl implements ResourceService {

  @Autowired
  private ResourceRepository resourceRepository; // 数据库操作接口

  private static final String uploadDir = "D:/courseresource/"; // 基础目录

  @Override
  public void createClassFolder(Long classId) {
    String folderPath = uploadDir + classId;
    File classFolder = new File(folderPath);
    if (!classFolder.exists()) {
      classFolder.mkdirs(); // 创建班级文件夹
      Resource resource = new Resource();
      resource.setFileName(String.valueOf(classId));
      resource.setFilePath(folderPath);
      resource.setClassId(classId);
      resource.setIsFolder(true); // 设置为文件夹
      resourceRepository.save(resource);
    }
  }

  @Override
  public void createSubFolder(Long classId, Long parentFolderId, String folderName) {
    Resource parentFolder = resourceRepository.findById(parentFolderId)
      .orElseThrow(() -> new RuntimeException("父文件夹不存在，ID: " + parentFolderId));
    // 使用父文件夹的路径构建子文件夹的路径
    String folderPath = parentFolder.getFilePath() + "/" + folderName;

    File subFolder = new File(folderPath);
    if (!subFolder.exists()) {
      subFolder.mkdirs(); // 创建子文件夹
      // 保存子文件夹信息到数据库
      Resource resource = new Resource();
      resource.setFileName(folderName);
      resource.setFilePath(folderPath);
      resource.setClassId(classId);
      resource.setParentFolderId(parentFolderId); // 设置父文件夹 ID
      resource.setIsFolder(true); // 设置为文件夹
      resourceRepository.save(resource);
    }
  }

  @Override
  public void uploadFiles(Long classId, Long parentFolderId, List<MultipartFile> files) throws IOException {
    Resource parentFolder = resourceRepository.findById(parentFolderId)
      .orElseThrow(() -> new RuntimeException("父文件夹不存在，ID: " + parentFolderId));

    String folderPath = parentFolder.getFilePath();

    File folder = new File(folderPath);
    for (MultipartFile file : files) {
      String fileName = file.getOriginalFilename();
      // 检查同一文件夹下是否已存在同名文件
      if (isFileExists(folderPath, fileName)) {
        throw new IOException("文件上传失败，已存在同名文件: " + fileName + " 在文件夹: " + folderPath);
      }
      // 检查文件扩展名是否允许
      if (!FilesUtil.isExtensionAllowed(fileName)) {
        throw new IOException("不支持的文件类型: " + FilesUtil.getFileExtension(fileName));
      }
      // 将文件写入目标文件
      File destFile = new File(folder, fileName);
      file.transferTo(destFile);

      // 保存资源信息到数据库
      Resource resource = new Resource();
      resource.setFileName(fileName);
      resource.setClassId(classId);
      resource.setFilePath(folderPath + "/" + fileName);
      resource.setParentFolderId(parentFolderId); // 设置父文件夹 ID
      resource.setIsFolder(false); // 设置为文件
      resourceRepository.save(resource); // 假设您有相应的保存方法
    }
  }


  public boolean isFileExists(String folderPath,String fileName) {
   folderPath = folderPath+'/'+fileName;
    List<Resource> resources = resourceRepository.findByFilePath(folderPath);
    return !resources.isEmpty(); // 如果存在同名文件，返回 true
  }

  @Override
  public List<Resource> getFolderStructure(Long classId) {
    List<Resource> allResources = resourceRepository.findByClassId(classId);
    Resource rootResources = resourceRepository.findByClassIdAndParentFolderIdIsNull(classId);
   List<Resource> resource=resourceRepository.findByParentFolderId(rootResources.getId()); // 根据父文件夹ID获取子文件夹和文件
    // 查询该班级下的所有资源（文件夹和文件）
    return resource;
  }
  @Override
  public List<Resource> getSubFolder(Long parentFolderId) {
    // 查询该文件夹下的所有文件夹
    return resourceRepository.findByParentFolderIdAndIsFolderTrue(parentFolderId);
  }
  @Override
  public List<Resource> getFolderFiles(Long parentFolderId) {
    // 查询该文件夹下的所有资源（文件夹和文件）
    return resourceRepository.findByParentFolderIdAndIsFolderFalse(parentFolderId);
  }
  public void downloadFile(Long fileId, HttpServletResponse response) throws IOException {
    Resource resource = resourceRepository.findById(fileId)
      .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found"));

    String filePath = resource.getFilePath();
    File file = new File(filePath);

    //
    if (!file.exists()) {
      throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found at path: " + filePath);
    }

    FilesUtil.downloadFile(file, response);
  }
  public List<Resource> searchFilesInFolder(Long parentFolderId, String searchTerm) {
    System.out.println("Searching for files in folder ID: " + parentFolderId + " with term: " + searchTerm);
    return resourceRepository.findByParentFolderIdAndFileNameContainingAndIsFolderFalse(parentFolderId, searchTerm);
  }
  public boolean deleteFile(Long fileId) {
    // 检查文件是否存在
    if (!resourceRepository.existsById(fileId)) {
      return false;
    }
    // 删除文件逻辑，例如从数据库中删除记录
    resourceRepository.deleteById(fileId);
    return true;
  }

}
