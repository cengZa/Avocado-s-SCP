package com.example.myproject.model;


import javax.persistence.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "class")
@ApiModel("班级实体类")
public class Class {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "班级ID", example = "1")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    @ApiModelProperty(value = "课程ID", example = "101")
    private Course course; // 关联课程实体

    @ApiModelProperty(value = "课序号", example = "2")
    @Column(name = "class_sequence", nullable = false)
    private int classSequence;



    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teacher_id", nullable = false)
    @ApiModelProperty(value = "教师ID", example = "1001")
    private User teacher; // 关联教师实体

    //  }
    @JoinColumn(name = "resource_id")
    @ApiModelProperty(value = "资源ID", example = "2")
    private Long resourceId; // 新增的字段

    // Getters and Setters

}
