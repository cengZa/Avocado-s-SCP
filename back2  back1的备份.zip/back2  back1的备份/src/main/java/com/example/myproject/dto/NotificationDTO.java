package com.example.myproject.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel("通知DTO类")
public class NotificationDTO {

  @ApiModelProperty(value = "通知ID", example = "1")
  private Long id;

  @ApiModelProperty(value = "班级ID", example = "1")
  private Long classId;

  @JsonProperty("title")
  @ApiModelProperty(value = "通知标题", example = "期末考试通知")
  private String title;

  @JsonProperty("content")
  @ApiModelProperty(value = "通知内容", example = "请同学们准备期末考试。")
  private String content;







  // Getters and Setters
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getClassId() {
    return classId;
  }

  public void setClassId(Long classId) {
    this.classId = classId;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }


}
