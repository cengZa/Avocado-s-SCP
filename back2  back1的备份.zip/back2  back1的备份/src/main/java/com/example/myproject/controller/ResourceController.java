package com.example.myproject.controller;


import com.example.myproject.model.Resource;
import com.example.myproject.service.ResourceService;
import com.example.myproject.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/resource")
public class ResourceController {
  @Autowired
  private ResourceService resourceService;


//新建文件夹

  // 创建班级文件夹（如果不存在）
  @PostMapping("/create-folder")
  public Result<?> createFolder(@RequestParam Long  classId, @RequestParam(required = false) Long parentFolderId,@RequestParam String folderName) {
    resourceService.createClassFolder(classId);

    if (parentFolderId!= null && !folderName.isEmpty()) {
      resourceService.createSubFolder(classId, parentFolderId,folderName);
      return Result.success( folderName,"子文件夹创建成功: " );
    }
    return Result.success(classId,"班级文件夹创建成功: " );
  }
  // 上传文件到班级特定的文件夹
  @PostMapping("/upload-files")
  public Result<?> uploadFiles(@RequestParam("classId") Long classId,
                               @RequestParam(value = "parentFolderId", required = false)Long parentFolderId,
                               @RequestParam("files") List<MultipartFile> files) {
    try {
      resourceService.uploadFiles(classId,parentFolderId, files);
      return Result.success("文件上传成功。");
    } catch (IOException e) {
      return Result.error("500", "文件上传失败: " + e.getMessage());
    }
  }
  // 下载文件
  @GetMapping("/download-file")
  public Result<?> downloadFile(@RequestParam Long fileId, HttpServletResponse response) {
    try {

      resourceService.downloadFile(fileId, response);
      return Result.success("开始下载文件");
    } catch (Exception e) {
      return Result.error("下载文件失败: " , e.getMessage());
    }
  }
//获取特定班级的文件结构
  @GetMapping("/get-folder-structure")
  public Result<?> getFolderStructure(@RequestParam Long classId) {
    List<Resource> resources = resourceService.getFolderStructure(classId);
    return Result.success(resources);
  }
  @GetMapping("/get-subfolder")
  public Result<?> getSubFolder(@RequestParam Long parentFolderId) {
    List<Resource> resources = resourceService.getSubFolder(parentFolderId);
    return Result.success(resources);
  }
  // 获取特定文件夹内容
  @GetMapping("/get-folder-files")
  public Result<?> getFolderContents(@RequestParam Long parentFolderId) {
    List<Resource> resources = resourceService.getFolderFiles(parentFolderId);
    return Result.success(resources);
  }
  // 查找文件夹下的文件
  @GetMapping("/search-folder-file")
  public Result<?> SearchFolderContents(@RequestParam Long parentFolderId,String searchTerm) {
    try {
      List<Resource> files = resourceService.searchFilesInFolder(parentFolderId, searchTerm);
      return Result.success(files, "查询成功");
    } catch (Exception e) {
      return Result.error("查询失败: ", e.getMessage());
    }


  }
  //删除文件夹下的文件，在文件列表里，每一个文件后面跟着一个删除的超链接
  //todo:只在数据库中删除了，没在本地文件夹里删除
  @DeleteMapping("/delete-folder-file")
  public Result<?> deleteFile(@RequestParam Long fileId) {
    try {
      boolean deleted = resourceService.deleteFile(fileId);
      if (deleted) {
        return Result.success("文件删除成功");
      } else {
        return Result.error("300","文件删除失败: 找不到该文件");
      }
    } catch (Exception e) {
      return Result.error("删除失败: ", e.getMessage());
    }
  }
}
