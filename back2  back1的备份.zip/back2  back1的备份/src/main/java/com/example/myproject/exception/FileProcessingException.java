package com.example.myproject.exception;

/**
 * 文件处理相关的异常
 */
public class FileProcessingException extends BaseException {
    public FileProcessingException(String code, String message) {
        super(code, message);
    }

    public FileProcessingException(String message) {
        super("500", message);
    }
}
